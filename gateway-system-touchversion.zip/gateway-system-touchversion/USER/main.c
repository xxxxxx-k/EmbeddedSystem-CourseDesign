#include <stdio.h>
#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "includes.h"
#include "lcd.h"
#include "adc.h"
#include "key.h"
#include "exti.h"
#include "rtc.h"
#include "sram.h"
#include "string.h"
#include "math.h"
#include "dac.h"
#include "touch.h"

/* 24px ASCII 字库 (定义在 FONT.H, 通过 lcd.c 引入; 此处声明为 extern 供 2x 缩放函数使用) */
extern const unsigned char asc2_2412[95][36];

/* ====== 触摸驱动强制选择(如果 TP_Init 自动识别失败,取消注释对应行强制指定) ====== */
/* #define TOUCH_FORCE_GT9147     */ /* 强制使用 GT9147 (4.3寸电容屏,LCD ID=0x5510) */
/* #define TOUCH_FORCE_FT5206     */ /* 强制使用 FT5206 (7寸电容屏,LCD ID=0x1963) */
/* #define TOUCH_FORCE_OTT2001A   */ /* 强制使用 OTT2001A (备选电容屏) */

/* 外部 SRAM 双缓冲显存定义 (基地址 0x68000000) */
#define SRAM_BANK3_ADDR ((u32)0x68000000)
u16 *UI_Buffer = (u16 *)SRAM_BANK3_ADDR;

#define UI_W 480
#define UI_H 800

/* 任务优先级与堆栈大小定义 */
#define START_TASK_PRIO 10
#define START_STK_SIZE 128
__align(8) OS_STK START_TASK_STK[START_STK_SIZE];
void start_task(void *pdata);

#define CONTROL_TASK_PRIO 4
#define CONTROL_STK_SIZE 256
__align(8) OS_STK CONTROL_TASK_STK[CONTROL_STK_SIZE];
void control_task(void *pdata);

#define SENSOR_TASK_PRIO 5
#define SENSOR_STK_SIZE 512 /* float+FPU需要更大栈空间 */
__align(8) OS_STK SENSOR_TASK_STK[SENSOR_STK_SIZE];
void sensor_task(void *pdata);

#define COM_TASK_PRIO 6
#define COM_STK_SIZE 512
__align(8) OS_STK COM_TASK_STK[COM_STK_SIZE];
void com_task(void *pdata);

#define UI_TASK_PRIO 7
#define UI_STK_SIZE 768 /* 大屏(480x800)绘图需要更大栈 */
__align(8) OS_STK UI_TASK_STK[UI_STK_SIZE];
void ui_task(void *pdata);

#define TOUCH_TASK_PRIO 8
#define TOUCH_STK_SIZE 384
__align(8) OS_STK TOUCH_TASK_STK[TOUCH_STK_SIZE];
void touch_task(void *pdata);

/* 内核对象指针 */
OS_EVENT *UI_Queue;
OS_EVENT *COM_Queue;
OS_EVENT *Key_Sem;
OS_EVENT *Config_Mutex;

#define QUEUE_MAX_SIZE 5
void *UI_Msg_Buf[QUEUE_MAX_SIZE];
void *COM_Msg_Buf[QUEUE_MAX_SIZE];

/* 全局状态变量 */
volatile u8 UI_Mode = 0;           /* 0: 折线图, 1: 仪表盘, 2: 通信日志, 3: 电子钟 */
u8 g_Led1_Cmd = 1;                 /* LED1 控制字: 0=串口命令关闭, 1=串口命令打开, 默认开 */
volatile u8 Menu_State = 0;        /* 0: 待机, 1: 菜单导航, 2: 数值编辑 */
volatile u8 Menu_Cursor = 0;       /* 0~5 代表 6 个菜单项 */
volatile u8 Crash_Sim_Active = 0;  /* Crash Sim 弹窗显示标志,置1时 ui_task 跳过刷新避免覆盖红屏 */
volatile u8 Bubble_Show = 0;       /* 折线图数据气泡显示标志,0=隐藏 1=显示 */
volatile u8 Bubble_Idx = 0;        /* 气泡对应的历史点索引 0~PLOT_POINTS_MAX-1 */
volatile s8 Log_Scroll_Offset = 0; /* 通信日志滚动偏移,0=最新,正值=看更早 */

/* 传感器数据传输结构体 */
typedef struct
{
    int temperature;  /* 放大 10 倍的温度值，如 385 代表 38.5C */
    uint16_t light;   /* 归一化亮度百分比 (0~100) */
    uint16_t dac_vol; /* DAC输出电压 (mV) */
    uint16_t adc_vol; /* ADC回读电压 (mV) */
    uint8_t time[10];
} SensorData_t;

/* 系统配置参数结构体 */
typedef struct
{
    int temp_limit; /* 放大 10 倍的温度限制，如 385 代表 38.5C */
    uint16_t light_limit;
    u8 emergency_stop;
    u8 beep_mute;
    u8 led_state;
} GlobalConfig_t;

GlobalConfig_t GlobalConfig;

/* 曲线历史缓冲区 */
#define PLOT_POINTS_MAX 40
int Temp_History[PLOT_POINTS_MAX];
uint16_t Light_History[PLOT_POINTS_MAX];
u8 History_Count = 0;
u8 History_Head = 0;

/* 通信日志缓冲区(带分类) */
#define LOG_LINES_MAX 60
#define LOG_CAT_TX 0  /* 网关→上位机 传感器上报 */
#define LOG_CAT_RX 1  /* 上位机→网关 控制指令 */
#define LOG_CAT_SYS 2 /* 系统事件 看门狗/闹钟/校时等 */
char Comm_Logs[LOG_LINES_MAX][80];
u8 Comm_Log_Cat[LOG_LINES_MAX]; /* 每条日志的分类 */
u8 Log_Count = 0;
u8 Log_Head = 0;
volatile u8 Log_Filter = 0; /* 0=ALL 1=TX 2=RX 3=SYS */
volatile u16 Log_Gen = 0;   /* 日志代数: 每次Add_Comm_Log递增, 用于UI跳过无变化重绘 */

/* ====== 多闹钟 (最多3个, BKP_DR3/DR4/DR5 持久化) ====== */
#define MAX_ALARMS 3
volatile u8 Alm_H[MAX_ALARMS];         /* 闹钟时 */
volatile u8 Alm_M[MAX_ALARMS];         /* 闹钟分 */
volatile u8 Alm_En[MAX_ALARMS];        /* 闹钟使能 0/1 */
volatile u8 Alm_Trig_Mask = 0;         /* 触发位掩码 bit0~bit2 对应闹钟0~2 */
volatile u8 Alm_Dismissed[MAX_ALARMS]; /* 当日已关闭,不再触发 */
volatile u8 Alm_Snoozing[MAX_ALARMS];  /* 贪睡中,等待 snooze 时间到 */
volatile u8 Alm_Snooze_H[MAX_ALARMS];  /* 贪睡目标时 */
volatile u8 Alm_Snooze_M[MAX_ALARMS];  /* 贪睡目标分 */
volatile u8 Alarm_Popup_Active = 0;    /* 闹钟弹窗激活 */
volatile u8 Alarm_Popup_Idx = 0;       /* 当前弹窗对应的闹钟索引 */

/* ====== 倒计时 (单位:秒) ====== */
volatile u16 Timer_Set_Sec = 0;    /* 设定秒数 */
volatile u16 Timer_Remain_Sec = 0; /* 剩余秒数 */
volatile u8 Timer_Running = 0;
volatile u8 Timer_Trig = 0;         /* 倒计时归零标志 */
volatile u8 Timer_Popup_Active = 0; /* 倒计时结束弹窗激活 */

/* ====== DAC 模式与 ADC 窗口检测 ====== */
volatile u8 Dac_Mode = 0;         /* 0=正弦波自动, 1=固定电压 */
volatile u16 Dac_Fix_Mv = 1900;   /* 固定电压值 (mV), 默认 1.9V */
volatile u16 Adc_Win_Low = 500;   /* ADC 窗口下限 (mV) */
volatile u16 Adc_Win_High = 3000; /* ADC 窗口上限 (mV) */
volatile u8 Adc_Win_Alarm = 0;    /* ADC 窗口报警标志 */
volatile u8 Melody_Playing = 0;   /* 1=闹钟/倒计时旋律播放中, sensor_alarm_control 应跳过 BEEP */
volatile u8 Stop_Alarm_Beep = 0;  /* 1=强制停止闹钟蜂鸣(点击任意弹窗按钮立即生效) */

/* ====== 时钟弹窗状态 ====== */
/* Clock_Popup: 0=无弹窗 1=设时间 2=设日期 3=设闹钟 4=倒计时 */
volatile u8 Clock_Popup = 0;
volatile u8 Popup_Field = 0;     /* 弹窗内当前选中字段 */
volatile u8 Popup_Alarm_Idx = 0; /* 闹钟编辑索引 0~2 */
/* 弹窗编辑缓冲区 */
volatile u8 Pop_H = 0, Pop_M = 0, Pop_S = 0;
volatile u8 Pop_Y = 26, Pop_Mo = 1, Pop_D = 1;
volatile u8 Pop_TH = 0, Pop_TM = 0; /* 倒计时缓冲 */

/* ====== 触摸反馈点 (像素保存/恢复, 真正消失而非涂黑) ====== */
#define TAP_FB_SIZE 20                            /* 反馈点区域边长(像素) */
#define TAP_FB_RADIUS 7                           /* 反馈环半径 */
#define TAP_FB_DURATION 50                        /* 反馈持续时长(OS tick, 5ms/tick → 250ms) */
static u16 Tap_Fb_Buf[TAP_FB_SIZE * TAP_FB_SIZE]; /* 像素保存缓冲 */
static volatile u8 Tap_Fb_Active = 0;             /* 1=反馈点正在显示 */
static u16 Tap_Fb_X = 0, Tap_Fb_Y = 0;            /* 反馈点左上角坐标 */
static volatile u8 UI_Redraw_Seq = 0;             /* 全屏重绘序号(每次全屏重绘+1) */
static u8 Tap_Fb_Saved_Seq = 0;                   /* 反馈点显示时的重绘序号 */
static u32 Tap_Fb_Tick = 0;                       /* 反馈点显示起始 tick */

/* ================== 触摸手势与热区常量(需在 UI 绘制函数前定义) ================== */
/* 手势阈值 */
#define TAP_MOVE_TH 50   /* 点击位移阈值(像素) — 与 SWIPE_MOVE_TH 一致,消除死区 */
#define TAP_TIME_TH 100  /* 长按时间阈值(100 ticks = 500ms) */
#define SWIPE_MOVE_TH 50 /* 滑动确认阈值(像素) — >= 此值触发滑动 */
#define DRAG_MOVE_TH 10  /* 拖动确认阈值(像素) */

/* 调节柱热区(扩大原 16px 宽柱子到 40px 热区) */
#define BAR_HOT_X1 340
#define BAR_HOT_X2 380
#define BAR_TOP_Y 310
#define BAR_BOTTOM_Y 440
#define BAR_HEIGHT (BAR_BOTTOM_Y - BAR_TOP_Y) /* 130 */

/* 编辑态按钮条(仅 Temp/Light 编辑时显示) y=475~515 */
#define EDIT_BTN_Y1 475
#define EDIT_BTN_Y2 515
#define EDIT_BTN_MINUS_X1 90
#define EDIT_BTN_MINUS_X2 140
#define EDIT_BTN_PLUS_X1 150
#define EDIT_BTN_PLUS_X2 200
#define EDIT_BTN_OK_X1 210
#define EDIT_BTN_OK_X2 270
#define EDIT_BTN_CANCEL_X1 280
#define EDIT_BTN_CANCEL_X2 360

/* 待机态长按呼出菜单的中心热区 */
#define MENU_HOT_CX1 160
#define MENU_HOT_CX2 320
#define MENU_HOT_CY1 300
#define MENU_HOT_CY2 500

/* 紧急模式触摸恢复热区(屏幕中心区域) */
#define EMG_HOT_X1 120
#define EMG_HOT_X2 360
#define EMG_HOT_Y1 200
#define EMG_HOT_Y2 500

/* 导航态菜单项布局(menu_h=250, menu_y=275) */
#define NAV_MENU_X 80
#define NAV_MENU_Y 275
#define NAV_MENU_W 320
#define NAV_MENU_H 250
#define NAV_ITEM_Y0 (NAV_MENU_Y + 55) /* 330 */
#define NAV_ITEM_H 28

/* 日志页筛选按钮热区(y=40~76, 4 个按钮各 105px 宽) */
#define LOGFILT_Y1 40
#define LOGFILT_Y2 76
#define LOGFILT_ALL_X1 20
#define LOGFILT_ALL_X2 125
#define LOGFILT_TX_X1 130
#define LOGFILT_TX_X2 235
#define LOGFILT_RX_X1 240
#define LOGFILT_RX_X2 345
#define LOGFILT_SYS_X1 350
#define LOGFILT_SYS_X2 455

/* 仪表盘 DAC 触摸调节按钮 (4 个, 横向排列, y=380~440) */
#define DAC_BTN_Y1 380
#define DAC_BTN_Y2 440
#define DAC_BTN_W 105
#define DAC_BTN_GAP 15
#define DAC_BTN_DEC_X1 20
#define DAC_BTN_DEC_X2 (DAC_BTN_DEC_X1 + DAC_BTN_W)
#define DAC_BTN_INC_X1 (DAC_BTN_DEC_X2 + DAC_BTN_GAP)
#define DAC_BTN_INC_X2 (DAC_BTN_INC_X1 + DAC_BTN_W)
#define DAC_BTN_SIN_X1 (DAC_BTN_INC_X2 + DAC_BTN_GAP)
#define DAC_BTN_SIN_X2 (DAC_BTN_SIN_X1 + DAC_BTN_W)
#define DAC_BTN_FIX_X1 (DAC_BTN_SIN_X2 + DAC_BTN_GAP)
#define DAC_BTN_FIX_X2 (DAC_BTN_FIX_X1 + DAC_BTN_W)

/* ============== 7 段数码管尺寸 (主时钟用) ============== */
#define SEG_DW 40    /* 单个数码管宽度 */
#define SEG_DH 72    /* 单个数码管高度 */
#define SEG_GAP 4    /* 数码管间距 */
#define SEG_COL_W 16 /* 冒号宽度 */
/* "HH:MM:SS" = 6 数码管 + 2 冒号 + 7 间距 */
#define SEG_TIME_W (6 * SEG_DW + 2 * SEG_COL_W + 7 * SEG_GAP) /* 292 */
#define SEG_TIME_X ((480 - SEG_TIME_W) / 2)                   /* 94 */
#define SEG_TIME_Y 90

/* ============== 时钟主视图 4 大功能按钮 (2x2 网格) ============== */
#define CLK_BTN_W 180
#define CLK_BTN_H 56
#define CLK_BTN_ROW1_Y 250
#define CLK_BTN_ROW2_Y 316
#define CLK_BTN_L_X 30
#define CLK_BTN_R_X 270
/* 按钮: 设时间 / 设日期 / 设闹钟 / 倒计时 */

/* ============== 闹钟列表显示区 ============== */
#define CLK_ALM_LIST_Y 390
#define CLK_ALM_LIST_H 30
#define CLK_ALM_LIST_X 30
#define CLK_ALM_LIST_W 420

/* ============== 倒计时显示区 ============== */
#define CLK_TIMER_Y 500
#define CLK_TIMER_H 40

/* ============== 弹窗对话框布局 (居中模态) ============== */
#define POPUP_W 400
#define POPUP_H 440
#define POPUP_X ((480 - POPUP_W) / 2) /* 40 */
#define POPUP_Y 180
#define POPUP_TITLE_H 40
/* 弹窗内大字体数字显示 (替代数码管, 更清晰可见) */
#define POPSEG_DW 36
#define POPSEG_DH 60
#define POPSEG_GAP 4
#define POPSEG_COL_W 14
/* 大字体字段布局: 每个字段 60px 宽, 24px 字体 */
#define POPFIELD_W 60
#define POPFIELD_H 32
#define POPFIELD_FONT 24
#define POPFIELD_GAP 30 /* 字段间距(含冒号) */
/* 3 字段(HH:MM:SS) 布局: 总宽 = 3*60 + 2*30 = 240, 居中 */
#define POP3_START_X (POPUP_X + (POPUP_W - 240) / 2) /* = 40 + 80 = 120 */
/* 2 字段(HH:MM) 布局: 总宽 = 2*60 + 30 = 150, 居中 */
#define POP2_START_X (POPUP_X + (POPUP_W - 150) / 2) /* = 40 + 125 = 165 */
/* 冒号位置 (3 字段) */
#define POP3_COL1_X (POP3_START_X + POPFIELD_W + 5) /* 冒号1 x */
#define POP3_FLD1_X (POP3_COL1_X + 20)              /* 字段1 x */
#define POP3_COL2_X (POP3_FLD1_X + POPFIELD_W + 5)  /* 冒号2 x */
#define POP3_FLD2_X (POP3_COL2_X + 20)              /* 字段2 x */
/* 冒号位置 (2 字段) */
#define POP2_COL1_X (POP2_START_X + POPFIELD_W + 5)
#define POP2_FLD1_X (POP2_COL1_X + 20)
/* 弹窗内字段高亮区 */
#define POPUP_FIELD_Y (POPUP_Y + 80)
#define POPUP_FIELD_H (POPFIELD_H + 8)
/* 弹窗 - / + 按钮 */
#define POPUP_MINUS_X (POPUP_X + 30)
#define POPUP_MINUS_W 80
#define POPUP_PLUS_X (POPUP_X + POPUP_W - 110)
#define POPUP_PLUS_W 80
#define POPUP_ADJ_Y (POPUP_Y + 200)
#define POPUP_ADJ_H 44
/* 弹窗 OK / Cancel 按钮 */
#define POPUP_OK_Y (POPUP_Y + 260)
#define POPUP_OK_H 44
#define POPUP_OK_X (POPUP_X + 40)
#define POPUP_OK_W 140
#define POPUP_CANCEL_X (POPUP_X + POPUP_W - 180)
#define POPUP_CANCEL_W 140
/* 弹窗闹钟切换 < / > 按钮 */
#define POPUP_PREV_X (POPUP_X + 20)
#define POPUP_PREV_W 50
#define POPUP_NEXT_X (POPUP_X + POPUP_W - 70)
#define POPUP_NEXT_W 50
#define POPUP_SWITCH_Y (POPUP_Y + 140)
#define POPUP_SWITCH_H 44

/* 共享缓冲区与控制变量声明 */
static char str_buf[128];
static char temp_logs[20][80];
static u8 temp_log_cat[20];
static int backup_temp = 380;
static uint16_t backup_light = 80;

/* ================== 所有子函数原型声明 ================== */
static void BKP_Light_Write(uint16_t val);
static uint16_t BKP_Light_Read(void);
static void UI_Clear_Area(u16 sx, u16 sy, u16 width, u16 height, u16 color);
static void LCD_Flush_Area(u16 sx, u16 sy, u16 width, u16 height);
static void check_watchdog_reset(void);
static void load_system_config(void);
static void iwdg_init(void);
static void sensor_alarm_control(u8 alarm_type);
static void control_handle_standby(void);
static void control_handle_menu_nav(void);
static void control_handle_menu_edit(void);
static void ui_draw_curve(u8 menu_s, int limit);
static void ui_draw_dashboard(SensorData_t *data, int limit);
static void ui_draw_terminal_logs(u8 force_clear);
static void ui_draw_bottom_bar(SensorData_t *data, int limit, u8 led_st, u8 mute);
static void ui_draw_menu(u8 menu_s, u8 menu_c, int limit, u8 is_emergency, u8 mute, u8 menu_bg_draw);
static void ui_draw_status_led(u8 menu_s, u8 is_emergency, u8 alarm_type, u8 crash_active);
static void ui_draw_clock(u8 force_clear);
static void alarm_load(void);
static void alarm_save_idx(u8 idx);
static void alarm_check(void);
static void draw_7seg_digit(u16 x, u16 y, u8 digit, u16 color, u16 bg, u8 dw, u8 dh);
static void draw_7seg_str(u16 x, u16 y, const char *s, u16 color, u16 bg, u8 dw, u8 dh, u8 gap, u8 col_w);
static void popup_adjust_field(s8 delta);
static void popup_open(u8 type);
static void popup_confirm(void);
static u8 touch_clock_handle(u16 x, u16 y);

/* ================== 公共日志添加函数(带分类) ================== */
void Add_Comm_Log(const char *log_str, u8 cat)
{
    OS_CPU_SR cpu_sr;
    u8 tail;

    cpu_sr = 0;
    OS_ENTER_CRITICAL(); /* 进入临界区 */

    tail = (Log_Head + Log_Count) % LOG_LINES_MAX;
    if (Log_Count < LOG_LINES_MAX)
    {
        Log_Count++;
    }
    else
    {
        Log_Head = (Log_Head + 1) % LOG_LINES_MAX;
    }
    strncpy(Comm_Logs[tail], log_str, 79);
    Comm_Logs[tail][79] = '\0';
    Comm_Log_Cat[tail] = cat;
    Log_Gen++; /* 标记日志已变化, 触发UI重绘 */

    OS_EXIT_CRITICAL(); /* 退出临界区 */
}

/* ================== 底层画图 API ================== */
void UI_Clear(u16 color)
{
    u32 total;
    u32 i;

    total = (u32)lcddev.width * lcddev.height;
    for (i = 0; i < total; i++)
    {
        UI_Buffer[i] = color;
    }
}

void UI_DrawPoint(u16 x, u16 y, u16 color)
{
    if (x < lcddev.width && y < lcddev.height)
    {
        UI_Buffer[y * lcddev.width + x] = color;
    }
}

void UI_DrawLine(u16 x1, u16 y1, u16 x2, u16 y2, u16 color)
{
    u16 t;
    int xerr;
    int yerr;
    int delta_x;
    int delta_y;
    int distance;
    int incx;
    int incy;
    int uRow;
    int uCol;

    xerr = 0;
    yerr = 0;
    delta_x = x2 - x1;
    delta_y = y2 - y1;
    uRow = x1;
    uCol = y1;

    if (delta_x > 0)
        incx = 1;
    else if (delta_x == 0)
        incx = 0;
    else
    {
        incx = -1;
        delta_x = -delta_x;
    }

    if (delta_y > 0)
        incy = 1;
    else if (delta_y == 0)
        incy = 0;
    else
    {
        incy = -1;
        delta_y = -delta_y;
    }

    if (delta_x > delta_y)
        distance = delta_x;
    else
        distance = delta_y;

    for (t = 0; t <= distance + 1; t++)
    {
        UI_DrawPoint(uRow, uCol, color);
        xerr += delta_x;
        yerr += delta_y;
        if (xerr > distance)
        {
            xerr -= distance;
            uRow += incx;
        }
        if (yerr > distance)
        {
            yerr -= distance;
            uCol += incy;
        }
    }
}

/* ================== 备份寄存器与 SRAM 辅助静态函数 ================== */
static void BKP_Light_Write(uint16_t val)
{
    PWR_BackupAccessCmd(ENABLE);
    RTC_WriteBackupRegister(RTC_BKP_DR2, val);
}

static uint16_t BKP_Light_Read(void)
{
    return (uint16_t)RTC_ReadBackupRegister(RTC_BKP_DR2);
}

static void UI_Clear_Area(u16 sx, u16 sy, u16 width, u16 height, u16 color)
{
    u16 x;
    u16 y;
    for (y = sy; y < sy + height; y++)
    {
        for (x = sx; x < sx + width; x++)
        {
            UI_Buffer[y * (u32)lcddev.width + x] = color;
        }
    }
}

static void LCD_Flush_Area(u16 sx, u16 sy, u16 width, u16 height)
{
    u16 x;
    u16 y;
    LCD_Set_Window(sx, sy, width, height);
    LCD_WriteRAM_Prepare();
    for (y = sy; y < sy + height; y++)
    {
        for (x = sx; x < sx + width; x++)
        {
            LCD->LCD_RAM = UI_Buffer[y * (u32)lcddev.width + x];
        }
    }
    LCD_Set_Window(0, 0, lcddev.width, lcddev.height);
}

/* ================== 重构提取的系统/传感器控制子函数 ================== */

/**
 * @brief  检查系统是否由于独立看门狗 (IWDG) 复位引起
 * @note   若检测到 IWDG 复位，则全屏提示 "SYSTEM CRASH DETECTED"，蜂鸣器急促鸣叫4声，提示用户系统曾发生卡死并已自动重启。
 * @param  无
 * @retval 无
 */
static void check_watchdog_reset(void)
{
    int k;
    if (RCC_GetFlagStatus(RCC_FLAG_IWDGRST) == SET)
    {
        RCC_ClearFlag(); /* 清除复位标志，防反复报警 */

        Add_Comm_Log("SYS: Watchdog reset detected", LOG_CAT_SYS);

        /* 全屏灰色背景 */
        LCD_Fill(0, 0, lcddev.width - 1, lcddev.height - 1, GRAY);

        /* 打印卡死和复位提示 */
        POINT_COLOR = RED;
        BACK_COLOR = GRAY;
        LCD_ShowString((lcddev.width - 240) / 2, lcddev.height / 2 - 40, 240, 24, 24, (u8 *)"SYSTEM CRASH DETECTED");
        POINT_COLOR = WHITE;
        LCD_ShowString((lcddev.width - 200) / 2, lcddev.height / 2, 200, 16, 16, (u8 *)"Rebooting system...");

        /* BEEP 急促发出四声短促滴滴滴滴 */
        for (k = 0; k < 4; k++)
        {
            BEEP = 1;
            delay_ms(100);
            BEEP = 0;
            delay_ms(100);
        }
        delay_ms(500); /* 维持半秒让用户看清提示 */
    }
}

/**
 * @brief  系统配置参数载入函数
 * @note   读取 RTC 备份寄存器固化的温度和光照限制参数。若首次上电（无有效备份标志），则载入默认配置。
 * @param  无
 * @retval 无
 */
static void load_system_config(void)
{
    u32 bkp_val;
    if (My_RTC_Init() == 0)
    {
        bkp_val = RTC_BKP_Read();
        if ((bkp_val >> 16) == 0x55AA)
        {
            GlobalConfig.temp_limit = (int)(bkp_val & 0xFFFF);
        }
        else
        {
            GlobalConfig.temp_limit = 380; /* 38.0C 放大 10 倍 */
            RTC_BKP_Write((0x55AA << 16) | (uint16_t)380);
        }

        bkp_val = BKP_Light_Read();
        if ((bkp_val >> 8) == 0x55)
        {
            GlobalConfig.light_limit = bkp_val & 0xFF;
        }
        else
        {
            GlobalConfig.light_limit = 80; /* 默认光照报警值 80% */
            BKP_Light_Write((0x55 << 8) | 80);
        }
    }
    else
    {
        GlobalConfig.temp_limit = 380;
        GlobalConfig.light_limit = 80;
    }
    GlobalConfig.emergency_stop = 0;
    GlobalConfig.beep_mute = 0;
    GlobalConfig.led_state = 0;

    /* 载入闹钟配置(BKP_DR3 持久化) */
    alarm_load();
}

/**
 * @brief  初始化并开启独立看门狗 (IWDG)
 * @note   分频系数设置为 64 (500Hz)，重装载值为 2000，溢出周期约为 4 秒 (2000 * 2ms = 4s)。
 * @param  无
 * @retval 无
 */
static void iwdg_init(void)
{
    IWDG->KR = 0x5555; /* 开启寄存器写权限 */
    IWDG->PR = 4;      /* 64分频 (32kHz / 64 = 500Hz, 每刻度 2ms) */
    IWDG->RLR = 2000;  /* 重装载值 2000 (2000 * 2ms = 4000ms = 4秒) */
    IWDG->KR = 0xAAAA; /* 重载计数器 */
    IWDG->KR = 0XCCCC; /* 启动看门狗 */
}

/* ================== 2x 缩放字体渲染 (24px → 48px) ================== */
/* LCD 驱动仅支持 12/16/24 号字体, 此函数将 24px 字模每个像素画为 2x2 块,
   实现等效 48px 大字体显示, 供时钟主视图大号时间使用 */
static void LCD_ShowChar_2x(u16 x, u16 y, u8 ch, u16 color, u16 bg)
{
    u8 temp, t1, t;
    u16 num = ch - ' ';
    u8 col, row;
    u16 sx, sy;

    for (t = 0; t < 36; t++) /* 24px 字模: 36 字节/字符 */
    {
        temp = asc2_2412[num][t];
        col = t / 3; /* 列 0~11 */
        for (t1 = 0; t1 < 8; t1++)
        {
            row = (t % 3) * 8 + t1; /* 行 0~23 */
            sx = x + col * 2;
            sy = y + row * 2;
            if (temp & 0x80)
            {
                LCD_Fast_DrawPoint(sx, sy, color);
                LCD_Fast_DrawPoint(sx + 1, sy, color);
                LCD_Fast_DrawPoint(sx, sy + 1, color);
                LCD_Fast_DrawPoint(sx + 1, sy + 1, color);
            }
            else
            {
                LCD_Fast_DrawPoint(sx, sy, bg);
                LCD_Fast_DrawPoint(sx + 1, sy, bg);
                LCD_Fast_DrawPoint(sx, sy + 1, bg);
                LCD_Fast_DrawPoint(sx + 1, sy + 1, bg);
            }
            temp <<= 1;
        }
    }
}

/* 2x 缩放字符串 (24px → 48px), 每字符宽 24px, 高 48px */
static void LCD_ShowString_2x(u16 x, u16 y, const u8 *s, u16 color, u16 bg)
{
    while (*s >= ' ' && *s <= '~')
    {
        LCD_ShowChar_2x(x, y, *s, color, bg);
        x += 24; /* 12 * 2 = 24 像素/字符 */
        s++;
    }
}

/* ================== 触摸反馈点 (像素保存/恢复) ================== */
/* 恢复反馈点区域像素, 真正消失而非涂黑 */
static void tap_feedback_clear(void)
{
    u16 i, j;
    if (!Tap_Fb_Active)
        return;

    for (i = 0; i < TAP_FB_SIZE; i++)
    {
        for (j = 0; j < TAP_FB_SIZE; j++)
        {
            u16 px = Tap_Fb_X + j;
            u16 py = Tap_Fb_Y + i;
            LCD_Fill(px, py, px, py, Tap_Fb_Buf[i * TAP_FB_SIZE + j]);
        }
    }
    Tap_Fb_Active = 0;
}

/* 在触摸点处保存背景像素并画青色环, 超时后恢复像素, 真正消失 */
static void tap_feedback_show(u16 cx, u16 cy)
{
    u16 i, j;
    s16 bx = (s16)cx - TAP_FB_SIZE / 2;
    s16 by = (s16)cy - TAP_FB_SIZE / 2;

    if (Tap_Fb_Active)
        tap_feedback_clear();

    if (bx < 0)
        bx = 0;
    if (by < 0)
        by = 0;
    if (bx + TAP_FB_SIZE > lcddev.width)
        bx = lcddev.width - TAP_FB_SIZE;
    if (by + TAP_FB_SIZE > lcddev.height)
        by = lcddev.height - TAP_FB_SIZE;

    Tap_Fb_X = (u16)bx;
    Tap_Fb_Y = (u16)by;

    for (i = 0; i < TAP_FB_SIZE; i++)
        for (j = 0; j < TAP_FB_SIZE; j++)
            Tap_Fb_Buf[i * TAP_FB_SIZE + j] = LCD_ReadPoint(Tap_Fb_X + j, Tap_Fb_Y + i);

    {
        u16 ccx = Tap_Fb_X + TAP_FB_SIZE / 2;
        u16 ccy = Tap_Fb_Y + TAP_FB_SIZE / 2;
        POINT_COLOR = CYAN;
        LCD_Draw_Circle(ccx, ccy, TAP_FB_RADIUS);
        LCD_Draw_Circle(ccx, ccy, TAP_FB_RADIUS - 2);
    }

    Tap_Fb_Active = 1;
    Tap_Fb_Tick = OSTimeGet();
    Tap_Fb_Saved_Seq = UI_Redraw_Seq; /* 记录当前重绘序号 */
}

static void tap_feedback_poll(void)
{
    if (Tap_Fb_Active)
    {
        /* 如果反馈点显示后发生过全屏重绘, 保存的像素已失效, 直接丢弃不恢复 */
        if (UI_Redraw_Seq != Tap_Fb_Saved_Seq)
        {
            Tap_Fb_Active = 0;
            return;
        }
        {
            u32 now = OSTimeGet();
            if ((now - Tap_Fb_Tick) >= TAP_FB_DURATION)
                tap_feedback_clear();
        }
    }
}

/* ================== 7 段数码管渲染 ================== */
/* 段位映射: bit0=a(上) bit1=b(右上) bit2=c(右下) bit3=d(下) bit4=e(左下) bit5=f(左上) bit6=g(中) */
static const u8 seg_font[10] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F};

/**
 * @brief  绘制单个 7 段数码管数字
 * @param  x,y   左上角坐标
 * @param  digit 0~9
 * @param  color 点亮段颜色
 * @param  bg    熄灭段颜色(背景)
 * @param  dw,dh 数码管宽高
 */
static void draw_7seg_digit(u16 x, u16 y, u8 digit, u16 color, u16 bg, u8 dw, u8 dh)
{
    u8 seg;
    u16 seg_w, seg_h;   /* 水平段宽高 */
    u16 vseg_w, vseg_h; /* 垂直段宽高 */
    u16 mx, my;         /* 中线 */
    u8 lit;

    if (digit > 9)
        digit = 0;
    seg = seg_font[digit];

    /* 水平段: 占数码管宽度的 60%, 高度 = dh/12 */
    seg_w = (u16)(dw * 60 / 100);
    seg_h = (u16)(dh / 12);
    if (seg_h < 3)
        seg_h = 3;
    /* 垂直段: 宽度 = dw/12, 高度 = (dh - 2*seg_h)/2 */
    vseg_w = (u16)(dw / 12);
    if (vseg_w < 3)
        vseg_w = 3;
    vseg_h = (u16)((dh - 2 * seg_h) / 2);

    mx = x + (u16)((dw - seg_w) / 2); /* 水平段左边 x */
    my = y + seg_h + vseg_h;          /* 中线 y */

    /* a 段 (上) */
    lit = (seg & 0x01) ? 1 : 0;
    LCD_Fill(mx, y, mx + seg_w - 1, y + seg_h - 1, lit ? color : bg);
    /* d 段 (下) */
    lit = (seg & 0x08) ? 1 : 0;
    LCD_Fill(mx, y + dh - seg_h, mx + seg_w - 1, y + dh - 1, lit ? color : bg);
    /* g 段 (中) */
    lit = (seg & 0x40) ? 1 : 0;
    LCD_Fill(mx, my, mx + seg_w - 1, my + seg_h - 1, lit ? color : bg);
    /* f 段 (左上) */
    lit = (seg & 0x20) ? 1 : 0;
    LCD_Fill(x, y + seg_h, x + vseg_w - 1, my - 1, lit ? color : bg);
    /* b 段 (右上) */
    lit = (seg & 0x02) ? 1 : 0;
    LCD_Fill(x + dw - vseg_w, y + seg_h, x + dw - 1, my - 1, lit ? color : bg);
    /* e 段 (左下) */
    lit = (seg & 0x10) ? 1 : 0;
    LCD_Fill(x, my + seg_h, x + vseg_w - 1, y + dh - seg_h - 1, lit ? color : bg);
    /* c 段 (右下) */
    lit = (seg & 0x04) ? 1 : 0;
    LCD_Fill(x + dw - vseg_w, my + seg_h, x + dw - 1, y + dh - seg_h - 1, lit ? color : bg);

    /* 左右两侧空白填充背景(避免残留) */
    LCD_Fill(x, y, mx - 1, y + dh - 1, bg);
    LCD_Fill(mx + seg_w, y, x + dw - 1, y + dh - 1, bg);
}

/**
 * @brief  绘制 7 段数码管字符串 (支持 0-9 和 ':')
 * @param  s     字符串,如 "12:30:45" 或 "26-07-07"
 * @param  dw,dh 单个数码管宽高
 * @param  gap   数字间距
 * @param  col_w 冒号/分隔符宽度
 */
static void draw_7seg_str(u16 x, u16 y, const char *s, u16 color, u16 bg, u8 dw, u8 dh, u8 gap, u8 col_w)
{
    u16 cx = x;
    const char *p = s;
    while (*p && cx < lcddev.width)
    {
        if (*p >= '0' && *p <= '9')
        {
            draw_7seg_digit(cx, y, (u8)(*p - '0'), color, bg, dw, dh);
            cx += dw + gap;
        }
        else
        {
            /* 冒号或分隔符: 画两个小方块 */
            u16 dot_w = (u16)(col_w / 3);
            u16 dot_y1;
            u16 dot_y2;
            if (dot_w < 2)
                dot_w = 2;
            dot_y1 = y + dh / 3;
            dot_y2 = y + dh * 2 / 3;
            /* 先填背景 */
            LCD_Fill(cx, y, cx + col_w - 1, y + dh - 1, bg);
            LCD_Fill(cx + (u16)((col_w - dot_w) / 2), dot_y1,
                     cx + (u16)((col_w - dot_w) / 2) + dot_w - 1, dot_y1 + dot_w - 1, color);
            LCD_Fill(cx + (u16)((col_w - dot_w) / 2), dot_y2,
                     cx + (u16)((col_w - dot_w) / 2) + dot_w - 1, dot_y2 + dot_w - 1, color);
            cx += col_w + gap;
        }
        p++;
    }
}

/* ================== 闹钟功能 (多闹钟, BKP_DR3/DR4/DR5 持久化) ================== */
/* 每个 BKP_DRx 格式: 0xFFFFFFFF=关闭, 否则 (0x55AA<<16)|(H<<8)|M, H/M 为 BCD-like 十进制 */
/* 闹钟 0/1/2 分别存于 BKP_DR3/DR4/DR5 */

/**
 * @brief  从 BKP_DR3/DR4/DR5 载入 3 个闹钟配置
 */
static void alarm_load(void)
{
    u8 i;
    u32 val;
    u32 dr_map[3] = {RTC_BKP_DR3, RTC_BKP_DR4, RTC_BKP_DR5};
    for (i = 0; i < MAX_ALARMS; i++)
    {
        val = RTC_ReadBackupRegister(dr_map[i]);
        if ((val >> 16) == 0x55AA)
        {
            Alm_H[i] = (u8)((val >> 8) & 0xFF);
            Alm_M[i] = (u8)(val & 0xFF);
            Alm_En[i] = 1;
            /* 合法性校验 */
            if (Alm_H[i] > 23)
                Alm_H[i] = 7;
            if (Alm_M[i] > 59)
                Alm_M[i] = 0;
        }
        else
        {
            Alm_H[i] = 7;
            Alm_M[i] = 0;
            Alm_En[i] = 0;
        }
    }
}

/**
 * @brief  保存指定闹钟到 BKP_DR(3+idx)
 * @param  idx 闹钟索引 0~2
 */
static void alarm_save_idx(u8 idx)
{
    u32 val;
    u32 dr_map[3] = {RTC_BKP_DR3, RTC_BKP_DR4, RTC_BKP_DR5};
    if (idx >= MAX_ALARMS)
        return;
    if (Alm_En[idx])
        val = (0x55AAUL << 16) | ((u32)Alm_H[idx] << 8) | Alm_M[idx];
    else
        val = 0xFFFFFFFF;
    PWR_BackupAccessCmd(ENABLE);
    RTC_WriteBackupRegister(dr_map[idx], val);
}

/**
 * @brief  闹钟+倒计时检测(每 250ms 调用一次)
 * @note   闹钟使用旋律节奏(区别于报警急促鸣叫),触发时弹出延后/关闭窗口。
 *         倒计时归零时触发蜂鸣。含整点报时。
 */
/* 闹钟旋律节奏表 (每步 50ms, 1=响 0=停, "叮-叮-叮"渐快节奏) */
/* 小星星旋律 50ms 一格 1=鸣 0=静音
简谱：11|55|66 5- |44|33|22 1-
每一组长音用连续1，停顿用0 */
/* 小星星 30ms一格 缩短停顿，节奏加快 */
static const u8 alm_melody[] = {
    // 1 1
    1,
    1,
    0,
    1,
    1,
    0,
    // 5 5
    1,
    1,
    0,
    1,
    1,
    0,
    // 6 6 长5
    1,
    1,
    0,
    1,
    1,
    0,
    1,
    1,
    1,
    0,
    // 4 4
    1,
    1,
    0,
    1,
    1,
    0,
    // 3 3
    1,
    1,
    0,
    1,
    1,
    0,
    // 2 2 长1
    1,
    1,
    0,
    1,
    1,
    0,
    1,
    1,
    1,
    0,
};
#define ALM_MELODY_LEN 56
#define ALM_MELODY_REPEAT 2

/* 倒计时结束 "叮-咚" 节奏表 (每步 50ms) */
static const u8 timer_melody[] = {
    1,
    1,
    1,
    1, /* 叮 (长, 200ms) */
    0,
    0, /* 停 100ms */
    1,
    1,
    1, /* 咚 (短, 150ms) */
    0,
    0,
    0,
    0, /* 停 200ms */
};
#define TIMER_MELODY_LEN 11
#define TIMER_MELODY_REPEAT 1 /* 只响一遍叮-咚 */

static void alarm_check(void)
{
    RTC_TimeTypeDef rtc_t;
    static u8 last_min = 0xFF;
    static u8 last_sec = 0xFF;
    static u16 alarm_beep_cnt = 0; /* 闹钟蜂鸣倒计时(50ms 单位) */
    static u16 timer_beep_cnt = 0; /* 倒计时结束蜂鸣(独立, 叮咚节奏) */
    static u8 timer_last_sec = 0xFF;
    static u16 melody_step = 0;
    static u8 melody_repeat_cnt = 0;
    static u16 t_melody_step = 0;
    static u8 t_melody_repeat_cnt = 0;
    u8 i;
    u8 mute_now;

    RTC_GetTime(RTC_Format_BIN, &rtc_t);

    /* 读取静音状态: 静音时闹钟/倒计时/整点报时都不响 */
    mute_now = GlobalConfig.beep_mute;

    /* 默认无旋律播放, sensor_alarm_control 可正常控制 BEEP */
    Melody_Playing = 0;

    /* 午夜清除当日已关闭标志 */
    if (rtc_t.RTC_Hours == 0 && rtc_t.RTC_Minutes == 0 && rtc_t.RTC_Seconds == 0)
    {
        for (i = 0; i < MAX_ALARMS; i++)
            Alm_Dismissed[i] = 0;
    }

    /* 闹钟蜂鸣进行中 (叮-叮-叮渐快旋律) */
    if (alarm_beep_cnt > 0)
    {
        u8 mel_idx;
        Melody_Playing = 1; /* 阻止 sensor_alarm_control 覆盖 BEEP */

        /* 强制停止闹钟蜂鸣 */
        if (Stop_Alarm_Beep)
        {
            Stop_Alarm_Beep = 0;
            alarm_beep_cnt = 0;
            BEEP = 0;
            melody_repeat_cnt = 0;
            melody_step = 0;
            return;
        }

        /* 静音模式: 不响蜂鸣器, 只保留弹窗视觉提示 */
        if (!mute_now)
        {
            alarm_beep_cnt--;
            mel_idx = (u8)(melody_step % ALM_MELODY_LEN);
            BEEP = alm_melody[mel_idx];
            melody_step++;

            if (mel_idx == ALM_MELODY_LEN - 1)
            {
                melody_repeat_cnt++;
                if (melody_repeat_cnt >= ALM_MELODY_REPEAT)
                {
                    alarm_beep_cnt = 0;
                    BEEP = 0;
                    melody_repeat_cnt = 0;
                    melody_step = 0;
                }
            }
        }
        else
        {
            /* 静音时立即结束蜂鸣计数, 弹窗仍由 Alarm_Popup_Active 控制 */
            alarm_beep_cnt = 0;
            BEEP = 0;
            melody_repeat_cnt = 0;
            melody_step = 0;
        }

        /* 弹窗激活时不响应按键,需通过弹窗按钮操作 */
        if (Alarm_Popup_Active)
            OSSemAccept(Key_Sem); /* 消费信号量但不关闭 */
        else
        {
            if (OSSemAccept(Key_Sem) > 0)
            {
                alarm_beep_cnt = 0;
                BEEP = 0;
                melody_step = 0;
                melody_repeat_cnt = 0;
            }
        }
        return;
    }

    /* 倒计时结束蜂鸣进行中 (叮-咚两声, 区别于闹钟) */
    if (timer_beep_cnt > 0)
    {
        u8 t_mel_idx;
        Melody_Playing = 1; /* 阻止 sensor_alarm_control 覆盖 BEEP */

        /* 静音模式: 不响蜂鸣器, 只保留弹窗视觉提示 */
        if (!mute_now)
        {
            timer_beep_cnt--;
            t_mel_idx = (u8)(t_melody_step % TIMER_MELODY_LEN);
            BEEP = timer_melody[t_mel_idx];
            t_melody_step++;

            if (t_mel_idx == TIMER_MELODY_LEN - 1)
            {
                t_melody_repeat_cnt++;
                if (t_melody_repeat_cnt >= TIMER_MELODY_REPEAT)
                {
                    timer_beep_cnt = 0;
                    BEEP = 0;
                    t_melody_repeat_cnt = 0;
                    t_melody_step = 0;
                }
            }
        }
        else
        {
            /* 静音时立即结束蜂鸣计数, 弹窗仍由 Timer_Popup_Active 控制 */
            timer_beep_cnt = 0;
            BEEP = 0;
            t_melody_repeat_cnt = 0;
            t_melody_step = 0;
        }

        /* 倒计时弹窗激活时不响应按键,需通过弹窗按钮关闭 */
        if (Timer_Popup_Active)
            OSSemAccept(Key_Sem);
        else
        {
            if (OSSemAccept(Key_Sem) > 0)
            {
                timer_beep_cnt = 0;
                BEEP = 0;
                t_melody_step = 0;
                t_melody_repeat_cnt = 0;
            }
        }
        return;
    }

    /* 倒计时:每秒递减一次 */
    if (rtc_t.RTC_Seconds != timer_last_sec)
    {
        timer_last_sec = rtc_t.RTC_Seconds;
        if (Timer_Running && Timer_Remain_Sec > 0)
        {
            Timer_Remain_Sec--;
            if (Timer_Remain_Sec == 0)
            {
                Timer_Running = 0;
                Timer_Trig = 1;
                timer_beep_cnt = (u16)(TIMER_MELODY_LEN * TIMER_MELODY_REPEAT);
                t_melody_step = 0;
                t_melody_repeat_cnt = 0;
                Timer_Popup_Active = 1;
                sprintf(str_buf, "SYS: Countdown finished");
                Add_Comm_Log(str_buf, LOG_CAT_SYS);
            }
        }
    }

    /* 仅在秒数变化时检测闹钟(避免同一秒内多次触发) */
    if (rtc_t.RTC_Seconds == last_sec)
        return;
    last_sec = rtc_t.RTC_Seconds;

    /* 多闹钟匹配:时分吻合且秒==0, 跳过已关闭的 */
    if (rtc_t.RTC_Seconds == 0)
    {
        for (i = 0; i < MAX_ALARMS; i++)
        {
            if (Alm_En[i] && !Alm_Dismissed[i] &&
                rtc_t.RTC_Hours == Alm_H[i] && rtc_t.RTC_Minutes == Alm_M[i])
            {
                Alm_Trig_Mask |= (1 << i);
                if (alarm_beep_cnt == 0 && !Alarm_Popup_Active)
                {
                    alarm_beep_cnt = (u16)(ALM_MELODY_LEN * ALM_MELODY_REPEAT);
                    melody_step = 0;
                    melody_repeat_cnt = 0;
                    Alarm_Popup_Active = 1;
                    Alarm_Popup_Idx = i;
                    Alm_Snoozing[i] = 0;
                    sprintf(str_buf, "SYS: Alarm %d triggered %02d:%02d", i + 1, Alm_H[i], Alm_M[i]);
                    Add_Comm_Log(str_buf, LOG_CAT_SYS);
                }
            }
        }

        /* 检查贪睡时间是否到达 */
        for (i = 0; i < MAX_ALARMS; i++)
        {
            if (Alm_Snoozing[i] && !Alm_Dismissed[i] &&
                rtc_t.RTC_Hours == Alm_Snooze_H[i] && rtc_t.RTC_Minutes == Alm_Snooze_M[i])
            {
                Alm_Trig_Mask |= (1 << i);
                if (alarm_beep_cnt == 0 && !Alarm_Popup_Active)
                {
                    alarm_beep_cnt = (u16)(ALM_MELODY_LEN * ALM_MELODY_REPEAT);
                    melody_step = 0;
                    melody_repeat_cnt = 0;
                    Alarm_Popup_Active = 1;
                    Alarm_Popup_Idx = i;
                    Alm_Snoozing[i] = 0;
                    sprintf(str_buf, "SYS: Alarm %d snooze fired %02d:%02d", i + 1,
                            Alm_Snooze_H[i], Alm_Snooze_M[i]);
                    Add_Comm_Log(str_buf, LOG_CAT_SYS);
                }
            }
        }
    }

    /* 整点报时:每整点短促两声(闹钟触发时跳过, 静音时不响) */
    if (rtc_t.RTC_Minutes == 0 && rtc_t.RTC_Seconds == 0 && alarm_beep_cnt == 0 && !mute_now)
    {
        u8 any_alm = 0;
        for (i = 0; i < MAX_ALARMS; i++)
        {
            if (Alm_En[i] && rtc_t.RTC_Hours == Alm_H[i])
            {
                any_alm = 1;
                break;
            }
        }
        if (!any_alm && last_min != 0)
        {
            BEEP = 1;
            delay_ms(80);
            BEEP = 0;
            delay_ms(80);
            BEEP = 1;
            delay_ms(80);
            BEEP = 0;
            sprintf(str_buf, "SYS: Hourly chime %02d:00", rtc_t.RTC_Hours);
            Add_Comm_Log(str_buf, LOG_CAT_SYS);
        }
    }
    last_min = rtc_t.RTC_Minutes;
}

/**
 * @brief  50ms 高频声光报警状态机控制
 * @note   根据当前的报警类型 (0=正常, 1=普通超限, 2=紧急拉闸) 周期性控制红灯和有源蜂鸣器的状态。
 * @param  alarm_type: 报警类型
 * @retval 无
 */
static void sensor_alarm_control(u8 alarm_type)
{
    u8 err;
    u8 mute;
    static u8 beep_tick = 0;
    static u8 last_alarm_type = 0;

    /* 状态发生改变时重置蜂鸣器节拍 */
    if (alarm_type != last_alarm_type)
    {
        last_alarm_type = alarm_type;
        beep_tick = 0;
    }

    OSMutexPend(Config_Mutex, 0, &err);
    mute = GlobalConfig.beep_mute;
    OSMutexPost(Config_Mutex);

    /* 闹钟/倒计时旋律播放中: 只控制 LED, 不干预 BEEP (由 alarm_check 控制) */
    if (Melody_Playing)
    {
        if (alarm_type == 2)
            LED0 = (beep_tick % 4 < 2) ? 0 : 1;
        else if (alarm_type == 1)
            LED0 = 0;
        else
            LED0 = 1;
        beep_tick++;
        return;
    }

    if (alarm_type == 2) /* 紧急报警：红灯高频闪烁，有源蜂鸣器急促短鸣 */
    {
        if (beep_tick >= 12)
            beep_tick = 0; /* 0.6秒周期 */
        if (!mute)
        {
            BEEP = (beep_tick % 4 < 2) ? 1 : 0; /* 100ms 鸣叫, 100ms 停止 */
        }
        else
        {
            BEEP = 0;
        }
        LED0 = (beep_tick % 4 < 2) ? 0 : 1; /* 红灯同步 5Hz 闪烁 */
        beep_tick++;
    }
    else if (alarm_type == 1) /* 普通超限报警：红灯长亮，有源蜂鸣器“滴-滴-嘀——”循环 */
    {
        if (beep_tick >= 24)
            beep_tick = 0; /* 1.2秒周期 */
        if (!mute)
        {
            if (beep_tick < 2)
                BEEP = 1; /* 0-100ms 鸣叫 (滴) */
            else if (beep_tick < 4)
                BEEP = 0; /* 100-200ms 停止 */
            else if (beep_tick < 6)
                BEEP = 1; /* 200-300ms 鸣叫 (滴) */
            else if (beep_tick < 8)
                BEEP = 0; /* 300-400ms 停止 */
            else if (beep_tick < 13)
                BEEP = 1; /* 400-650ms 鸣叫 (嘀——) */
            else
                BEEP = 0; /* 650-1200ms 停止 */
        }
        else
        {
            BEEP = 0;
        }
        LED0 = 0; /* 红灯长亮 */
        beep_tick++;
    }
    else /* 正常无警报 */
    {
        BEEP = 0;
        LED0 = 1; /* 红灯熄灭 */
        beep_tick = 0;
    }
}

/* ================== 重构提取的按键控制子函数 ================== */

/**
 * @brief  待机模式下的物理按键逻辑处理
 * @note   在待机状态下，根据触发的按键执行呼出菜单、紧急拉闸/恢复、消音以及UI页面切换。
 * @param  无
 * @retval 无
 */
static void control_handle_standby(void)
{
    if (Last_Key == 0) /* KEY0: 呼出系统菜单 */
    {
        Menu_State = 1;
        Menu_Cursor = 0;
    }
    else if (Last_Key == 2) /* KEY2: 紧急拉闸/恢复 */
    {
        GlobalConfig.emergency_stop = !GlobalConfig.emergency_stop;
        if (GlobalConfig.emergency_stop == 0)
        {
            BEEP = 0;
            LED0 = 1;
            Add_Comm_Log("SYS: Emergency released", LOG_CAT_SYS);
        }
        else
        {
            Add_Comm_Log("SYS: Emergency stop activated", LOG_CAT_SYS);
        }
    }
    else if (Last_Key == 1) /* KEY1 (DOWN): 待机下向下循环切换 UI 页面 */
    {
        UI_Mode = (UI_Mode + 1) % 4;
    }
    else if (Last_Key == 3) /* WK_UP: 切换蜂鸣器消音开关 (响/不响) */
    {
        GlobalConfig.beep_mute = !GlobalConfig.beep_mute;
    }
}

/**
 * @brief  菜单导航模式下的物理按键逻辑处理
 * @note   在一级菜单导航状态下，处理光标移动、确认进入二级编辑菜单以及返回退出菜单。
 * @param  无
 * @retval 无
 */
static void control_handle_menu_nav(void)
{
    if (Last_Key == 3) /* WK_UP: 向上选择菜单项 */
    {
        if (Menu_Cursor > 0)
            Menu_Cursor--;
        else
            Menu_Cursor = 5;
    }
    else if (Last_Key == 1) /* KEY1: 向下选择菜单项 */
    {
        if (Menu_Cursor < 5)
            Menu_Cursor++;
        else
            Menu_Cursor = 0;
    }
    else if (Last_Key == 0) /* KEY0: 确认选中当前项 */
    {
        if (Menu_Cursor == 5) /* Exit */
        {
            Menu_State = 0;
        }
        else if (Menu_Cursor == 2) /* Emg Stop 直接切换 ON/OFF */
        {
            GlobalConfig.emergency_stop = !GlobalConfig.emergency_stop;
            if (GlobalConfig.emergency_stop == 0)
            {
                BEEP = 0;
                LED0 = 1;
            }
        }
        else if (Menu_Cursor == 3) /* Beep Mute 直接切换 ON/OFF */
        {
            GlobalConfig.beep_mute = !GlobalConfig.beep_mute;
        }
        else /* Temp Limit (0), Light Limit (1), Crash Sim (4) 进入状态 2 */
        {
            Menu_State = 2;
            backup_temp = GlobalConfig.temp_limit;
            backup_light = GlobalConfig.light_limit;
        }
    }
    else if (Last_Key == 2) /* KEY2: 返回并退出菜单 */
    {
        Menu_State = 0;
    }
}

/**
 * @brief  二级数值编辑与卡死仿真处理
 * @note   在参数编辑模式下高频周期性轮询物理引脚电平，处理参数调节（温度、光照）、卡死仿真启动、确认与放弃修改逻辑。
 * @param  无
 * @retval 无
 */
static void control_handle_menu_edit(void)
{
    u8 pin_key;
    u8 err;
    u16 menu_w;
    u16 menu_h;
    u16 menu_x;
    u16 menu_y;

    pin_key = 0; /* 0=未按, 1=WK_UP(加), 2=KEY1(减), 3=KEY0(确定), 4=KEY2(回退) */

    /* 先检查触摸任务注入的虚拟按键(通过 Key_Sem 信号量,非阻塞) */
    if (OSSemAccept(Key_Sem) > 0)
    {
        if (Last_Key == 3)
            pin_key = 1; /* 触摸 "+" → WK_UP */
        else if (Last_Key == 1)
            pin_key = 2; /* 触摸 "-" → KEY1 */
        else if (Last_Key == 0)
            pin_key = 3; /* 触摸 "OK" → KEY0 */
        else if (Last_Key == 2)
            pin_key = 4; /* 触摸 "Cancel" → KEY2 */
        Last_Key = 0xFF;
    }

    /* 没有触摸按键时,直接读取物理 GPIO 电平 */
    if (pin_key == 0)
    {
        if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0) == 1)
            pin_key = 1; /* WK_UP 物理高电平代表按下 */
        else if (GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_3) == 0)
            pin_key = 2; /* KEY1 物理低电平代表按下 */
        else if (GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_4) == 0)
            pin_key = 3; /* KEY0 物理低电平代表按下 */
        else if (GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_2) == 0)
            pin_key = 4; /* KEY2 物理低电平代表按下 */
    }

    if (pin_key > 0)
    {
        OSMutexPend(Config_Mutex, 0, &err);
        if (Menu_Cursor == 0) /* 编辑 Temp Limit (15.0 ~ 50.0) */
        {
            if (pin_key == 1) /* WK_UP (+) */
            {
                GlobalConfig.temp_limit += 5; /* 增加 0.5C */
                if (GlobalConfig.temp_limit > 500)
                    GlobalConfig.temp_limit = 500;
            }
            else if (pin_key == 2) /* KEY1 (-) */
            {
                GlobalConfig.temp_limit -= 5; /* 减少 0.5C */
                if (GlobalConfig.temp_limit < 150)
                    GlobalConfig.temp_limit = 150;
            }
            else if (pin_key == 3) /* KEY0 (确认保存并返回) */
            {
                RTC_BKP_Write((0x55AA << 16) | (uint16_t)GlobalConfig.temp_limit);
                sprintf(str_buf, "SYS: Temp limit=%d.%dC",
                        GlobalConfig.temp_limit / 10, GlobalConfig.temp_limit % 10);
                Add_Comm_Log(str_buf, LOG_CAT_SYS);
                Menu_State = 1;
            }
            else if (pin_key == 4) /* KEY2 (放弃修改并返回) */
            {
                GlobalConfig.temp_limit = backup_temp; /* 恢复旧值 */
                Menu_State = 1;
            }
        }
        else if (Menu_Cursor == 1) /* 编辑 Light Limit (10 ~ 95) */
        {
            if (pin_key == 1) /* WK_UP (+) */
            {
                GlobalConfig.light_limit += 5;
                if (GlobalConfig.light_limit > 95)
                    GlobalConfig.light_limit = 95;
            }
            else if (pin_key == 2) /* KEY1 (-) */
            {
                GlobalConfig.light_limit -= 5;
                if (GlobalConfig.light_limit < 10)
                    GlobalConfig.light_limit = 10;
            }
            else if (pin_key == 3) /* KEY0 (确认保存并返回) */
            {
                BKP_Light_Write((0x55 << 8) | GlobalConfig.light_limit);
                sprintf(str_buf, "SYS: Light limit=%d%%", GlobalConfig.light_limit);
                Add_Comm_Log(str_buf, LOG_CAT_SYS);
                Menu_State = 1;
            }
            else if (pin_key == 4) /* KEY2 (放弃修改并返回) */
            {
                GlobalConfig.light_limit = backup_light; /* 恢复旧值 */
                Menu_State = 1;
            }
        }
        else if (Menu_Cursor == 4) /* 编辑 Crash Sim */
        {
            if (pin_key == 1 || pin_key == 3) /* WK_UP (+) 或 KEY0 (确定) */
            {
                menu_w = 320;
                menu_h = 250;
                menu_x = (lcddev.width - menu_w) / 2;
                menu_y = (lcddev.height - menu_h) / 2;

                OSMutexPost(Config_Mutex); /* 释放信号量 */

                /* 置 Crash Sim 显示标志,阻止 ui_task 刷新覆盖红屏弹窗,
                   同时 sensor_task 检测到此标志后停止喂 IWDG */
                Crash_Sim_Active = 1;
                Add_Comm_Log("SYS: Crash simulation started", LOG_CAT_SYS);

                /* 喂狗一次,重置 IWDG 4 秒倒计时(从此刻开始计算) */
                IWDG->KR = 0xAAAA;

                /* 覆盖画红底白字弹窗提示 */
                LCD_Fill(menu_x, menu_y, menu_x + menu_w - 1, menu_y + menu_h - 1, RED);
                UI_Redraw_Seq++; /* 标记重绘, 使反馈点保存的像素失效 */
                POINT_COLOR = WHITE;
                BACK_COLOR = RED;
                LCD_ShowString(menu_x + 30, menu_y + 60, 260, 24, 24, (u8 *)"CRASH SIMULATION");
                LCD_ShowString(menu_x + 20, menu_y + 95, 280, 16, 16, (u8 *)"System will crash in 4s...");

                /* ====== 进度条动画(4秒倒计时,匹配 IWDG 超时) ====== */
                {
                    int prog_i;
                    u16 pb_x = menu_x + 60;
                    u16 pb_y = menu_y + 140;
                    u16 pb_w = 200;
                    u16 pb_h = 20;

                    /* 进度条边框(白色) */
                    LCD_DrawLine(pb_x, pb_y, pb_x + pb_w, pb_y);
                    LCD_DrawLine(pb_x, pb_y + pb_h, pb_x + pb_w, pb_y + pb_h);
                    LCD_DrawLine(pb_x, pb_y, pb_x, pb_y + pb_h);
                    LCD_DrawLine(pb_x + pb_w, pb_y, pb_x + pb_w, pb_y + pb_h);

                    /* 80 步 × 50ms = 4000ms,匹配 IWDG 4 秒超时 */
                    for (prog_i = 0; prog_i < 80; prog_i++)
                    {
                        OSTimeDly(10); /* 50ms per step */
                        /* 黄色填充进度条 */
                        LCD_Fill(pb_x + 1, pb_y + 1,
                                 pb_x + 1 + (u16)((u32)(pb_w - 2) * (u32)prog_i / 79),
                                 pb_y + pb_h - 1, YELLOW);
                        /* 百分比文字 */
                        sprintf(str_buf, "%3d%%", (int)((u32)prog_i * 100 / 79));
                        LCD_ShowString(menu_x + 130, pb_y + pb_h + 8, 60, 16, 16, (u8 *)str_buf);
                    }
                }

                /* 关中断并死循环,此时 IWDG 已接近超时,很快就会复位 */
                __disable_irq();
                while (1)
                    ;
            }
            else if (pin_key == 2 || pin_key == 4) /* KEY1 (-) 或 KEY2 (返回) */
            {
                Menu_State = 1; /* 取消并返回 */
            }
        }
        OSMutexPost(Config_Mutex);

        /* 发送信号重绘，让数值和“竖着的条条”进度柱立刻变化！ */
        OSQPost(UI_Queue, (void *)0xFFFFFFFF);

        /* 根据按键类型做不同的延时 */
        if (pin_key == 3 || pin_key == 4)
        {
            /* 确认/返回键：必须等待所有物理按键完全释放以防穿透与连跳 */
            while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0) == 1 ||
                   GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_3) == 0 ||
                   GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_4) == 0 ||
                   GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_2) == 0)
            {
                OSTimeDly(2); /* 每次延时 20ms 等待松手 */
            }
            OSTimeDly(5); /* 松手后消抖 50ms */

            /* 彻底清除在这期间的所有挂起中断，并重新使能外部中断 */
            EXTI_ClearITPendingBit(EXTI_Line0 | EXTI_Line2 | EXTI_Line3 | EXTI_Line4);
            EXTI->IMR |= (1 << 0) | (1 << 2) | (1 << 3) | (1 << 4);

            /* 彻底排空在轮询与释放期间，中断所记录的所有残留信号量，防穿透 */
            while (OSSemAccept(Key_Sem) > 0)
                ;
            Last_Key = 0xFF;
        }
        else
        {
            OSTimeDly(10); /* 阈值加减调节：长按快滚延时 (100ms) 带来流畅连调体验 */
        }
    }
    else
    {
        /* 无按键按下时，延迟 20ms，降低 CPU 负载并防止高频扫描 */
        OSTimeDly(2);
    }
}

/* ================== 重构提取的 UI 绘制子函数 ================== */

/**
 * @brief  绘制折线图看板
 * @note   在外部 SRAM 显存中离屏绘制网格线、坐标轴、双曲线（温度曲线和光照曲线）以及温度/光照限制线，最后一次性拷贝刷新到物理 LCD。
 * @param  menu_s: 菜单状态
 * @param  limit: 温度限制值
 * @retval 无
 */
static void ui_draw_curve(u8 menu_s, int limit)
{
    u16 grid_x;
    u16 grid_w;
    u16 grid_y;
    u16 grid_h;
    int i;
    int y_limit;
    int step_x;
    int idx1;
    int idx2;
    int t1;
    int t2;
    int x1;
    int x2;
    int y1;
    int y2;

    grid_x = 55;
    grid_w = lcddev.width - 110;
    grid_y = 40;
    grid_h = lcddev.height - 200;

    /* 局部擦除外部 SRAM 中的对应显示区域(始终清空,保证菜单打开时背景干净) */
    UI_Clear_Area(grid_x, grid_y, grid_w + 1, grid_h + 1, BLACK);

    /* 在外部 SRAM 显存中离屏绘制网格背景线 */
    for (i = 0; i <= 6; i++)
    {
        UI_DrawLine(grid_x, grid_y + i * (grid_h / 6), grid_x + grid_w, grid_y + i * (grid_h / 6), GRAY);
    }
    for (i = 0; i <= 8; i++)
    {
        UI_DrawLine(grid_x + i * (grid_w / 8), grid_y, grid_x + i * (grid_w / 8), grid_y + grid_h, GRAY);
    }

    /* 在外部 SRAM 显存中离屏绘制坐标轴边框 */
    UI_DrawLine(grid_x, grid_y, grid_x, grid_y + grid_h, WHITE);
    UI_DrawLine(grid_x, grid_y + grid_h, grid_x + grid_w, grid_y + grid_h, WHITE);
    UI_DrawLine(grid_x + grid_w, grid_y, grid_x + grid_w, grid_y + grid_h, WHITE);

    /* 绘制左侧温度刻度轴 (10 ~ 60 C，直接绘制在 LCD 上，不受显存刷新清空影响) */
    POINT_COLOR = GREEN;
    BACK_COLOR = BLACK;
    for (i = 0; i <= 6; i++)
    {
        sprintf(str_buf, "%2d", 60 - i * 10);
        LCD_ShowString(grid_x - 30, grid_y + i * (grid_h / 6) - 8, 25, 16, 16, (u8 *)str_buf);
    }
    LCD_ShowString(grid_x - 20, grid_y - 22, 40, 16, 16, (u8 *)"T(C)");

    /* 绘制右侧光照刻度轴 (0 ~ 100 %，直接绘制在 LCD 上) */
    POINT_COLOR = YELLOW;
    BACK_COLOR = BLACK;
    for (i = 0; i <= 6; i++)
    {
        sprintf(str_buf, "%3d", 100 - i * 20);
        LCD_ShowString(grid_x + grid_w + 8, grid_y + i * (grid_h / 6) - 8, 30, 16, 16, (u8 *)str_buf);
    }
    LCD_ShowString(grid_x + grid_w - 20, grid_y - 22, 40, 16, 16, (u8 *)"L(%)");

    /* 绘制底部时间坐标偏移 (直接绘制在 LCD 上) */
    POINT_COLOR = WHITE;
    LCD_ShowString(grid_x, grid_y + grid_h + 5, 40, 16, 16, (u8 *)"-40s");
    LCD_ShowString(grid_x + grid_w / 2 - 15, grid_y + grid_h + 5, 40, 16, 16, (u8 *)"-20s");
    LCD_ShowString(grid_x + grid_w - 25, grid_y + grid_h + 5, 30, 16, 16, (u8 *)"0s");

    /* 红色温度阈值线 (在外部 SRAM 中绘制) */
    if (limit >= 100 && limit <= 600)
    {
        y_limit = grid_y + grid_h - (limit - 100) * grid_h / 500;
        if (y_limit >= grid_y && y_limit <= grid_y + grid_h)
        {
            UI_DrawLine(grid_x, y_limit, grid_x + grid_w, y_limit, RED);
        }
    }

    /* 黄色光照阈值虚线 (在外部 SRAM 中绘制) */
    if (GlobalConfig.light_limit <= 100)
    {
        int y_lim_l = grid_y + grid_h - (u32)GlobalConfig.light_limit * grid_h / 100;
        if (y_lim_l >= grid_y && y_lim_l <= grid_y + grid_h)
        {
            for (i = 0; i < grid_w; i += 8)
            {
                UI_DrawLine(grid_x + i, y_lim_l, grid_x + i + 4, y_lim_l, YELLOW);
            }
        }
    }

    step_x = grid_w / PLOT_POINTS_MAX;
    if (step_x == 0)
        step_x = 10;

    /* 绘制绿色温度曲线 (在外部 SRAM 中绘制) */
    for (i = 0; i < (int)History_Count - 1; i++)
    {
        idx1 = (History_Head + i) % PLOT_POINTS_MAX;
        idx2 = (History_Head + i + 1) % PLOT_POINTS_MAX;
        t1 = Temp_History[idx1];
        t2 = Temp_History[idx2];
        x1 = grid_x + i * step_x;
        x2 = grid_x + (i + 1) * step_x;
        y1 = grid_y + grid_h - (t1 - 100) * grid_h / 500;
        y2 = grid_y + grid_h - (t2 - 100) * grid_h / 500;
        if (y1 < grid_y)
            y1 = grid_y;
        if (y1 > grid_y + grid_h)
            y1 = grid_y + grid_h;
        if (y2 < grid_y)
            y2 = grid_y;
        if (y2 > grid_y + grid_h)
            y2 = grid_y + grid_h;
        UI_DrawLine(x1, y1, x2, y2, GREEN);
    }

    /* 绘制黄色光照曲线 (在外部 SRAM 中绘制) */
    for (i = 0; i < (int)History_Count - 1; i++)
    {
        idx1 = (History_Head + i) % PLOT_POINTS_MAX;
        idx2 = (History_Head + i + 1) % PLOT_POINTS_MAX;
        t1 = Light_History[idx1];
        t2 = Light_History[idx2];
        x1 = grid_x + i * step_x;
        x2 = grid_x + (i + 1) * step_x;
        y1 = grid_y + grid_h - (u32)t1 * grid_h / 100;
        y2 = grid_y + grid_h - (u32)t2 * grid_h / 100;
        if (y1 < grid_y)
            y1 = grid_y;
        if (y1 > grid_y + grid_h)
            y1 = grid_y + grid_h;
        if (y2 < grid_y)
            y2 = grid_y;
        if (y2 > grid_y + grid_h)
            y2 = grid_y + grid_h;
        UI_DrawLine(x1, y1, x2, y2, YELLOW);
    }

    /* 画完后将外部 SRAM 数据拷贝并刷新到物理 LCD(始终刷新,保证菜单打开时曲线背景可见) */
    LCD_Flush_Area(grid_x, grid_y, grid_w + 1, grid_h + 1);

    /* 折线图数据气泡(仅待机态显示,触摸点击曲线点后弹出) */
    if (menu_s == 0 && Bubble_Show && Bubble_Idx < History_Count)
    {
        u16 b_step_x = grid_w / PLOT_POINTS_MAX;
        u16 b_idx = (History_Head + Bubble_Idx) % PLOT_POINTS_MAX;
        int b_temp = Temp_History[b_idx];
        u16 b_light = Light_History[b_idx];
        u16 b_pt_x = grid_x + Bubble_Idx * b_step_x;
        int b_pt_y_raw = grid_y + grid_h - (b_temp - 100) * grid_h / 500;
        u16 b_pt_y;
        u16 b_x, b_y;
        int sec_ago;

        if (b_pt_y_raw < grid_y)
            b_pt_y = grid_y;
        else if (b_pt_y_raw > grid_y + grid_h)
            b_pt_y = grid_y + grid_h;
        else
            b_pt_y = (u16)b_pt_y_raw;

        /* 气泡位置:点上方,太靠上则下方 */
        if (b_pt_y > grid_y + 70)
            b_y = b_pt_y - 58;
        else
            b_y = b_pt_y + 15;
        b_x = b_pt_x - 45;
        if (b_x < grid_x)
            b_x = grid_x;
        if (b_x + 100 > grid_x + grid_w)
            b_x = grid_x + grid_w - 100;

        /* 画气泡框白底黑边 */
        LCD_Fill(b_x, b_y, b_x + 99, b_y + 49, WHITE);
        POINT_COLOR = BLACK;
        LCD_DrawLine(b_x, b_y, b_x + 99, b_y);
        LCD_DrawLine(b_x, b_y + 49, b_x + 99, b_y + 49);
        LCD_DrawLine(b_x, b_y, b_x, b_y + 49);
        LCD_DrawLine(b_x + 99, b_y, b_x + 99, b_y + 49);

        /* 气泡文字 */
        BACK_COLOR = WHITE;
        POINT_COLOR = BLACK;
        sprintf(str_buf, "T: %d.%dC", b_temp / 10, b_temp % 10);
        LCD_ShowString(b_x + 6, b_y + 5, 90, 16, 16, (u8 *)str_buf);
        sprintf(str_buf, "L: %d%%", b_light);
        LCD_ShowString(b_x + 6, b_y + 21, 90, 16, 16, (u8 *)str_buf);
        sec_ago = (int)History_Count - 1 - (int)Bubble_Idx;
        if (sec_ago < 0)
            sec_ago = 0;
        sprintf(str_buf, "-%ds", sec_ago);
        LCD_ShowString(b_x + 6, b_y + 37, 90, 12, 12, (u8 *)str_buf);

        /* 画指示点 */
        LCD_Fill(b_pt_x - 2, b_pt_y - 2, b_pt_x + 2, b_pt_y + 2, RED);
    }
}

/**
 * @brief  绘制仪表盘看板
 * @note   在物理 LCD 上绘制四个通道（温度、光照强度、DAC 输出电压、ADC 回读电压）的进度条以及实时数值。
 * @param  data: 指向当前传感器数据结构体的指针
 * @param  limit: 温度限制值
 * @retval 无
 */
static void ui_draw_dashboard(SensorData_t *data, int limit)
{
    u16 bar_w;
    u16 fill_w;
    int temp_val;
    int temp_abs;

    bar_w = lcddev.width - 80;
    POINT_COLOR = WHITE;
    BACK_COLOR = BLACK;

    /* 1. TEMPERATURE GAUGE */
    LCD_ShowString(40, 55, 200, 16, 16, (u8 *)"1. TEMPERATURE (C)");
    temp_val = data->temperature;
    temp_abs = temp_val < 0 ? -temp_val : temp_val;
    /* 尾部增加空格以消除数值位宽减小时的残留像素残影 */
    sprintf(str_buf, "%s%d.%d   ", temp_val < 0 ? "-" : "", temp_abs / 10, temp_abs % 10);
    LCD_ShowString(lcddev.width - 120, 55, 80, 16, 16, (u8 *)str_buf);

    if (data->temperature < 100)
        fill_w = 0;
    else if (data->temperature > 600)
        fill_w = bar_w;
    else
        fill_w = (u16)((data->temperature - 100) * bar_w / 500);

    LCD_Fill(40, 75, 40 + fill_w - 1, 95 - 1, (data->temperature > limit) ? RED : GREEN);
    if (fill_w < bar_w)
        LCD_Fill(40 + fill_w, 75, 40 + bar_w - 1, 95 - 1, DARKBLUE);

    /* 2. LIGHT STRENGTH GAUGE */
    LCD_ShowString(40, 125, 200, 16, 16, (u8 *)"2. LIGHT STRENGTH (%)");
    /* 尾部增加空格 */
    sprintf(str_buf, "%d%%   ", data->light);
    LCD_ShowString(lcddev.width - 120, 125, 80, 16, 16, (u8 *)str_buf);

    fill_w = (u16)((u32)data->light * bar_w / 100);
    if (fill_w > bar_w)
        fill_w = bar_w;

    LCD_Fill(40, 145, 40 + fill_w - 1, 165 - 1, (data->light > GlobalConfig.light_limit) ? RED : YELLOW);
    if (fill_w < bar_w)
        LCD_Fill(40 + fill_w, 145, 40 + bar_w - 1, 165 - 1, DARKBLUE);

    /* 3. DAC OUTPUT GAUGE (PA4) */
    LCD_ShowString(40, 195, 200, 16, 16, (u8 *)"3. DAC OUTPUT (PA4)");
    /* 尾部增加空格，并且将颜色由暗沉的蓝色更换为青色 */
    sprintf(str_buf, "%d.%02dV  ", data->dac_vol / 1000, (data->dac_vol % 1000) / 10);
    LCD_ShowString(lcddev.width - 120, 195, 80, 16, 16, (u8 *)str_buf);

    fill_w = (u16)((u32)data->dac_vol * bar_w / 3300);
    if (fill_w > bar_w)
        fill_w = bar_w;

    LCD_Fill(40, 215, 40 + fill_w - 1, 235 - 1, CYAN);
    if (fill_w < bar_w)
        LCD_Fill(40 + fill_w, 215, 40 + bar_w - 1, 235 - 1, DARKBLUE);

    /* 4. ADC LOOPBACK GAUGE (PA5) */
    LCD_ShowString(40, 265, 200, 16, 16, (u8 *)"4. ADC LOOPBACK (PA5)");
    /* 尾部增加空格 */
    sprintf(str_buf, "%d.%02dV  ", data->adc_vol / 1000, (data->adc_vol % 1000) / 10);
    LCD_ShowString(lcddev.width - 120, 265, 80, 16, 16, (u8 *)str_buf);

    fill_w = (u16)((u32)data->adc_vol * bar_w / 3300);
    if (fill_w > bar_w)
        fill_w = bar_w;

    LCD_Fill(40, 285, 40 + fill_w - 1, 305 - 1, MAGENTA);
    if (fill_w < bar_w)
        LCD_Fill(40 + fill_w, 285, 40 + bar_w - 1, 305 - 1, DARKBLUE);

    /* ====== DAC 电压触摸调节区 (填充下方空白) ====== */
    /* 分区标题 */
    POINT_COLOR = WHITE;
    BACK_COLOR = BLACK;
    LCD_ShowString(40, 325, 240, 16, 16, (u8 *)"DAC VOLTAGE CONTROL");

    /* 当前模式与 ADC 窗口状态 */
    sprintf(str_buf, "Mode: %s  DAC: %d.%02dV  Fix: %d.%02dV",
            Dac_Mode == 0 ? "SIN" : "FIX",
            data->dac_vol / 1000, (data->dac_vol % 1000) / 10,
            Dac_Fix_Mv / 1000, (Dac_Fix_Mv % 1000) / 10);
    LCD_ShowString(40, 345, 400, 16, 16, (u8 *)str_buf);

    sprintf(str_buf, "ADC Window: %d.%02dV ~ %d.%02dV  %s",
            Adc_Win_Low / 1000, (Adc_Win_Low % 1000) / 10,
            Adc_Win_High / 1000, (Adc_Win_High % 1000) / 10,
            Adc_Win_Alarm ? "** ALARM **" : "OK");
    POINT_COLOR = Adc_Win_Alarm ? RED : GRAY;
    LCD_ShowString(40, 362, 400, 16, 16, (u8 *)str_buf);

    /* 4 个触摸按钮: DAC- / DAC+ / SIN / FIX */
    /* DAC- (橙色) */
    LCD_Fill(DAC_BTN_DEC_X1, DAC_BTN_Y1, DAC_BTN_DEC_X2, DAC_BTN_Y2, 0xFD20);
    POINT_COLOR = WHITE;
    BACK_COLOR = 0xFD20;
    LCD_ShowString(DAC_BTN_DEC_X1 + 18, DAC_BTN_Y1 + 17, 80, 24, 24, (u8 *)"DAC-");

    /* DAC+ (青色) */
    LCD_Fill(DAC_BTN_INC_X1, DAC_BTN_Y1, DAC_BTN_INC_X2, DAC_BTN_Y2, CYAN);
    POINT_COLOR = BLACK;
    BACK_COLOR = CYAN;
    LCD_ShowString(DAC_BTN_INC_X1 + 18, DAC_BTN_Y1 + 17, 80, 24, 24, (u8 *)"DAC+");

    /* SIN (正弦波, 选中=绿色高亮, 未选=灰色) */
    LCD_Fill(DAC_BTN_SIN_X1, DAC_BTN_Y1, DAC_BTN_SIN_X2, DAC_BTN_Y2,
             Dac_Mode == 0 ? GREEN : GRAY);
    POINT_COLOR = WHITE;
    BACK_COLOR = Dac_Mode == 0 ? GREEN : GRAY;
    LCD_ShowString(DAC_BTN_SIN_X1 + 28, DAC_BTN_Y1 + 17, 60, 24, 24, (u8 *)"SIN");

    /* FIX (固定电压, 选中=黄色高亮, 未选=灰色) */
    LCD_Fill(DAC_BTN_FIX_X1, DAC_BTN_Y1, DAC_BTN_FIX_X2, DAC_BTN_Y2,
             Dac_Mode == 1 ? YELLOW : GRAY);
    POINT_COLOR = BLACK;
    BACK_COLOR = Dac_Mode == 1 ? YELLOW : GRAY;
    LCD_ShowString(DAC_BTN_FIX_X1 + 30, DAC_BTN_Y1 + 17, 60, 24, 24, (u8 *)"FIX");

    /* 按钮下方提示 */
    POINT_COLOR = GRAY;
    BACK_COLOR = BLACK;
    LCD_ShowString(40, 455, 440, 16, 16,
                   (u8 *)"DAC-/+ : 0.1V step   SIN : auto wave   FIX : hold voltage");
}

/**
 * @brief  绘制串口通信终端日志看板
 * @note   在屏幕顶部绘制 4 个筛选按钮(ALL/TX/RX/SYS),下方实时滚动显示最近 20 条日志,
 *         按 TX/RX/SYS 分类着色(绿/青/黄),支持触屏点击切换筛选模式。
 * @param  force_clear: 是否强制重绘框体背景和标题顶栏
 * @retval 无
 */
static void ui_draw_terminal_logs(u8 force_clear)
{
    u16 box_x;
    u16 box_w;
    u16 box_y;
    u16 box_h;
    int draw_y;
    u8 temp_log_count;
    u8 temp_log_head;
    int i;
    int log_idx;
    OS_CPU_SR cpu_sr;
    u8 show_cnt;
    u8 cat;
    u16 cat_color;
    static u8 last_filter = 0xFF;
    static u16 last_log_gen = 0xFFFF;
    static u8 last_filter_for_content = 0xFF;
    static s8 last_scroll_for_content = -1;
    u8 filt;
    u8 need_content_redraw;

    box_x = 20;
    box_w = lcddev.width - 40;
    box_y = 82;
    box_h = lcddev.height - 175;

    filt = Log_Filter;

    /* 筛选按钮栏 (force_clear 或筛选模式变化时重绘) */
    if (force_clear || filt != last_filter)
    {
        last_filter = filt;
        LCD_Fill(20, LOGFILT_Y1, lcddev.width - 21, LOGFILT_Y2, BLACK);

        /* ALL 按钮 */
        LCD_Fill(LOGFILT_ALL_X1, LOGFILT_Y1, LOGFILT_ALL_X2, LOGFILT_Y2,
                 filt == 0 ? DARKBLUE : GRAY);
        POINT_COLOR = (filt == 0) ? YELLOW : WHITE;
        BACK_COLOR = (filt == 0) ? DARKBLUE : GRAY;
        LCD_ShowString(LOGFILT_ALL_X1 + 25, LOGFILT_Y1 + 10, 80, 16, 16, (u8 *)"ALL");

        /* TX 按钮 */
        LCD_Fill(LOGFILT_TX_X1, LOGFILT_Y1, LOGFILT_TX_X2, LOGFILT_Y2,
                 filt == 1 ? DARKBLUE : GRAY);
        POINT_COLOR = (filt == 1) ? YELLOW : WHITE;
        BACK_COLOR = (filt == 1) ? DARKBLUE : GRAY;
        LCD_ShowString(LOGFILT_TX_X1 + 30, LOGFILT_Y1 + 10, 80, 16, 16, (u8 *)"TX");

        /* RX 按钮 */
        LCD_Fill(LOGFILT_RX_X1, LOGFILT_Y1, LOGFILT_RX_X2, LOGFILT_Y2,
                 filt == 2 ? DARKBLUE : GRAY);
        POINT_COLOR = (filt == 2) ? YELLOW : WHITE;
        BACK_COLOR = (filt == 2) ? DARKBLUE : GRAY;
        LCD_ShowString(LOGFILT_RX_X1 + 30, LOGFILT_Y1 + 10, 80, 16, 16, (u8 *)"RX");

        /* SYS 按钮 */
        LCD_Fill(LOGFILT_SYS_X1, LOGFILT_Y1, LOGFILT_SYS_X2, LOGFILT_Y2,
                 filt == 3 ? DARKBLUE : GRAY);
        POINT_COLOR = (filt == 3) ? YELLOW : WHITE;
        BACK_COLOR = (filt == 3) ? DARKBLUE : GRAY;
        LCD_ShowString(LOGFILT_SYS_X1 + 25, LOGFILT_Y1 + 10, 80, 16, 16, (u8 *)"SYS");
    }

    if (force_clear)
    {
        LCD_Fill(box_x, box_y, box_x + box_w - 1, box_y + box_h - 1, BLACK);
        POINT_COLOR = GRAY;
        LCD_DrawLine(box_x, box_y, box_x + box_w - 1, box_y);
        LCD_DrawLine(box_x, box_y + box_h - 1, box_x + box_w - 1, box_y + box_h - 1);
        LCD_DrawLine(box_x, box_y, box_x, box_y + box_h - 1);
        LCD_DrawLine(box_x + box_w - 1, box_y, box_x + box_w - 1, box_y + box_h - 1);
    }

    /* 判断是否需要重绘日志内容:
       仅在 force_clear/筛选变化/滚动变化/有新日志 时才重绘20行文本。
       原先每250ms都全量重绘(耗时150ms+), 导致touch_task(prio 8)被饿死,
       日志页触屏完全失效。 */
    need_content_redraw = (force_clear ||
                           filt != last_filter_for_content ||
                           Log_Scroll_Offset != last_scroll_for_content ||
                           Log_Gen != last_log_gen);
    if (!need_content_redraw)
        return; /* 无变化, 跳过日志内容重绘, 释放CPU给touch_task */

    /* 筛选变化时清除内容框, 避免旧日志残留为灰色块 */
    if (!force_clear && filt != last_filter_for_content)
    {
        /* 清除从筛选按钮底部到内容框底部的整片区域(含按钮和框之间的间隙) */
        LCD_Fill(0, LOGFILT_Y2 + 1, lcddev.width - 1, box_y + box_h - 1, BLACK);
        POINT_COLOR = GRAY;
        LCD_DrawLine(box_x, box_y, box_x + box_w - 1, box_y);
        LCD_DrawLine(box_x, box_y + box_h - 1, box_x + box_w - 1, box_y + box_h - 1);
        LCD_DrawLine(box_x, box_y, box_x, box_y + box_h - 1);
        LCD_DrawLine(box_x + box_w - 1, box_y, box_x + box_w - 1, box_y + box_h - 1);
    }

    last_filter_for_content = filt;
    last_scroll_for_content = Log_Scroll_Offset;
    last_log_gen = Log_Gen;

    /* 临界区:提取最多 20 条符合筛选条件的日志(最新在前) */
    cpu_sr = 0;
    OS_ENTER_CRITICAL();
    temp_log_count = Log_Count;
    temp_log_head = Log_Head;

    show_cnt = 0;
    /* 从最新到最老遍历,先跳过 Log_Scroll_Offset 条匹配的日志,再收集 20 条 */
    {
        int collected = 0;
        int skipped = 0;
        int scan_i;
        int total_matched = 0;
        u8 match;
        /* 先统计匹配总数用于限制 offset */
        for (scan_i = (int)temp_log_count - 1; scan_i >= 0; scan_i--)
        {
            log_idx = (temp_log_head + scan_i) % LOG_LINES_MAX;
            cat = Comm_Log_Cat[log_idx];
            if (filt == 0)
                match = 1;
            else if (filt == 1)
                match = (cat == LOG_CAT_TX) ? 1 : 0;
            else if (filt == 2)
                match = (cat == LOG_CAT_RX) ? 1 : 0;
            else
                match = (cat == LOG_CAT_SYS) ? 1 : 0;
            if (match)
                total_matched++;
        }
        /* 限制 offset 不超过可滚动范围 */
        if (Log_Scroll_Offset > 0 && total_matched <= 20)
        {
            Log_Scroll_Offset = 0;
        }
        else if ((int)Log_Scroll_Offset > total_matched - 20)
        {
            Log_Scroll_Offset = (s8)((total_matched > 20) ? (total_matched - 20) : 0);
        }

        for (scan_i = (int)temp_log_count - 1; scan_i >= 0; scan_i--)
        {
            log_idx = (temp_log_head + scan_i) % LOG_LINES_MAX;
            cat = Comm_Log_Cat[log_idx];
            if (filt == 0)
                match = 1; /* ALL */
            else if (filt == 1)
                match = (cat == LOG_CAT_TX) ? 1 : 0;
            else if (filt == 2)
                match = (cat == LOG_CAT_RX) ? 1 : 0;
            else
                match = (cat == LOG_CAT_SYS) ? 1 : 0;
            if (match)
            {
                if (skipped < (int)Log_Scroll_Offset)
                {
                    skipped++;
                    continue;
                }
                if (collected < 20)
                {
                    temp_log_cat[collected] = cat;
                    strncpy(temp_logs[collected], Comm_Logs[log_idx], 79);
                    temp_logs[collected][79] = '\0';
                    collected++;
                }
                else
                {
                    break;
                }
            }
        }
        show_cnt = (u8)collected;
    }
    OS_EXIT_CRITICAL();

    /* 滚动位置指示器 */
    if (Log_Scroll_Offset > 0)
    {
        POINT_COLOR = MAGENTA;
        BACK_COLOR = BLACK;
        sprintf(str_buf, "^ %d older", (int)Log_Scroll_Offset);
        LCD_ShowString(box_x + box_w - 110, box_y + 6, 100, 16, 16, (u8 *)str_buf);
    }
    else
    {
        LCD_Fill(box_x + box_w - 110, box_y + 6, box_x + box_w - 6, box_y + 22, BLACK);
    }

    /* 从上往下绘制(最新在最上方) */
    draw_y = box_y + 6;
    BACK_COLOR = BLACK;
    for (i = 0; i < (int)show_cnt; i++)
    {
        char *p_log = temp_logs[i];
        cat = temp_log_cat[i];
        if (cat == LOG_CAT_TX)
            cat_color = GREEN;
        else if (cat == LOG_CAT_RX)
            cat_color = CYAN;
        else
            cat_color = YELLOW;
        POINT_COLOR = cat_color;

        /* 截断到 54 字符(适配日志框宽度) */
        if (strlen(p_log) > 54)
        {
            strncpy(str_buf, p_log, 54);
            str_buf[54] = '\0';
        }
        else
        {
            strcpy(str_buf, p_log);
        }
        /* 补空格覆盖旧内容 */
        {
            int sl = (int)strlen(str_buf);
            while (sl < 54)
            {
                str_buf[sl] = ' ';
                sl++;
            }
            str_buf[sl] = '\0';
        }
        LCD_ShowString(box_x + 6, draw_y, box_w - 12, 16, 16, (u8 *)str_buf);
        draw_y += 24;
        /* 每5行让出一次CPU给touch_task(5ms), 防止长时间绘制饿死触摸任务 */
        if ((i + 1) % 5 == 0)
            OSTimeDly(1);
    }

    /* 擦除剩余空白 */
    if (draw_y < box_y + box_h - 2)
    {
        LCD_Fill(box_x + 1, draw_y, box_x + box_w - 2, box_y + box_h - 2, BLACK);
    }
}

/**
 * @brief  绘制电子钟页面 (大7段数码管 + 弹窗校时 + 多闹钟 + 倒计时)
 * @param  force_clear: 是否强制重绘整个页面背景
 */
static void ui_draw_clock(u8 force_clear)
{
    RTC_TimeTypeDef rtc_t;
    RTC_DateTypeDef rtc_d;
    char time_str[16];
    static u8 last_sec = 0xFF;
    static u8 last_popup = 0xFF;
    static u8 last_timer_m = 0xFF;
    static u8 last_timer_h = 0xFF;
    static u8 last_timer_s = 0xFF;
    static u8 last_alm_en[3] = {0xFF, 0xFF, 0xFF};
    u8 need_full;
    u8 i;
    u16 field_color;
    char pop_str[16];

    RTC_GetTime(RTC_Format_BIN, &rtc_t);
    RTC_GetDate(RTC_Format_BIN, &rtc_d);

    /* 弹窗状态变化时强制全屏重绘 */
    need_full = force_clear;
    if (Clock_Popup != last_popup)
    {
        need_full = 1;
        last_popup = Clock_Popup;
        UI_Redraw_Seq++; /* 标记全屏重绘, 使反馈点保存的像素失效 */
    }

    /* ====== 弹窗模式 ====== */
    if (Clock_Popup != 0)
    {
        if (need_full)
        {
            /* 半透明遮罩 */
            LCD_Fill(0, 0, lcddev.width - 1, lcddev.height - 91, 0x4208);
            /* 弹窗框体 */
            LCD_Fill(POPUP_X, POPUP_Y, POPUP_X + POPUP_W - 1, POPUP_Y + POPUP_H - 1, DARKBLUE);
            POINT_COLOR = WHITE;
            LCD_DrawLine(POPUP_X, POPUP_Y, POPUP_X + POPUP_W - 1, POPUP_Y);
            LCD_DrawLine(POPUP_X, POPUP_Y + POPUP_H - 1, POPUP_X + POPUP_W - 1, POPUP_Y + POPUP_H - 1);
            LCD_DrawLine(POPUP_X, POPUP_Y, POPUP_X, POPUP_Y + POPUP_H - 1);
            LCD_DrawLine(POPUP_X + POPUP_W - 1, POPUP_Y, POPUP_X + POPUP_W - 1, POPUP_Y + POPUP_H - 1);
            /* 标题栏 */
            LCD_Fill(POPUP_X + 1, POPUP_Y + 1, POPUP_X + POPUP_W - 2, POPUP_Y + POPUP_TITLE_H, BLUE);
            POINT_COLOR = WHITE;
            BACK_COLOR = BLUE;
            if (Clock_Popup == 1)
                LCD_ShowString(POPUP_X + 140, POPUP_Y + 12, 120, 16, 16, (u8 *)"SET TIME");
            else if (Clock_Popup == 2)
                LCD_ShowString(POPUP_X + 140, POPUP_Y + 12, 120, 16, 16, (u8 *)"SET DATE");
            else if (Clock_Popup == 3)
            {
                sprintf(str_buf, "SET ALARM %d", Popup_Alarm_Idx + 1);
                LCD_ShowString(POPUP_X + 130, POPUP_Y + 12, 140, 16, 16, (u8 *)str_buf);
            }
            else
                LCD_ShowString(POPUP_X + 140, POPUP_Y + 12, 120, 16, 16, (u8 *)"SET TIMER");

            BACK_COLOR = DARKBLUE;
            if (Clock_Popup == 3)
            {
                /* 闹钟弹窗: < / > 切换 + ON/OFF 开关 */
                LCD_Fill(POPUP_PREV_X, POPUP_SWITCH_Y, POPUP_PREV_X + POPUP_PREV_W - 1, POPUP_SWITCH_Y + POPUP_SWITCH_H - 1, GRAY);
                LCD_Fill(POPUP_NEXT_X, POPUP_SWITCH_Y, POPUP_NEXT_X + POPUP_NEXT_W - 1, POPUP_SWITCH_Y + POPUP_SWITCH_H - 1, GRAY);
                POINT_COLOR = YELLOW;
                BACK_COLOR = GRAY;
                LCD_ShowString(POPUP_PREV_X + 15, POPUP_SWITCH_Y + 14, 30, 16, 16, (u8 *)"<");
                LCD_ShowString(POPUP_NEXT_X + 15, POPUP_SWITCH_Y + 14, 30, 16, 16, (u8 *)">");
                {
                    u16 swx = POPUP_X + 110;
                    LCD_Fill(swx, POPUP_SWITCH_Y, swx + 80, POPUP_SWITCH_Y + POPUP_SWITCH_H - 1,
                             Alm_En[Popup_Alarm_Idx] ? GREEN : RED);
                    POINT_COLOR = WHITE;
                    BACK_COLOR = Alm_En[Popup_Alarm_Idx] ? GREEN : RED;
                    LCD_ShowString(swx + 18, POPUP_SWITCH_Y + 14, 50, 16, 16,
                                   (u8 *)(Alm_En[Popup_Alarm_Idx] ? "ON" : "OFF"));
                }
                /* 闹钟也显示 +/- 按钮用于调节时间 */
                LCD_Fill(POPUP_MINUS_X, POPUP_ADJ_Y, POPUP_MINUS_X + POPUP_MINUS_W - 1, POPUP_ADJ_Y + POPUP_ADJ_H - 1, GRAY);
                LCD_Fill(POPUP_PLUS_X, POPUP_ADJ_Y, POPUP_PLUS_X + POPUP_PLUS_W - 1, POPUP_ADJ_Y + POPUP_ADJ_H - 1, GRAY);
                POINT_COLOR = YELLOW;
                BACK_COLOR = GRAY;
                LCD_ShowString(POPUP_MINUS_X + 30, POPUP_ADJ_Y + 14, 30, 16, 16, (u8 *)"-");
                LCD_ShowString(POPUP_PLUS_X + 30, POPUP_ADJ_Y + 14, 30, 16, 16, (u8 *)"+");
            }
            else
            {
                LCD_Fill(POPUP_MINUS_X, POPUP_ADJ_Y, POPUP_MINUS_X + POPUP_MINUS_W - 1, POPUP_ADJ_Y + POPUP_ADJ_H - 1, GRAY);
                LCD_Fill(POPUP_PLUS_X, POPUP_ADJ_Y, POPUP_PLUS_X + POPUP_PLUS_W - 1, POPUP_ADJ_Y + POPUP_ADJ_H - 1, GRAY);
                POINT_COLOR = YELLOW;
                BACK_COLOR = GRAY;
                LCD_ShowString(POPUP_MINUS_X + 30, POPUP_ADJ_Y + 14, 30, 16, 16, (u8 *)"-");
                LCD_ShowString(POPUP_PLUS_X + 30, POPUP_ADJ_Y + 14, 30, 16, 16, (u8 *)"+");
            }

            /* OK / Cancel 按钮 */
            LCD_Fill(POPUP_OK_X, POPUP_OK_Y, POPUP_OK_X + POPUP_OK_W - 1, POPUP_OK_Y + POPUP_OK_H - 1, GREEN);
            LCD_Fill(POPUP_CANCEL_X, POPUP_OK_Y, POPUP_CANCEL_X + POPUP_CANCEL_W - 1, POPUP_OK_Y + POPUP_OK_H - 1, RED);
            POINT_COLOR = WHITE;
            BACK_COLOR = GREEN;
            LCD_ShowString(POPUP_OK_X + 45, POPUP_OK_Y + 14, 50, 16, 16, (u8 *)"OK");
            BACK_COLOR = RED;
            LCD_ShowString(POPUP_CANCEL_X + 30, POPUP_OK_Y + 14, 80, 16, 16, (u8 *)"CANCEL");

            POINT_COLOR = CYAN;
            BACK_COLOR = DARKBLUE;
            LCD_ShowString(POPUP_X + 30, POPUP_Y + 320, 340, 16, 16,
                           (u8 *)"Tap field to select. Swipe or +/- to adjust.");
        }

        /* 弹窗内大字体数字 (每次刷新都重绘, 替代数码管更清晰) */
        LCD_Fill(POPUP_X + 10, POPUP_FIELD_Y, POPUP_X + POPUP_W - 11, POPUP_FIELD_Y + POPUP_FIELD_H, DARKBLUE);
        BACK_COLOR = DARKBLUE;

        if (Clock_Popup == 1 || Clock_Popup == 2)
        {
            /* 3 字段: HH:MM:SS 或 YY-MM-DD, 使用 24px 大字体 */
            const char *sep = (Clock_Popup == 1) ? ":" : "-";
            /* 字段 0 */
            field_color = (Popup_Field == 0) ? YELLOW : WHITE;
            if (Clock_Popup == 1)
                sprintf(pop_str, "%02d", Pop_H);
            else
                sprintf(pop_str, "%02d", Pop_Y);
            POINT_COLOR = field_color;
            LCD_ShowString(POP3_START_X, POPUP_FIELD_Y, POPFIELD_W, POPFIELD_H, POPFIELD_FONT, (u8 *)pop_str);
            /* 选中字段下方画黄色下划线 */
            if (Popup_Field == 0)
            {
                POINT_COLOR = YELLOW;
                LCD_DrawLine(POP3_START_X, POPUP_FIELD_Y + POPFIELD_H, POP3_START_X + POPFIELD_W - 1, POPUP_FIELD_Y + POPFIELD_H);
            }
            /* 分隔符 1 */
            POINT_COLOR = WHITE;
            LCD_ShowString(POP3_COL1_X, POPUP_FIELD_Y, 20, POPFIELD_H, POPFIELD_FONT, (u8 *)sep);
            /* 字段 1 */
            field_color = (Popup_Field == 1) ? YELLOW : WHITE;
            if (Clock_Popup == 1)
                sprintf(pop_str, "%02d", Pop_M);
            else
                sprintf(pop_str, "%02d", Pop_Mo);
            POINT_COLOR = field_color;
            LCD_ShowString(POP3_FLD1_X, POPUP_FIELD_Y, POPFIELD_W, POPFIELD_H, POPFIELD_FONT, (u8 *)pop_str);
            if (Popup_Field == 1)
            {
                POINT_COLOR = YELLOW;
                LCD_DrawLine(POP3_FLD1_X, POPUP_FIELD_Y + POPFIELD_H, POP3_FLD1_X + POPFIELD_W - 1, POPUP_FIELD_Y + POPFIELD_H);
            }
            /* 分隔符 2 */
            POINT_COLOR = WHITE;
            LCD_ShowString(POP3_COL2_X, POPUP_FIELD_Y, 20, POPFIELD_H, POPFIELD_FONT, (u8 *)sep);
            /* 字段 2 */
            field_color = (Popup_Field == 2) ? YELLOW : WHITE;
            if (Clock_Popup == 1)
                sprintf(pop_str, "%02d", Pop_S);
            else
                sprintf(pop_str, "%02d", Pop_D);
            POINT_COLOR = field_color;
            LCD_ShowString(POP3_FLD2_X, POPUP_FIELD_Y, POPFIELD_W, POPFIELD_H, POPFIELD_FONT, (u8 *)pop_str);
            if (Popup_Field == 2)
            {
                POINT_COLOR = YELLOW;
                LCD_DrawLine(POP3_FLD2_X, POPUP_FIELD_Y + POPFIELD_H, POP3_FLD2_X + POPFIELD_W - 1, POPUP_FIELD_Y + POPFIELD_H);
            }
        }
        else
        {
            /* 2 字段: HH:MM (闹钟) 或 MM:SS (倒计时), 24px 大字体 */
            /* 字段 0 */
            field_color = (Popup_Field == 0) ? YELLOW : WHITE;
            if (Clock_Popup == 3)
                sprintf(pop_str, "%02d", Alm_H[Popup_Alarm_Idx]);
            else
                sprintf(pop_str, "%02d", Pop_TH);
            POINT_COLOR = field_color;
            LCD_ShowString(POP2_START_X, POPUP_FIELD_Y, POPFIELD_W, POPFIELD_H, POPFIELD_FONT, (u8 *)pop_str);
            if (Popup_Field == 0)
            {
                POINT_COLOR = YELLOW;
                LCD_DrawLine(POP2_START_X, POPUP_FIELD_Y + POPFIELD_H, POP2_START_X + POPFIELD_W - 1, POPUP_FIELD_Y + POPFIELD_H);
            }
            /* 冒号 */
            POINT_COLOR = WHITE;
            LCD_ShowString(POP2_COL1_X, POPUP_FIELD_Y, 20, POPFIELD_H, POPFIELD_FONT, (u8 *)":");
            /* 字段 1 */
            field_color = (Popup_Field == 1) ? YELLOW : WHITE;
            if (Clock_Popup == 3)
                sprintf(pop_str, "%02d", Alm_M[Popup_Alarm_Idx]);
            else
                sprintf(pop_str, "%02d", Pop_TM);
            POINT_COLOR = field_color;
            LCD_ShowString(POP2_FLD1_X, POPUP_FIELD_Y, POPFIELD_W, POPFIELD_H, POPFIELD_FONT, (u8 *)pop_str);
            if (Popup_Field == 1)
            {
                POINT_COLOR = YELLOW;
                LCD_DrawLine(POP2_FLD1_X, POPUP_FIELD_Y + POPFIELD_H, POP2_FLD1_X + POPFIELD_W - 1, POPUP_FIELD_Y + POPFIELD_H);
            }
        }
        return; /* 弹窗模式不绘制主视图 */
    }

    /* ====== 主视图 ====== */
    if (need_full)
    {
        LCD_Fill(0, 0, lcddev.width - 1, lcddev.height - 91, BLACK);

        /* 4 大功能按钮 (2x2 网格) */
        LCD_Fill(CLK_BTN_L_X, CLK_BTN_ROW1_Y, CLK_BTN_L_X + CLK_BTN_W - 1, CLK_BTN_ROW1_Y + CLK_BTN_H - 1, DARKBLUE);
        LCD_Fill(CLK_BTN_R_X, CLK_BTN_ROW1_Y, CLK_BTN_R_X + CLK_BTN_W - 1, CLK_BTN_ROW1_Y + CLK_BTN_H - 1, DARKBLUE);
        LCD_Fill(CLK_BTN_L_X, CLK_BTN_ROW2_Y, CLK_BTN_L_X + CLK_BTN_W - 1, CLK_BTN_ROW2_Y + CLK_BTN_H - 1, DARKBLUE);
        LCD_Fill(CLK_BTN_R_X, CLK_BTN_ROW2_Y, CLK_BTN_R_X + CLK_BTN_W - 1, CLK_BTN_ROW2_Y + CLK_BTN_H - 1, DARKBLUE);
        POINT_COLOR = WHITE;
        BACK_COLOR = DARKBLUE;
        LCD_ShowString(CLK_BTN_L_X + 40, CLK_BTN_ROW1_Y + 20, 100, 16, 16, (u8 *)"SET TIME");
        LCD_ShowString(CLK_BTN_R_X + 40, CLK_BTN_ROW1_Y + 20, 100, 16, 16, (u8 *)"SET DATE");
        LCD_ShowString(CLK_BTN_L_X + 35, CLK_BTN_ROW2_Y + 20, 110, 16, 16, (u8 *)"SET ALARM");
        LCD_ShowString(CLK_BTN_R_X + 50, CLK_BTN_ROW2_Y + 20, 80, 16, 16, (u8 *)"TIMER");

        /* 闹钟列表标题 */
        POINT_COLOR = CYAN;
        BACK_COLOR = BLACK;
        LCD_ShowString(CLK_ALM_LIST_X, CLK_ALM_LIST_Y - 22, 100, 16, 16, (u8 *)"Alarms:");

        /* 倒计时标题 */
        LCD_ShowString(30, CLK_TIMER_Y - 22, 100, 16, 16, (u8 *)"Timer:");

        /* 操作提示 */
        POINT_COLOR = GRAY;
        LCD_ShowString(30, 560, 420, 16, 16, (u8 *)"Tap buttons to set. Tap alarm row to toggle.");
        LCD_ShowString(30, 580, 420, 16, 16, (u8 *)"Swipe left/right to switch pages.");

        for (i = 0; i < MAX_ALARMS; i++)
            last_alm_en[i] = 0xFF;
    }

    /* 大字体时间显示 (每秒更新, 2x 缩放 24px → 等效 48px) */
    if (rtc_t.RTC_Seconds != last_sec || need_full)
    {
        last_sec = rtc_t.RTC_Seconds;
        sprintf(time_str, "%02d:%02d:%02d", rtc_t.RTC_Hours, rtc_t.RTC_Minutes, rtc_t.RTC_Seconds);
        /* 清除时间区域 (8 字符 × 24px = 192px 宽, 48px 高) */
        LCD_Fill(144, 30, 144 + 192 - 1, 30 + 48 - 1, BLACK);
        LCD_ShowString_2x(144, 30, (u8 *)time_str, CYAN, BLACK);

        /* 日期显示 (24号字体, 无星期) */
        sprintf(str_buf, "20%02d-%02d-%02d", rtc_d.RTC_Year, rtc_d.RTC_Month, rtc_d.RTC_Date);
        POINT_COLOR = WHITE;
        BACK_COLOR = BLACK;
        LCD_ShowString((lcddev.width - 120) / 2, 90, 120, 24, 24, (u8 *)str_buf);
    }

    /* 闹钟列表 (使能状态变化时更新) */
    for (i = 0; i < MAX_ALARMS; i++)
    {
        if (need_full || last_alm_en[i] != Alm_En[i])
        {
            last_alm_en[i] = Alm_En[i];
            {
                u16 ay = CLK_ALM_LIST_Y + i * CLK_ALM_LIST_H;
                LCD_Fill(CLK_ALM_LIST_X, ay, CLK_ALM_LIST_X + CLK_ALM_LIST_W - 1, ay + CLK_ALM_LIST_H - 2, BLACK);
                sprintf(str_buf, "A%d: %s  %02d:%02d", i + 1,
                        Alm_En[i] ? "ON " : "OFF", Alm_H[i], Alm_M[i]);
                POINT_COLOR = Alm_En[i] ? GREEN : GRAY;
                BACK_COLOR = BLACK;
                LCD_ShowString(CLK_ALM_LIST_X + 20, ay + 8, 200, 16, 16, (u8 *)str_buf);
                LCD_Fill(CLK_ALM_LIST_X + 250, ay + 8, CLK_ALM_LIST_X + 262, ay + 20,
                         Alm_En[i] ? GREEN : RED);
            }
        }
    }

    /* 倒计时显示 */
    {
        u8 ts_h = (u8)(Timer_Remain_Sec / 3600);
        u8 ts_m = (u8)((Timer_Remain_Sec % 3600) / 60);
        u8 ts_s = (u8)(Timer_Remain_Sec % 60);
        if (need_full || ts_s != last_timer_s || ts_m != last_timer_m || ts_h != last_timer_h)
        {
            last_timer_s = ts_s;
            last_timer_m = ts_m;
            last_timer_h = ts_h;
            LCD_Fill(30, CLK_TIMER_Y, 240, CLK_TIMER_Y + CLK_TIMER_H - 1, BLACK);
            sprintf(str_buf, "%02d:%02d:%02d", ts_h, ts_m, ts_s);
            POINT_COLOR = Timer_Running ? YELLOW : (Timer_Remain_Sec == 0 ? RED : WHITE);
            BACK_COLOR = BLACK;
            LCD_ShowString(30, CLK_TIMER_Y + 12, 200, 24, 24, (u8 *)str_buf);
        }
        /* Start/Pause 和 Reset 按钮 */
        LCD_Fill(250, CLK_TIMER_Y, 340, CLK_TIMER_Y + CLK_TIMER_H - 1, DARKBLUE);
        LCD_Fill(350, CLK_TIMER_Y, 440, CLK_TIMER_Y + CLK_TIMER_H - 1, DARKBLUE);
        POINT_COLOR = YELLOW;
        BACK_COLOR = DARKBLUE;
        if (Timer_Running)
            LCD_ShowString(265, CLK_TIMER_Y + 12, 80, 16, 16, (u8 *)"PAUSE");
        else
            LCD_ShowString(260, CLK_TIMER_Y + 12, 80, 16, 16, (u8 *)"START");
        LCD_ShowString(365, CLK_TIMER_Y + 12, 80, 16, 16, (u8 *)"RESET");
    }
}

/**
 * @brief  绘制屏幕底部状态栏
 * @note   在屏幕底部区域显示系统时间、温度与光照实测值与限值，以及 LED1、蜂鸣器消音状态和当前 UI 模式名。
 * @param  data: 指向当前传感器数据结构体的指针
 * @param  limit: 温度限制值
 * @param  led_st: LED1 状态 (0/1)
 * @param  mute: 蜂鸣器消音状态 (0/1)
 * @retval 无
 */
static void ui_draw_bottom_bar(SensorData_t *data, int limit, u8 led_st, u8 mute)
{
    int text_y;
    int temp_val;
    int temp_abs;
    int limit_abs;

    POINT_COLOR = WHITE;
    BACK_COLOR = BLACK;
    text_y = lcddev.height - 90;
    if (text_y < 200)
        text_y = 200;

    sprintf(str_buf, "Time: %-10s", data->time);
    LCD_ShowString(20, text_y, 200, 16, 16, (u8 *)str_buf);

    temp_val = data->temperature;
    temp_abs = temp_val < 0 ? -temp_val : temp_val;
    limit_abs = limit < 0 ? -limit : limit;
    sprintf(str_buf, "Temp: %s%d.%dC Lim: %s%d.%dC",
            temp_val < 0 ? "-" : "", temp_abs / 10, temp_abs % 10,
            limit < 0 ? "-" : "", limit_abs / 10, limit_abs % 10);
    LCD_ShowString(20, text_y + 20, 240, 16, 16, (u8 *)str_buf);

    sprintf(str_buf, "Light: %-3d Lim: %-3d", data->light, GlobalConfig.light_limit);
    LCD_ShowString(20, text_y + 40, 240, 16, 16, (u8 *)str_buf);

    sprintf(str_buf, "LED1:%s Mute:%s", led_st ? "ON " : "OFF", mute ? "YES" : "NO ");
    LCD_ShowString(20, text_y + 60, 160, 16, 16, (u8 *)str_buf);

    /* ADC / DAC 电压显示 (右侧) */
    sprintf(str_buf, "DAC:%d.%02dV", data->dac_vol / 1000, (data->dac_vol % 1000) / 10);
    POINT_COLOR = CYAN;
    LCD_ShowString(260, text_y + 20, 120, 16, 16, (u8 *)str_buf);
    sprintf(str_buf, "ADC:%d.%02dV", data->adc_vol / 1000, (data->adc_vol % 1000) / 10);
    LCD_ShowString(260, text_y + 40, 120, 16, 16, (u8 *)str_buf);

    if (UI_Mode == 0)
    {
        POINT_COLOR = YELLOW;
        LCD_ShowString(lcddev.width - 180, text_y, 160, 16, 16, (u8 *)"MODE: CURVE VIEW ");
    }
    else if (UI_Mode == 1)
    {
        POINT_COLOR = YELLOW;
        LCD_ShowString(lcddev.width - 180, text_y, 160, 16, 16, (u8 *)"MODE: DASHBOARD  ");
    }
    else if (UI_Mode == 2)
    {
        POINT_COLOR = YELLOW;
        LCD_ShowString(lcddev.width - 180, text_y, 160, 16, 16, (u8 *)"MODE: COMM LOGS  ");
    }
    else if (UI_Mode == 3)
    {
        POINT_COLOR = YELLOW;
        LCD_ShowString(lcddev.width - 180, text_y, 160, 16, 16, (u8 *)"MODE: CLOCK      ");
    }
}

/**
 * @brief  绘制右下角状态指示灯(呼吸闪烁效果)
 * @note   根据系统状态显示不同颜色的指示灯:
 *         - 绿色慢闪: 正常运行(待机,无报警)
 *         - 黄色慢闪: 菜单打开中
 *         - 红色快闪: 传感器超限报警
 *         - 红色常亮: 紧急拉闸
 *         - 蓝色常亮: Crash Sim 进行中
 * @param  menu_s: 菜单状态
 * @param  is_emergency: 紧急拉闸状态
 * @param  alarm_type: 报警类型(0=正常 1=超限 2=紧急)
 * @param  crash_active: Crash Sim 弹窗进行中
 * @retval 无
 */
static void ui_draw_status_led(u8 menu_s, u8 is_emergency, u8 alarm_type, u8 crash_active)
{
    static u8 blink_cnt = 0;
    u16 led_color;
    u8 led_on;
    u16 cx, cy;
    u8 r = 8;

    cx = lcddev.width - 25;
    cy = lcddev.height - 55;
    blink_cnt++;

    /* ui_task 约 50ms 刷新一次,故 1 个 blink_cnt 周期 ≈ 50ms */
    if (crash_active)
    {
        led_color = BLUE;
        led_on = 1; /* 常亮(系统即将卡死) */
    }
    else if (is_emergency)
    {
        led_color = RED;
        led_on = 1; /* 常亮(紧急拉闸) */
    }
    else if (alarm_type == 2)
    {
        led_color = RED;
        led_on = (blink_cnt % 8 < 4); /* 红色快闪 2.5Hz(超限报警) */
    }
    else if (alarm_type == 1)
    {
        led_color = YELLOW;
        led_on = (blink_cnt % 16 < 8); /* 黄色慢闪 1.25Hz(接近限值警告) */
    }
    else if (menu_s > 0)
    {
        led_color = YELLOW;
        led_on = (blink_cnt % 16 < 8); /* 黄色慢闪 1.25Hz(菜单打开) */
    }
    else
    {
        led_color = GREEN;
        led_on = (blink_cnt % 20 < 10); /* 绿色心跳 1Hz(正常运行) */
    }

    /* 先画黑色背景擦除上次 LED */
    LCD_Fill(cx - r - 2, cy - r - 2, cx + r + 2, cy + r + 2, BLACK);

    if (led_on)
    {
        /* 画实心圆:用多个同心圆填充 */
        u8 ri;
        POINT_COLOR = led_color;
        for (ri = r; ri > 0; ri--)
            LCD_Draw_Circle(cx, cy, ri);
        LCD_Draw_Circle(cx, cy, r);
    }
    else
    {
        /* 灭灯:只画暗色外框 */
        POINT_COLOR = GRAY;
        LCD_Draw_Circle(cx, cy, r);
    }
}

/**
 * @brief  绘制系统设置主菜单与调节竖条
 * @note   在屏幕居中位置绘制系统设置主菜单背景、选项列表、选中的光标指示器，并在二级数值编辑模式下，于右侧绘制带颜色填充（温度为红、光照为黄）的比例调节竖条。
 * @param  menu_s: 菜单状态 (1=导航模式, 2=编辑模式)
 * @param  menu_c: 当前菜单光标索引 (0~5)
 * @param  limit: 当前温度限制值
 * @param  is_emergency: 是否处于紧急拉闸状态
 * @param  mute: 蜂鸣器是否消音
 * @param  menu_bg_draw: 是否重绘菜单框体灰色背景及顶栏标题
 * @retval 无
 */
static void ui_draw_menu(u8 menu_s, u8 menu_c, int limit, u8 is_emergency, u8 mute, u8 menu_bg_draw)
{
    u16 menu_w;
    u16 menu_h;
    u16 menu_x;
    u16 menu_y;
    u16 menu_i;
    u16 item_y;
    int limit_abs;

    menu_w = 320;
    if (menu_s == 2 && (menu_c == 0 || menu_c == 1))
        menu_h = 320; /* 编辑温度/光照时扩大高度容纳 +/-/OK/Cancel 按钮 */
    else
        menu_h = 250;
    menu_x = (lcddev.width - menu_w) / 2;
    menu_y = (lcddev.height - menu_h) / 2;

    if (menu_bg_draw)
    {
        LCD_Fill(menu_x, menu_y, menu_x + menu_w - 1, menu_y + menu_h - 1, GRAY);
        POINT_COLOR = WHITE;
        LCD_DrawLine(menu_x, menu_y, menu_x + menu_w, menu_y);
        LCD_DrawLine(menu_x, menu_y + menu_h, menu_x + menu_w, menu_y + menu_h);
        LCD_DrawLine(menu_x, menu_y, menu_x, menu_y + menu_h);
        LCD_DrawLine(menu_x + menu_w, menu_y, menu_x + menu_w, menu_y + menu_h);

        BACK_COLOR = GRAY;
        LCD_ShowString(menu_x + 90, menu_y + 15, 140, 24, 24, (u8 *)"SYSTEM MENU");
        LCD_DrawLine(menu_x + 10, menu_y + 45, menu_x + menu_w - 10, menu_y + 45);
    }

    /* 清空之前的进度条痕迹，防止返回导航时花屏 */
    if (menu_s == 1)
    {
        LCD_Fill(menu_x + 250, menu_y + 60, menu_x + 300, menu_y + 220, GRAY);
    }

    BACK_COLOR = GRAY;
    for (menu_i = 0; menu_i < 6; menu_i++)
    {
        item_y = menu_y + 55 + menu_i * 28;
        if (menu_i == menu_c)
        {
            POINT_COLOR = YELLOW;
            /* 层级不同使用不同前缀：二级修改为 '>' 提示，一级菜单为 '*' 提示 */
            if (menu_s == 2)
                LCD_ShowString(menu_x + 15, item_y, 20, 16, 16, (u8 *)">");
            else
                LCD_ShowString(menu_x + 15, item_y, 20, 16, 16, (u8 *)"*");
        }
        else
        {
            POINT_COLOR = WHITE;
            LCD_ShowString(menu_x + 15, item_y, 20, 16, 16, (u8 *)" ");
        }

        if (menu_i == 0)
        {
            limit_abs = limit < 0 ? -limit : limit;
            if (menu_s == 2 && menu_c == 0)
                sprintf(str_buf, "1. Temp Limit  : [%s%d.%dC]", limit < 0 ? "-" : "", limit_abs / 10, limit_abs % 10);
            else
                sprintf(str_buf, "1. Temp Limit  :  %s%d.%dC", limit < 0 ? "-" : "", limit_abs / 10, limit_abs % 10);
        }
        else if (menu_i == 1)
        {
            if (menu_s == 2 && menu_c == 1)
                sprintf(str_buf, "2. Light Limit : [%-3d]", GlobalConfig.light_limit);
            else
                sprintf(str_buf, "2. Light Limit :  %-3d", GlobalConfig.light_limit);
        }
        else if (menu_i == 2)
            sprintf(str_buf, "3. Emg Stop    : %-3s", is_emergency ? "ON " : "OFF");
        else if (menu_i == 3)
            sprintf(str_buf, "4. Beep Mute   : %-3s", mute ? "ON " : "OFF");
        else if (menu_i == 4)
        {
            if (menu_s == 2 && menu_c == 4)
                sprintf(str_buf, "5. Crash Sim   : [YES]");
            else
                sprintf(str_buf, "5. Crash Sim   :  NO ");
        }
        else if (menu_i == 5)
            sprintf(str_buf, "6. Exit");

        LCD_ShowString(menu_x + 30, item_y, 220, 16, 16, (u8 *)str_buf);
    }

    /* --- 绘制右侧温度/光照调节的“竖条条” --- */
    if (menu_s == 2 && (menu_c == 0 || menu_c == 1))
    {
        u16 bar_x = menu_x + 270;
        u16 bar_y = menu_y + 70;
        u16 bar_w = 16;
        u16 bar_h = 130;
        u16 fill_h = 0;

        /* 绘制外边框 */
        POINT_COLOR = WHITE;
        LCD_DrawLine(bar_x, bar_y, bar_x + bar_w, bar_y);
        LCD_DrawLine(bar_x, bar_y + bar_h, bar_x + bar_w, bar_y + bar_h);
        LCD_DrawLine(bar_x, bar_y, bar_x, bar_y + bar_h);
        LCD_DrawLine(bar_x + bar_w, bar_y, bar_x + bar_w, bar_y + bar_h);

        if (menu_c == 0) /* 温度范围为 15.0 ~ 50.0 C (150 ~ 500) */
        {
            if (limit < 150)
                fill_h = 0;
            else if (limit > 500)
                fill_h = bar_h - 2;
            else
                fill_h = (u16)((limit - 150) * (bar_h - 2) / 350);

            /* 红色填充代表温度 */
            if (fill_h > 0)
                LCD_Fill(bar_x + 1, bar_y + bar_h - fill_h - 1, bar_x + bar_w - 1, bar_y + bar_h - fill_h - 2 + fill_h + 1, RED);
            if (fill_h < (bar_h - 2))
                LCD_Fill(bar_x + 1, bar_y + 1, bar_x + bar_w - 1, bar_y + bar_h - fill_h - 2, DARKBLUE);
        }
        else /* 光照范围为 10 ~ 95 */
        {
            if (GlobalConfig.light_limit < 10)
                fill_h = 0;
            else if (GlobalConfig.light_limit > 95)
                fill_h = bar_h - 2;
            else
                fill_h = (u16)((GlobalConfig.light_limit - 10) * (bar_h - 2) / 85);

            /* 黄色填充代表光照 */
            if (fill_h > 0)
                LCD_Fill(bar_x + 1, bar_y + bar_h - fill_h - 1, bar_x + bar_w - 1, bar_y + bar_h - fill_h - 2 + fill_h + 1, YELLOW);
            if (fill_h < (bar_h - 2))
                LCD_Fill(bar_x + 1, bar_y + 1, bar_x + bar_w - 1, bar_y + bar_h - fill_h - 2, DARKBLUE);
        }
    }

    /* --- 编辑态绘制 +/-/OK/Cancel 触摸按钮(仅温度/光照编辑时) --- */
    if (menu_bg_draw && menu_s == 2 && (menu_c == 0 || menu_c == 1))
    {
        BACK_COLOR = DARKBLUE;
        POINT_COLOR = WHITE;
        LCD_Fill(EDIT_BTN_MINUS_X1, EDIT_BTN_Y1, EDIT_BTN_MINUS_X2, EDIT_BTN_Y2, DARKBLUE);
        LCD_DrawLine(EDIT_BTN_MINUS_X1, EDIT_BTN_Y1, EDIT_BTN_MINUS_X2, EDIT_BTN_Y1);
        LCD_DrawLine(EDIT_BTN_MINUS_X1, EDIT_BTN_Y2, EDIT_BTN_MINUS_X2, EDIT_BTN_Y2);
        LCD_DrawLine(EDIT_BTN_MINUS_X1, EDIT_BTN_Y1, EDIT_BTN_MINUS_X1, EDIT_BTN_Y2);
        LCD_DrawLine(EDIT_BTN_MINUS_X2, EDIT_BTN_Y1, EDIT_BTN_MINUS_X2, EDIT_BTN_Y2);
        LCD_ShowString(EDIT_BTN_MINUS_X1 + 18, EDIT_BTN_Y1 + 12, 24, 16, 16, (u8 *)"-");

        LCD_Fill(EDIT_BTN_PLUS_X1, EDIT_BTN_Y1, EDIT_BTN_PLUS_X2, EDIT_BTN_Y2, DARKBLUE);
        LCD_DrawLine(EDIT_BTN_PLUS_X1, EDIT_BTN_Y1, EDIT_BTN_PLUS_X2, EDIT_BTN_Y1);
        LCD_DrawLine(EDIT_BTN_PLUS_X1, EDIT_BTN_Y2, EDIT_BTN_PLUS_X2, EDIT_BTN_Y2);
        LCD_DrawLine(EDIT_BTN_PLUS_X1, EDIT_BTN_Y1, EDIT_BTN_PLUS_X1, EDIT_BTN_Y2);
        LCD_DrawLine(EDIT_BTN_PLUS_X2, EDIT_BTN_Y1, EDIT_BTN_PLUS_X2, EDIT_BTN_Y2);
        LCD_ShowString(EDIT_BTN_PLUS_X1 + 18, EDIT_BTN_Y1 + 12, 24, 16, 16, (u8 *)"+");

        BACK_COLOR = GREEN;
        LCD_Fill(EDIT_BTN_OK_X1, EDIT_BTN_Y1, EDIT_BTN_OK_X2, EDIT_BTN_Y2, GREEN);
        LCD_DrawLine(EDIT_BTN_OK_X1, EDIT_BTN_Y1, EDIT_BTN_OK_X2, EDIT_BTN_Y1);
        LCD_DrawLine(EDIT_BTN_OK_X1, EDIT_BTN_Y2, EDIT_BTN_OK_X2, EDIT_BTN_Y2);
        LCD_DrawLine(EDIT_BTN_OK_X1, EDIT_BTN_Y1, EDIT_BTN_OK_X1, EDIT_BTN_Y2);
        LCD_DrawLine(EDIT_BTN_OK_X2, EDIT_BTN_Y1, EDIT_BTN_OK_X2, EDIT_BTN_Y2);
        LCD_ShowString(EDIT_BTN_OK_X1 + 14, EDIT_BTN_Y1 + 12, 40, 16, 16, (u8 *)"OK");

        BACK_COLOR = RED;
        LCD_Fill(EDIT_BTN_CANCEL_X1, EDIT_BTN_Y1, EDIT_BTN_CANCEL_X2, EDIT_BTN_Y2, RED);
        LCD_DrawLine(EDIT_BTN_CANCEL_X1, EDIT_BTN_Y1, EDIT_BTN_CANCEL_X2, EDIT_BTN_Y1);
        LCD_DrawLine(EDIT_BTN_CANCEL_X1, EDIT_BTN_Y2, EDIT_BTN_CANCEL_X2, EDIT_BTN_Y2);
        LCD_DrawLine(EDIT_BTN_CANCEL_X1, EDIT_BTN_Y1, EDIT_BTN_CANCEL_X1, EDIT_BTN_Y2);
        LCD_DrawLine(EDIT_BTN_CANCEL_X2, EDIT_BTN_Y1, EDIT_BTN_CANCEL_X2, EDIT_BTN_Y2);
        LCD_ShowString(EDIT_BTN_CANCEL_X1 + 6, EDIT_BTN_Y1 + 12, 70, 16, 16, (u8 *)"Cancel");
    }
}

/* ================== 系统核心任务函数 ================== */

/**
 * @brief  系统主函数入口
 */
int main(void)
{
    u8 err;

    /* ====== 显式开启 FPU (防止编译器未定义 __FPU_USED 导致浮点运算 HardFault) ====== */
    SCB->CPACR |= ((3UL << 10 * 2) | (3UL << 11 * 2)); /* set CP10 and CP11 Full Access */

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); /* 设中断优先级分组2 */
    delay_init(168);                                /* 初始化延时函数 */
    uart_init(115200);                              /* 初始化串口1 */
    LED_Init();                                     /* 初始化 LED 及蜂鸣器 */
    LED1 = 0;                                       /* 上电默认点亮LED1(g_Led1_Cmd=1) */
    LCD_Init();                                     /* 初始化 LCD */
    TP_Init();                                      /* 初始化触摸屏(自动识别 GT9147/FT5206/OTT2001A/电阻屏) */

    /* ====== 触摸屏调试输出(通过串口1输出,115200波特率) ====== */
    printf("\r\n[TOUCH] LCD ID: 0x%04X, W=%d, H=%d\r\n", lcddev.id, lcddev.width, lcddev.height);
    printf("[TOUCH] tp_dev.touchtype: 0x%02X (%s)\r\n", tp_dev.touchtype,
           (tp_dev.touchtype & 0x80) ? "Capacitive" : "Resistive");
    if (tp_dev.touchtype & 0x80)
    {
        if (lcddev.id == 0x5510)
            printf("[TOUCH] Driver: GT9147 or OTT2001A (4.3\" cap)\r\n");
        else if (lcddev.id == 0x1963)
            printf("[TOUCH] Driver: FT5206 (7\" cap)\r\n");
        else
            printf("[TOUCH] WARNING: Unknown LCD ID for capacitive touch!\r\n");
    }
    else
    {
        printf("[TOUCH] Driver: Resistive (GPIO SPI)\r\n");
        printf("[TOUCH] If you have a capacitive panel, LCD ID mismatch!\r\n");
    }
    printf("[TOUCH] scan func ptr: 0x%08X\r\n", (u32)tp_dev.scan);

    /* ====== 触摸驱动强制覆盖(自动识别失败时使用,取消顶部宏定义注释即可生效) ====== */
#if defined(TOUCH_FORCE_GT9147)
    GT9147_Init();
    tp_dev.scan = GT9147_Scan;
    tp_dev.touchtype |= 0x80;                /* 标记为电容屏 */
    tp_dev.touchtype |= (lcddev.dir & 0x01); /* 同步横竖屏方向 */
    printf("[TOUCH] FORCED -> GT9147 (4.3\" cap)\r\n");
#elif defined(TOUCH_FORCE_FT5206)
    FT5206_Init();
    tp_dev.scan = FT5206_Scan;
    tp_dev.touchtype |= 0x80;
    tp_dev.touchtype |= (lcddev.dir & 0x01);
    printf("[TOUCH] FORCED -> FT5206 (7\" cap)\r\n");
#elif defined(TOUCH_FORCE_OTT2001A)
    OTT2001A_Init();
    tp_dev.scan = OTT2001A_Scan;
    tp_dev.touchtype |= 0x80;
    tp_dev.touchtype |= (lcddev.dir & 0x01);
    printf("[TOUCH] FORCED -> OTT2001A (4.3\" cap alt)\r\n");
#endif

    /* ====== 独立看门狗复位检测与声光报警提示 ====== */
    check_watchdog_reset();

    Adc_Init();       /* 初始化 ADC */
    Dac1_Init();      /* 初始化 DAC 通道1 (PA4) */
    EXTIX_Init();     /* 初始化按键 EXTI 中断 */
    FSMC_SRAM_Init(); /* 初始化外部 SRAM */

    /* 固化参数参数载入 */
    load_system_config();

    OSInit();

    UI_Queue = OSQCreate(UI_Msg_Buf, QUEUE_MAX_SIZE);
    COM_Queue = OSQCreate(COM_Msg_Buf, QUEUE_MAX_SIZE);
    Key_Sem = OSSemCreate(0);
    Config_Mutex = OSMutexCreate(0, &err); /* 无天花板优先级,依赖优先级继承自动处理 */

    OSTaskCreate(start_task, (void *)0, (OS_STK *)&START_TASK_STK[START_STK_SIZE - 2], START_TASK_PRIO);
    OSStart();
    return 0;
}

/**
 * @brief  系统启动任务，用于创建其他核心应用任务
 */
void start_task(void *pdata)
{
    pdata = pdata;

    OSTaskCreate(control_task, (void *)0, (OS_STK *)&CONTROL_TASK_STK[CONTROL_STK_SIZE - 2], CONTROL_TASK_PRIO);
    OSTaskCreate(sensor_task, (void *)0, (OS_STK *)&SENSOR_TASK_STK[SENSOR_STK_SIZE - 2], SENSOR_TASK_PRIO);
    OSTaskCreate(com_task, (void *)0, (OS_STK *)&COM_TASK_STK[COM_STK_SIZE - 2], COM_TASK_PRIO);
    OSTaskCreate(ui_task, (void *)0, (OS_STK *)&UI_TASK_STK[UI_STK_SIZE - 2], UI_TASK_PRIO);
    OSTaskCreate(touch_task, (void *)0, (OS_STK *)&TOUCH_TASK_STK[TOUCH_STK_SIZE - 2], TOUCH_TASK_PRIO);

    /* 防止 UCOS-II 早期 PendSV 抢占导致栈溢出,先延时让调度稳定 */
    OSTimeDly(2);

    /* 挂起自身(start_task不再需要) */
    OSTaskSuspend(OS_PRIO_SELF);

    /* 兜底:挂起失败时死循环防止PC跑飞 */
    while (1)
        ;
}

/**
 * @brief  传感器采集与声光警报任务
 */
void sensor_task(void *pdata)
{
    int temp_window[10];
    uint16_t light_window[10];
    u8 window_idx;
    u8 window_full;
    u8 cycle_cnt;
    int temp_sum;
    u32 light_sum;
    u8 sample_num;
    int avg_temp_adc;
    uint16_t avg_light;
    int cur_temp_10;
    u8 err;
    u8 is_emergency;
    int limit;
    uint16_t light_limit;
    SensorData_t *p_data;
    int i;
    int cur_light;
    u16 adc_val;
    uint16_t dac_vol_mv;
    uint16_t adc_vol_mv;
    u8 led_cmd;

    /* 静态变量 */
    static u8 dac_idx = 0;    /* 静态变量，记录 DAC 查表索引 */
    static u8 alarm_type = 0; /* 报警状态: 0=正常, 1=普通超限, 2=紧急拉闸 */

    /* 正弦查表数据，表示 0.9V ~ 2.9V，避开极限电压，波形平滑 */
    const uint16_t Dac_Sin_Table[16] = {1900, 2280, 2600, 2800, 2900, 2800, 2600, 2280, 1900, 1520, 1200, 1000, 900, 1000, 1200, 1520};

    static SensorData_t data_pool[QUEUE_MAX_SIZE + 1];
    static u8 pool_idx = 0;

    memset(temp_window, 0, sizeof(temp_window));
    memset(light_window, 0, sizeof(light_window));
    window_idx = 0;
    window_full = 0;
    cycle_cnt = 0;

    pdata = pdata;

    printf("[SENSOR] Task started\r\n");

    /* ====== 开启独立看门狗 (IWDG) 监控系统 ====== */
    iwdg_init();

    while (1)
    {
        /* Crash Sim 期间停止喂狗,让 IWDG 在 4 秒后触发复位 */
        if (!Crash_Sim_Active)
            IWDG->KR = 0xAAAA; /* 喂狗 */

        /* 50ms 高频周期性采集 (读取原始 ADC 整数值) */
        temp_window[window_idx] = Get_Adc_Value(ADC1, ADC_Channel_TempSensor);
        light_window[window_idx] = Get_Adc_Value(ADC3, ADC_Channel_5);
        window_idx++;
        if (window_idx >= 10)
        {
            window_idx = 0;
            window_full = 1;
        }

        cycle_cnt++;
        if (cycle_cnt >= 5) /* 250ms (4Hz) 处理与上报 */
        {
            cycle_cnt = 0;

            temp_sum = 0;
            light_sum = 0;
            sample_num = window_full ? 10 : window_idx;
            if (sample_num == 0)
                sample_num = 1;

            for (i = 0; i < sample_num; i++)
            {
                temp_sum += temp_window[i];
                light_sum += light_window[i];
            }
            avg_temp_adc = temp_sum / sample_num;
            avg_light = light_sum / sample_num;

            /* 内部传感器纯整数乘移位的高精度公式，放大 10 倍，不需要任何 FPU 和浮点资源 */
            cur_temp_10 = ((avg_temp_adc * 825) >> 8) - 2790;
            if (avg_light > 4000)
                avg_light = 4000;
            cur_light = 100 - (avg_light / 40);

            OSMutexPend(Config_Mutex, 0, &err);
            is_emergency = GlobalConfig.emergency_stop;
            limit = GlobalConfig.temp_limit;
            light_limit = GlobalConfig.light_limit;

            led_cmd = g_Led1_Cmd;
            if (led_cmd == 1)
                LED1 = 0; /* 低电平亮 */
            else
                LED1 = 1; /* 高电平灭 */

            /* 注意: beep_mute 不在此处自动重置!
               静音状态只能由用户通过按键/触摸/串口命令主动切换,
               否则 {"BEEP":1} 设的静音会在 250ms 后被清除。 */
            OSMutexPost(Config_Mutex);

            /* 更新报警状态，由 50ms 状态机在小周期内执行声光控制 */
            if (is_emergency)
            {
                alarm_type = 2;
            }
            else if (cur_temp_10 > limit || cur_light > light_limit)
            {
                alarm_type = 1;
            }
            else
            {
                alarm_type = 0;
            }

            /* DAC 输出: 正弦波模式 or 固定电压模式 */
            if (Dac_Mode == 0)
            {
                dac_vol_mv = Dac_Sin_Table[dac_idx];
                Dac1_Set_Vol(dac_vol_mv);
                dac_idx = (dac_idx + 1) % 16;
            }
            else
            {
                dac_vol_mv = Dac_Fix_Mv;
                Dac1_Set_Vol(dac_vol_mv);
            }

            /* 回读 PA5 电压 */
            adc_val = Get_Adc_Value(ADC1, ADC_Channel_5);
            adc_vol_mv = (uint16_t)((u32)adc_val * 3300 / 4096);

            /* ADC 窗口检测: 电压过低或过高触发报警 */
            if (adc_vol_mv < Adc_Win_Low || adc_vol_mv > Adc_Win_High)
            {
                Adc_Win_Alarm = 1;
                if (alarm_type == 0)
                    alarm_type = 1; /* 提升为普通报警 */
            }
            else
            {
                Adc_Win_Alarm = 0;
            }

            p_data = &data_pool[pool_idx];
            p_data->temperature = cur_temp_10;
            p_data->light = cur_light;
            p_data->dac_vol = dac_vol_mv;
            p_data->adc_vol = adc_vol_mv;
            RTC_Get_Time_Str((char *)p_data->time);

            OSQPost(UI_Queue, (void *)p_data);
            OSQPost(COM_Queue, (void *)p_data);

            pool_idx = (pool_idx + 1) % (QUEUE_MAX_SIZE + 1);

            /* 闹钟与整点报时检测(每 250ms 调用) */
            alarm_check();
        }

        /* ====== 50ms 级别声光报警状态机 ====== */
        sensor_alarm_control(alarm_type);

        delay_ms(50);
    }
}

/**
 * @brief  系统控制逻辑与按键交互任务
 */
void control_task(void *pdata)
{
    u8 err;
    pdata = pdata;
    while (1)
    {
        if (Menu_State != 2) /* 在 待机(0) 和 导航(1) 状态下，使用信号量阻塞等待外部中断（按一下响应一次，省电防连跳） */
        {
            OSSemPend(Key_Sem, 0, &err); /* 等待按键中断同步信号量 */

            /* 立即硬件级屏蔽这四个按键 of EXTI 中断触发，以供软件防抖 */
            EXTI->IMR &= ~((1 << 0) | (1 << 2) | (1 << 3) | (1 << 4));

            OSMutexPend(Config_Mutex, 0, &err);

            if (Menu_State == 0) /* 待机模式 */
            {
                control_handle_standby();
            }
            else if (Menu_State == 1) /* 菜单导航模式 (共 6 项) */
            {
                control_handle_menu_nav();
            }

            Last_Key = 0xFF;
            OSMutexPost(Config_Mutex);

            /* 主动发送瞬时刷新指令，让屏幕在微秒内完成状态重绘 */
            OSQPost(UI_Queue, (void *)0xFFFFFFFF);

            /* 挂起任务 100ms 去抖 */
            OSTimeDly(10);

            /* 等待物理按键全部松开，从根本上杜绝连按或连跳问题 */
            while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0) == 1 ||
                   GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_3) == 0 ||
                   GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_4) == 0 ||
                   GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_2) == 0)
            {
                OSTimeDly(2); /* 每次延时 20ms */
            }

            /* 松手后再防抖 50ms */
            OSTimeDly(5);

            /* 清除此期间产生的 EXTI 挂起寄存器标志 */
            EXTI_ClearITPendingBit(EXTI_Line0 | EXTI_Line2 | EXTI_Line3 | EXTI_Line4);

            /* 只有当非编辑模式时，才重新使能外部中断 */
            if (Menu_State != 2)
            {
                EXTI->IMR |= (1 << 0) | (1 << 2) | (1 << 3) | (1 << 4);
            }

            /* 清理队列多余信号量 */
            while (OSSemAccept(Key_Sem) > 0)
                ;
        }
        else /* 在 编辑(2) 状态下，为了实现长按快速调节，我们直接高频周期性轮询物理引脚电平！ */
        {
            control_handle_menu_edit();
        }
    }
}

/**
 * @brief  串口双向数据通信与命令解析任务
 */
void com_task(void *pdata)
{
    u8 err;
    SensorData_t *data;
    char log_buf[80];
    char json_str[160];
    char cmd_buf[256]; /* 串口命令本地副本, 防止 DMA 在处理期间覆盖 */
    int limit;
    char *p;
    char *p_led;
    char *p_val;
    int val_led;
    char *p_alert;
    int val_alert;
    int temp_i, temp_d;
    int temp_val, temp_abs;
    int limit_abs;
    int light_limit;
    u8 is_emergency;
    int light_val;
    const char *warn_str;

    pdata = pdata;

    while (1)
    {
        /* 限时 100ms 等待发送队列，以保证有时间处理接收 */
        data = (SensorData_t *)OSQPend(COM_Queue, 10, &err);
        if (err == OS_ERR_NONE && data != NULL)
        {
            OSMutexPend(Config_Mutex, 0, &err);
            limit = GlobalConfig.temp_limit;
            light_limit = GlobalConfig.light_limit;
            is_emergency = GlobalConfig.emergency_stop;
            OSMutexPost(Config_Mutex);

            temp_val = data->temperature;
            temp_abs = temp_val < 0 ? -temp_val : temp_val;
            limit_abs = limit < 0 ? -limit : limit;
            light_val = data->light;

            warn_str = "NONE";
            if (is_emergency)
            {
                warn_str = "EMERGENCY";
            }
            else
            {
                if (temp_val > limit && light_val > light_limit)
                {
                    warn_str = "TEMP_AND_LIGHT_OVER_LIMIT";
                }
                else if (temp_val > limit)
                {
                    warn_str = "TEMP_OVER_LIMIT";
                }
                else if (light_val > light_limit)
                {
                    warn_str = "LIGHT_OVER_LIMIT";
                }
            }

            sprintf(json_str, "{\"time\":\"%s\",\"temp\":%s%d.%d,\"light\":%d,\"alert_t\":%s%d.%d,\"alert_l\":%d,\"dac_v\":%d.%02d,\"adc_v\":%d.%02d,\"warn\":\"%s\",\"alarm_trig\":%d}\r\n",
                    data->time,
                    temp_val < 0 ? "-" : "", temp_abs / 10, temp_abs % 10,
                    light_val,
                    limit < 0 ? "-" : "", limit_abs / 10, limit_abs % 10,
                    light_limit,
                    data->dac_vol / 1000, (data->dac_vol % 1000) / 10,
                    data->adc_vol / 1000, (data->adc_vol % 1000) / 10,
                    warn_str, Alm_Trig_Mask);

            /* 闹钟触发标志上报后自动清除 */
            if (Alm_Trig_Mask)
                Alm_Trig_Mask = 0;

            p = json_str;
            while (*p)
            {
                /* 等待发送完毕 */
                while ((USART1->SR & 0X40) == 0)
                    ;
                USART1->DR = (u8)*p++;
            }
            /* 构造 TX 日志: 可读摘要格式, 包含所有传感器数据 */
            sprintf(log_buf, "TX: [%s] T=%s%d.%d L=%d D=%d.%02d A=%d.%02d %s",
                    data->time,
                    temp_val < 0 ? "-" : "", temp_abs / 10, temp_abs % 10,
                    light_val,
                    data->dac_vol / 1000, (data->dac_vol % 1000) / 10,
                    data->adc_vol / 1000, (data->adc_vol % 1000) / 10,
                    warn_str);
            log_buf[79] = '\0';
            Add_Comm_Log(log_buf, LOG_CAT_TX);
        }

        /* 轮询串口 DMA 接收完成标志 */
        if (USART_RX_FLAG == 1)
        {
            /* 立即复制到本地缓冲区, 防止 DMA 在处理期间覆盖原始数据 */
            {
                u16 rx_len = USART_RX_LEN;
                if (rx_len >= 256)
                    rx_len = 255;
                memcpy(cmd_buf, (char *)USART_RX_BUF, rx_len);
                cmd_buf[rx_len] = '\0';
            }
            /* 立即清除标志, 让 DMA 可以接收下一帧 */
            USART_RX_FLAG = 0;
            USART_RX_LEN = 0;

            /* 构造 RX 日志信息，把真实接收的指令字符串打印出来 */
            strncpy(log_buf, "RX: ", 4);
            strncpy(log_buf + 4, cmd_buf, 75);
            log_buf[79] = '\0';
            {
                char *p_nl = strpbrk(log_buf, "\r\n");
                if (p_nl != NULL)
                    *p_nl = '\0';
            }
            Add_Comm_Log(log_buf, LOG_CAT_RX);

            p_led = strstr(cmd_buf, "\"LED\"");
            if (p_led != NULL)
            {
                p_val = strchr(p_led, ':');
                if (p_val != NULL)
                {
                    val_led = 0;
                    sscanf(p_val + 1, "%d", &val_led);
                    OSMutexPend(Config_Mutex, 0, &err);
                    GlobalConfig.led_state = val_led;
                    g_Led1_Cmd = val_led;
                    /* 立即生效 GPIO,无需等 sensor_task 的 1Hz 周期 */
                    if (val_led == 1)
                        LED1 = 0;
                    else
                        LED1 = 1;
                    OSMutexPost(Config_Mutex);
                    sprintf(log_buf, "SYS: LED set to %d", val_led);
                    Add_Comm_Log(log_buf, LOG_CAT_SYS);
                }
            }

            p_alert = strstr(cmd_buf, "\"SET_ALERT\"");
            if (p_alert != NULL)
            {
                p_val = strchr(p_alert, ':');
                if (p_val != NULL)
                {
                    char *p_qa = strchr(p_val + 1, '"');
                    if (p_qa != NULL)
                    {
                        val_alert = 0;
                        temp_i = 0;
                        temp_d = 0;
                        if (sscanf(p_qa + 1, "%d.%d", &temp_i, &temp_d) == 2)
                        {
                            /* 小数部分只取 1 位 (0.1°C 精度): 25.5→255, 25.50→255 */
                            if (temp_d >= 10)
                                temp_d /= 10;
                            if (temp_d >= 10)
                                temp_d /= 10;
                            val_alert = temp_i * 10 + temp_d;
                        }
                        else if (sscanf(p_qa + 1, "%d", &temp_i) == 1)
                        {
                            val_alert = temp_i * 10;
                        }

                        if (val_alert >= 150 && val_alert <= 500)
                        {
                            OSMutexPend(Config_Mutex, 0, &err);
                            GlobalConfig.temp_limit = val_alert;
                            RTC_BKP_Write((0x55AA << 16) | (uint16_t)val_alert);
                            OSMutexPost(Config_Mutex);
                            sprintf(log_buf, "SYS: Alert threshold=%d.%dC", val_alert / 10, val_alert % 10);
                            Add_Comm_Log(log_buf, LOG_CAT_SYS);
                        }
                    }
                }
            }

            /* SET_TIME 串口校时命令: {"SET_TIME":"HH:MM:SS"} */
            {
                char *p_st = strstr(cmd_buf, "\"SET_TIME\"");
                if (p_st != NULL)
                {
                    int sh = 0, sm = 0, ss = 0;
                    p_val = strchr(p_st, ':');
                    if (p_val != NULL)
                    {
                        char *p_q = strchr(p_val + 1, '"');
                        if (p_q != NULL && sscanf(p_q + 1, "%d:%d:%d", &sh, &sm, &ss) == 3)
                        {
                            if (sh >= 0 && sh < 24 && sm >= 0 && sm < 60 && ss >= 0 && ss < 60)
                            {
                                RTC_Set_Time((u8)sh, (u8)sm, (u8)ss, RTC_H12_AM);
                                sprintf(log_buf, "SYS: Time set to %02d:%02d:%02d", sh, sm, ss);
                                Add_Comm_Log(log_buf, LOG_CAT_SYS);
                            }
                        }
                    }
                }
            }

            /* SET_DATE 串口设日期命令: {"SET_DATE":"YY-MM-DD"} */
            {
                char *p_sd = strstr(cmd_buf, "\"SET_DATE\"");
                if (p_sd != NULL)
                {
                    int dy = 0, dm = 0, dd = 0;
                    p_val = strchr(p_sd, ':');
                    if (p_val != NULL)
                    {
                        char *p_q = strchr(p_val + 1, '"');
                        if (p_q != NULL && sscanf(p_q + 1, "%d-%d-%d", &dy, &dm, &dd) == 3)
                        {
                            if (dy >= 0 && dy < 100 && dm >= 1 && dm <= 12 && dd >= 1 && dd <= 31)
                            {
                                RTC_DateTypeDef rtc_d;
                                rtc_d.RTC_Year = (u8)dy;
                                rtc_d.RTC_Month = (u8)dm;
                                rtc_d.RTC_Date = (u8)dd;
                                rtc_d.RTC_WeekDay = 1; /* 默认周一,RTC 会自动计算 */
                                RTC_SetDate(RTC_Format_BIN, &rtc_d);
                                sprintf(log_buf, "SYS: Date set to 20%02d-%02d-%02d", dy, dm, dd);
                                Add_Comm_Log(log_buf, LOG_CAT_SYS);
                            }
                        }
                    }
                }
            }

            /* SET_ALARM 串口设闹钟命令: {"SET_ALARM":"idx,en,hh:mm"} */
            {
                char *p_sa = strstr(cmd_buf, "\"SET_ALARM\"");
                if (p_sa != NULL)
                {
                    int aidx = 0, aen = 0, ah = 0, am = 0;
                    p_val = strchr(p_sa, ':');
                    if (p_val != NULL)
                    {
                        char *p_q = strchr(p_val + 1, '"');
                        if (p_q != NULL && sscanf(p_q + 1, "%d,%d,%d:%d", &aidx, &aen, &ah, &am) == 4)
                        {
                            if (aidx >= 0 && aidx < MAX_ALARMS && ah >= 0 && ah < 24 && am >= 0 && am < 60)
                            {
                                Alm_H[aidx] = (u8)ah;
                                Alm_M[aidx] = (u8)am;
                                Alm_En[aidx] = (aen != 0) ? 1 : 0;
                                alarm_save_idx((u8)aidx);
                                sprintf(log_buf, "SYS: Alarm %d %s %02d:%02d", aidx + 1,
                                        Alm_En[aidx] ? "ON" : "OFF", ah, am);
                                Add_Comm_Log(log_buf, LOG_CAT_SYS);
                            }
                        }
                    }
                }
            }

            /* SET_TIMER 串口设倒计时命令: {"SET_TIMER":"mm:ss"} 或 {"SET_TIMER":"start"} / {"SET_TIMER":"stop"} / {"SET_TIMER":"reset"} */
            {
                char *p_sti = strstr(cmd_buf, "\"SET_TIMER\"");
                if (p_sti != NULL)
                {
                    char *p_val2 = strchr(p_sti, ':');
                    if (p_val2 != NULL)
                    {
                        char *p_q2 = strchr(p_val2 + 1, '"');
                        if (p_q2 != NULL)
                        {
                            if (strncmp(p_q2 + 1, "start", 5) == 0)
                            {
                                if (Timer_Remain_Sec > 0)
                                {
                                    Timer_Running = 1;
                                    sprintf(log_buf, "SYS: Timer started (%ds)", Timer_Remain_Sec);
                                    Add_Comm_Log(log_buf, LOG_CAT_SYS);
                                }
                            }
                            else if (strncmp(p_q2 + 1, "stop", 4) == 0)
                            {
                                Timer_Running = 0;
                                Add_Comm_Log("SYS: Timer paused", LOG_CAT_SYS);
                            }
                            else if (strncmp(p_q2 + 1, "reset", 5) == 0)
                            {
                                Timer_Running = 0;
                                Timer_Remain_Sec = Timer_Set_Sec;
                                Add_Comm_Log("SYS: Timer reset", LOG_CAT_SYS);
                            }
                            else
                            {
                                int tmin = 0, tsec = 0;
                                if (sscanf(p_q2 + 1, "%d:%d", &tmin, &tsec) == 2)
                                {
                                    if (tmin >= 0 && tmin < 100 && tsec >= 0 && tsec < 60)
                                    {
                                        Timer_Set_Sec = (u16)(tmin * 60 + tsec);
                                        Timer_Remain_Sec = Timer_Set_Sec;
                                        Timer_Running = 0;
                                        sprintf(log_buf, "SYS: Timer set to %02d:%02d", tmin, tsec);
                                        Add_Comm_Log(log_buf, LOG_CAT_SYS);
                                    }
                                }
                            }
                        }
                    }
                }
            }

            /* SET_DAC 串口命令: {"SET_DAC":"x.xx"} 设固定电压
               {"SET_DAC":"sin"} 切正弦波  {"SET_DAC":"fix"} 切固定电压
               {"SET_DAC":"+"} 加 0.1V    {"SET_DAC":"-"} 减 0.1V */
            {
                char *p_dac = strstr(cmd_buf, "\"SET_DAC\"");
                if (p_dac != NULL)
                {
                    char *p_vd = strchr(p_dac, ':');
                    if (p_vd != NULL)
                    {
                        char *p_qd = strchr(p_vd + 1, '"');
                        if (p_qd != NULL)
                        {
                            if (strncmp(p_qd + 1, "sin", 3) == 0)
                            {
                                Dac_Mode = 0;
                                Add_Comm_Log("SYS: DAC mode SIN", LOG_CAT_SYS);
                            }
                            else if (strncmp(p_qd + 1, "fix", 3) == 0)
                            {
                                Dac_Mode = 1;
                                Add_Comm_Log("SYS: DAC mode FIX", LOG_CAT_SYS);
                            }
                            else if (p_qd[1] == '+')
                            {
                                if (Dac_Fix_Mv <= 3200)
                                    Dac_Fix_Mv += 100;
                                Dac_Mode = 1;
                                sprintf(log_buf, "SYS: DAC+ %d.%02dV",
                                        Dac_Fix_Mv / 1000, (Dac_Fix_Mv % 1000) / 10);
                                Add_Comm_Log(log_buf, LOG_CAT_SYS);
                            }
                            else if (p_qd[1] == '-')
                            {
                                if (Dac_Fix_Mv >= 100)
                                    Dac_Fix_Mv -= 100;
                                Dac_Mode = 1;
                                sprintf(log_buf, "SYS: DAC- %d.%02dV",
                                        Dac_Fix_Mv / 1000, (Dac_Fix_Mv % 1000) / 10);
                                Add_Comm_Log(log_buf, LOG_CAT_SYS);
                            }
                            else
                            {
                                /* 手动解析浮点数, 正确处理任意位数小数:
                                   "1.5"→1500mV, "1.50"→1500mV, "1.05"→1050mV */
                                int v_int = 0;
                                u16 mv;
                                char *p_num = p_qd + 1;
                                u8 parsed = 0;
                                while (*p_num >= '0' && *p_num <= '9')
                                {
                                    v_int = v_int * 10 + (*p_num - '0');
                                    p_num++;
                                    parsed = 1;
                                }
                                mv = (u16)(v_int * 1000);
                                if (*p_num == '.')
                                {
                                    int multiplier = 100;
                                    p_num++;

                                    while (*p_num >= '0' && *p_num <= '9' && multiplier >= 1)
                                    {
                                        mv += (u16)((*p_num - '0') * multiplier);
                                        multiplier /= 10;
                                        p_num++;
                                    }
                                    parsed = 1;
                                }
                                if (parsed && mv <= 3300)
                                {
                                    Dac_Fix_Mv = mv;
                                    Dac_Mode = 1;
                                    sprintf(log_buf, "SYS: DAC set %d.%02dV",
                                            Dac_Fix_Mv / 1000, (Dac_Fix_Mv % 1000) / 10);
                                    Add_Comm_Log(log_buf, LOG_CAT_SYS);
                                }
                            }
                        }
                    }
                }
            }

            /* SET_ADCWIN 串口命令: {"SET_ADCWIN":"low,high"} 设 ADC 窗口上下限 (mV) */
            {
                char *p_aw = strstr(cmd_buf, "\"SET_ADCWIN\"");
                if (p_aw != NULL)
                {
                    char *p_vw = strchr(p_aw, ':');
                    if (p_vw != NULL)
                    {
                        char *p_qw = strchr(p_vw + 1, '"');
                        if (p_qw != NULL)
                        {
                            int lo = 0, hi = 3300;
                            if (sscanf(p_qw + 1, "%d,%d", &lo, &hi) == 2)
                            {
                                if (lo < 0)
                                    lo = 0;
                                if (hi > 3300)
                                    hi = 3300;
                                if (lo < hi)
                                {
                                    Adc_Win_Low = (u16)lo;
                                    Adc_Win_High = (u16)hi;
                                    sprintf(log_buf, "SYS: ADC window %d~%dmV", lo, hi);
                                    Add_Comm_Log(log_buf, LOG_CAT_SYS);
                                }
                            }
                        }
                    }
                }
            }

            /* SET_LIGHT 串口命令: {"SET_LIGHT":"80"} 设光照报警阈值 (10~95%) */
            {
                char *p_sl = strstr(cmd_buf, "\"SET_LIGHT\"");
                if (p_sl != NULL)
                {
                    char *p_vl = strchr(p_sl, ':');
                    if (p_vl != NULL)
                    {
                        char *p_ql = strchr(p_vl + 1, '"');
                        if (p_ql != NULL)
                        {
                            int lv = 80;
                            if (sscanf(p_ql + 1, "%d", &lv) == 1)
                            {
                                if (lv < 10)
                                    lv = 10;
                                if (lv > 95)
                                    lv = 95;
                                OSMutexPend(Config_Mutex, 0, &err);
                                GlobalConfig.light_limit = (u8)lv;
                                OSMutexPost(Config_Mutex);
                                sprintf(log_buf, "SYS: Light limit=%d%%", lv);
                                Add_Comm_Log(log_buf, LOG_CAT_SYS);
                            }
                        }
                    }
                }
            }

            /* BEEP 串口命令: {"BEEP":1} 静音开  {"BEEP":0} 静音关 */
            {
                char *p_bp = strstr(cmd_buf, "\"BEEP\"");
                if (p_bp != NULL)
                {
                    char *p_vb = strchr(p_bp, ':');
                    if (p_vb != NULL)
                    {
                        int bv = 0;
                        sscanf(p_vb + 1, "%d", &bv);
                        OSMutexPend(Config_Mutex, 0, &err);
                        GlobalConfig.beep_mute = (bv != 0) ? 1 : 0;
                        OSMutexPost(Config_Mutex);
                        sprintf(log_buf, "SYS: Beep mute %s", bv ? "ON" : "OFF");
                        Add_Comm_Log(log_buf, LOG_CAT_SYS);
                    }
                }
            }
        }
    }
}

/**
 * @brief  LCD 液晶屏界面刷新与显示绘制任务
 */
void ui_task(void *pdata)
{
    u8 err;
    SensorData_t *data;

    /* 声明所有局部变量于函数顶部，完美适配 C89 编译器 */
    int limit;
    u8 is_emergency;
    u8 led_st;
    u8 menu_s;
    u8 menu_c;
    u8 mute;
    u8 tail;
    u8 last_mode;
    u8 last_emg;
    u8 last_menu_s;
    u8 last_menu_c;
    static u8 force_clear;
    static u8 Popup_Closed_Redraw = 0; /* 弹窗关闭后需在下一轮迭代全屏重绘 */
    u8 menu_bg_draw;

    static SensorData_t last_data;
    static u8 has_last_data = 0;

    last_mode = 0xFF;
    last_emg = 0xFF;
    last_menu_s = 0xFF;
    last_menu_c = 0xFF;
    force_clear = 0;
    menu_bg_draw = 0;

    pdata = pdata;

    /* ========== 开机 Splash 动画 ========== */
    {
        u8 spin_i;
        u8 dot_i;
        u16 cx_s = lcddev.width / 2;
        u16 cy_s = 250; /* 圆环中心下移, 给文字留足空间 */
        u8 radius = 45; /* 圆环加大 */
        s16 angle;
        u16 dx_s, dy_s;

        LCD_Fill(0, 0, lcddev.width - 1, lcddev.height - 1, BLACK);

        /* 标题区 (上方, 字体加大) */
        POINT_COLOR = WHITE;
        BACK_COLOR = BLACK;
        LCD_ShowString((lcddev.width - 216) / 2, 40, 216, 24, 24, (u8 *)"Embedded Gateway");
        POINT_COLOR = CYAN;
        LCD_ShowString((lcddev.width - 240) / 2, 75, 240, 24, 24, (u8 *)"STM32F407ZG @ 168MHz");
        POINT_COLOR = GRAY;
        LCD_ShowString((lcddev.width - 160) / 2, 110, 160, 16, 16, (u8 *)"UCOS-II RTOS");
        POINT_COLOR = YELLOW;
        LCD_ShowString((lcddev.width - 200) / 2, 135, 200, 16, 16, (u8 *)"Gateway System v1.0");

        /* 环形加载转圈动画: 12 个点, 旋转 24 帧 (约 1.2 秒) */
        for (spin_i = 0; spin_i < 24; spin_i++)
        {
            /* 清除圆环区域 (避免残影) */
            LCD_Fill(cx_s - radius - 10, cy_s - radius - 10,
                     cx_s + radius + 10, cy_s + radius + 10, BLACK);

            for (dot_i = 0; dot_i < 12; dot_i++)
            {
                /* 计算每个点的角度 (0~330 度, 间隔 30 度) */
                angle = (s16)(dot_i * 30 + spin_i * 15);
                /* 简单三角函数: 用查表近似, 避免浮点 */
                {
                    s16 a4 = (s16)(angle % 360);
                    s16 sin_v;
                    s16 cos_v;
                    /* 角度到 sin/cos 的简化查表 (12 个点, 30 度间隔) */
                    /* sin: 0,50,87,100,87,50,0,-50,-87,-100,-87,-50 (*100) */
                    s16 sin_tbl[12] = {0, 50, 87, 100, 87, 50, 0, -50, -87, -100, -87, -50};
                    s16 cos_tbl[12] = {100, 87, 50, 0, -50, -87, -100, -87, -50, 0, 50, 87};
                    u8 tbl_idx = (u8)((a4 + 360) % 360 / 30);
                    sin_v = sin_tbl[tbl_idx];
                    cos_v = cos_tbl[tbl_idx];
                    dx_s = (u16)(cx_s + (s16)(radius * cos_v / 100));
                    dy_s = (u16)(cy_s + (s16)(radius * sin_v / 100));
                }

                /* 前 4 个点亮 (蓝), 后面渐暗 */
                if (dot_i < 3)
                    LCD_Fill(dx_s - 3, dy_s - 3, dx_s + 3, dy_s + 3, BLUE);
                else if (dot_i < 5)
                    LCD_Fill(dx_s - 3, dy_s - 3, dx_s + 3, dy_s + 3, 0x2104); /* 暗蓝 */
                else
                    LCD_Fill(dx_s - 2, dy_s - 2, dx_s + 2, dy_s + 2, 0x4208); /* 深灰 */
            }

            /* "Loading..." 文字 */
            POINT_COLOR = WHITE;
            BACK_COLOR = BLACK;
            LCD_ShowString((lcddev.width - 80) / 2, cy_s + radius + 25, 80, 16, 16, (u8 *)"Loading...");

            delay_ms(50);
        }
    }
    /* ========== Splash 结束 ========== */

    while (1)
    {
        data = (SensorData_t *)OSQPend(UI_Queue, 0, &err);

        /* Crash Sim 弹窗显示中,取走队列消息但不刷新屏幕,避免覆盖红屏 */
        if (Crash_Sim_Active)
            continue;

        if (err == OS_ERR_NONE && data != NULL)
        {
            if (data == (SensorData_t *)0xFFFFFFFF)
            {
                if (!has_last_data)
                    continue;
                data = &last_data;
            }
            else
            {
                last_data = *data;
                has_last_data = 1;

                /* 只有收到真正的传感器 data 才更新历史曲线 */
                tail = (History_Head + History_Count) % PLOT_POINTS_MAX;
                if (History_Count < PLOT_POINTS_MAX)
                {
                    History_Count++;
                }
                else
                {
                    History_Head = (History_Head + 1) % PLOT_POINTS_MAX;
                }
                Temp_History[tail] = data->temperature;
                Light_History[tail] = data->light;
            }

            OSMutexPend(Config_Mutex, 0, &err);
            limit = GlobalConfig.temp_limit;
            is_emergency = GlobalConfig.emergency_stop;
            led_st = GlobalConfig.led_state;
            mute = GlobalConfig.beep_mute;
            menu_s = Menu_State;
            menu_c = Menu_Cursor;
            OSMutexPost(Config_Mutex);

            /* 弹窗刚关闭时上一轮迭代设置了 Popup_Closed_Redraw=1, 此处消费它 */
            if (Popup_Closed_Redraw)
            {
                force_clear = 1;
                Popup_Closed_Redraw = 0;
            }
            else
                force_clear = 0;
            menu_bg_draw = 0;
            if (is_emergency != last_emg || UI_Mode != last_mode || menu_s != last_menu_s)
            {
                force_clear = 1;
                last_emg = is_emergency;
                last_mode = UI_Mode;
                last_menu_s = menu_s;

                LCD_Fill(0, 0, lcddev.width - 1, lcddev.height - 1, is_emergency ? RED : BLACK);
                UI_Redraw_Seq++; /* 标记全屏重绘, 使反馈点保存的像素失效 */
                if (menu_s > 0)
                    menu_bg_draw = 1;
            }

            if (menu_s > 0 && menu_c != last_menu_c)
            {
                last_menu_c = menu_c;
            }

            if (is_emergency)
            {
                if (force_clear)
                {
                    POINT_COLOR = WHITE;
                    BACK_COLOR = RED;
                    LCD_ShowString((lcddev.width - 360) / 2, 80, 360, 24, 24, (u8 *)"SYSTEM EMERGENCY STOP!");
                    LCD_ShowString((lcddev.width - 320) / 2, 140, 320, 16, 16, (u8 *)"Press KEY2 to recover system");
                }
            }
            else
            {
                if (menu_s == 0 || force_clear)
                {
                    if (UI_Mode == 0) /* 折线图看板 */
                    {
                        ui_draw_curve(menu_s, limit);
                    }
                    else if (UI_Mode == 1) /* 仪表盘看板 */
                    {
                        ui_draw_dashboard(data, limit);
                    }
                    else if (UI_Mode == 2) /* 日志看板 */
                    {
                        ui_draw_terminal_logs(force_clear);
                    }
                    else if (UI_Mode == 3) /* 电子钟看板 */
                    {
                        ui_draw_clock(force_clear);
                    }
                }

                /* BOTTOM TEXT (总是绘制，背景覆盖实现差分刷新) */
                ui_draw_bottom_bar(data, limit, led_st, mute);

                /* --- 右下角状态指示灯 --- */
                {
                    /* 三级报警:0=正常 1=警告(接近限值) 2=超限报警 */
                    u8 alarm_type = 0;
                    int temp_limit = limit;
                    int light_limit = GlobalConfig.light_limit;
                    /* 警告阈值:限值的 90% */
                    int temp_warn = (int)((u32)temp_limit * 9 / 10);
                    int light_warn = (int)((u32)light_limit * 9 / 10);

                    if (data->temperature > temp_limit || (int)data->light > light_limit)
                        alarm_type = 2; /* 超限:红灯快闪 */
                    else if (data->temperature >= temp_warn || (int)data->light >= light_warn)
                        alarm_type = 1; /* 警告:黄灯慢闪 */

                    ui_draw_status_led(menu_s, is_emergency, alarm_type, Crash_Sim_Active);

                    /* 首次或状态变化时串口输出调试信息 */
                    {
                        static u8 last_alarm = 0xFF;
                        if (alarm_type != last_alarm)
                        {
                            printf("[LED] temp=%d.%dC(limit=%d.%dC) light=%d%%(limit=%d%%) alarm=%d\r\n",
                                   data->temperature / 10, data->temperature % 10,
                                   temp_limit / 10, temp_limit % 10,
                                   data->light, light_limit, alarm_type);
                            last_alarm = alarm_type;
                        }
                    }
                }

                /* --- 绘制居中菜单 --- */
                if (menu_s > 0)
                {
                    ui_draw_menu(menu_s, menu_c, limit, is_emergency, mute, menu_bg_draw);
                }

                /* --- 闹钟弹窗 (覆盖在所有页面之上) --- */
                {
                    static u8 last_alm_popup = 0;
                    if (Alarm_Popup_Active)
                    {
                        u8 alm_idx = Alarm_Popup_Idx;
                        RTC_TimeTypeDef alm_t;

                        if (last_alm_popup == 0)
                        {
                            last_alm_popup = 1;
                            /* 半透明遮罩 */
                            LCD_Fill(0, 0, lcddev.width - 1, lcddev.height - 91, 0x4208);
                            UI_Redraw_Seq++; /* 标记重绘, 使反馈点保存的像素失效 */
                            /* 弹窗框体 */
                            LCD_Fill(60, 200, lcddev.width - 61, 480, DARKBLUE);
                            POINT_COLOR = WHITE;
                            LCD_DrawLine(60, 200, lcddev.width - 61, 200);
                            LCD_DrawLine(60, 480, lcddev.width - 61, 480);
                            LCD_DrawLine(60, 200, 60, 480);
                            LCD_DrawLine(lcddev.width - 61, 200, lcddev.width - 61, 480);
                            /* 标题栏 (红色,区别于蓝色设置弹窗) */
                            LCD_Fill(61, 201, lcddev.width - 62, 240, RED);
                            POINT_COLOR = WHITE;
                            BACK_COLOR = RED;
                            LCD_ShowString((lcddev.width - 120) / 2, 210, 120, 24, 24, (u8 *)"ALARM!");
                        }

                        BACK_COLOR = DARKBLUE;
                        RTC_GetTime(RTC_Format_BIN, &alm_t);
                        sprintf(str_buf, "Alarm %d  %02d:%02d:%02d", alm_idx + 1,
                                alm_t.RTC_Hours, alm_t.RTC_Minutes, alm_t.RTC_Seconds);
                        POINT_COLOR = YELLOW;
                        LCD_ShowString((lcddev.width - 200) / 2, 260, 200, 16, 16, (u8 *)str_buf);

                        /* Snooze 按钮 (绿色) */
                        LCD_Fill(90, 340, 230, 390, GREEN);
                        POINT_COLOR = WHITE;
                        BACK_COLOR = GREEN;
                        LCD_ShowString(100, 355, 130, 16, 16, (u8 *)"Snooze 5 min");

                        /* Dismiss 按钮 (红色) */
                        LCD_Fill(250, 340, 390, 390, RED);
                        POINT_COLOR = WHITE;
                        BACK_COLOR = RED;
                        LCD_ShowString(290, 355, 100, 16, 16, (u8 *)"Dismiss");

                        POINT_COLOR = GRAY;
                        BACK_COLOR = DARKBLUE;
                        LCD_ShowString((lcddev.width - 240) / 2, 420, 240, 16, 16,
                                       (u8 *)"Snooze: remind in 5 min");
                        LCD_ShowString((lcddev.width - 280) / 2, 440, 280, 16, 16,
                                       (u8 *)"Dismiss: stop until tomorrow");
                    }
                    else if (last_alm_popup)
                    {
                        last_alm_popup = 0;
                        Popup_Closed_Redraw = 1; /* 下一轮迭代全屏重绘 */
                        LCD_Fill(0, 0, lcddev.width - 1, lcddev.height - 91, BLACK);
                        UI_Redraw_Seq++; /* 标记重绘, 使反馈点保存的像素失效 */
                    }
                }

                /* --- 倒计时结束弹窗 (区别于闹钟: 蓝色标题, 单个 OK 按钮) --- */
                {
                    static u8 last_tmr_popup = 0;
                    if (Timer_Popup_Active)
                    {
                        if (last_tmr_popup == 0)
                        {
                            last_tmr_popup = 1;
                            /* 半透明遮罩 */
                            LCD_Fill(0, 0, lcddev.width - 1, lcddev.height - 91, 0x4208);
                            UI_Redraw_Seq++; /* 标记重绘, 使反馈点保存的像素失效 */
                            /* 弹窗框体 */
                            LCD_Fill(60, 220, lcddev.width - 61, 460, DARKBLUE);
                            POINT_COLOR = WHITE;
                            LCD_DrawLine(60, 220, lcddev.width - 61, 220);
                            LCD_DrawLine(60, 460, lcddev.width - 61, 460);
                            LCD_DrawLine(60, 220, 60, 460);
                            LCD_DrawLine(lcddev.width - 61, 220, lcddev.width - 61, 460);
                            /* 标题栏 (蓝色, 区别于闹钟红色) */
                            LCD_Fill(61, 221, lcddev.width - 62, 260, BLUE);
                            POINT_COLOR = WHITE;
                            BACK_COLOR = BLUE;
                            LCD_ShowString((lcddev.width - 160) / 2, 230, 160, 24, 24, (u8 *)"Timer Done!");
                        }

                        BACK_COLOR = DARKBLUE;
                        POINT_COLOR = YELLOW;
                        LCD_ShowString((lcddev.width - 200) / 2, 290, 200, 24, 24,
                                       (u8 *)"Countdown Finished");
                        POINT_COLOR = WHITE;
                        LCD_ShowString((lcddev.width - 240) / 2, 325, 240, 16, 16,
                                       (u8 *)"Press OK to dismiss");

                        /* OK 按钮 (青色, 居中, 区别于闹钟的红/绿) */
                        LCD_Fill(170, 370, 310, 420, CYAN);
                        POINT_COLOR = BLACK;
                        BACK_COLOR = CYAN;
                        LCD_ShowString(210, 385, 80, 24, 24, (u8 *)"OK");
                    }
                    else if (last_tmr_popup)
                    {
                        last_tmr_popup = 0;
                        Popup_Closed_Redraw = 1; /* 下一轮迭代全屏重绘 */
                        LCD_Fill(0, 0, lcddev.width - 1, lcddev.height - 91, BLACK);
                        UI_Redraw_Seq++; /* 标记重绘, 使反馈点保存的像素失效 */
                    }
                }
            }
        }
    }
}

/* ================== 触摸手势识别与交互任务 ================== */

/* 手势状态 */
typedef enum
{
    G_IDLE = 0, /* 空闲 */
    G_PRESSED,  /* 已按下,未确定手势 */
    G_SWIPE_H,  /* 水平滑动已确认 */
    G_SWIPE_V,  /* 垂直滑动已确认 */
    G_DRAG_BAR  /* 调节柱拖动中 */
} TouchGesture_t;

/* 调节柱 y 坐标 → 配置值 */
static int touch_bar_y_to_val(u16 y, u8 menu_c)
{
    int val;
    if (y < BAR_TOP_Y)
        y = BAR_TOP_Y;
    if (y > BAR_BOTTOM_Y)
        y = BAR_BOTTOM_Y;
    if (menu_c == 0) /* 温度 150~500 */
        val = 150 + (int)(BAR_BOTTOM_Y - y) * 350 / BAR_HEIGHT;
    else /* 光照 10~95 */
        val = 10 + (int)(BAR_BOTTOM_Y - y) * 85 / BAR_HEIGHT;
    if (menu_c == 0)
    {
        if (val < 150)
            val = 150;
        if (val > 500)
            val = 500;
    }
    else
    {
        if (val < 10)
            val = 10;
        if (val > 95)
            val = 95;
    }
    return val;
}

/* 编辑态按钮热区命中检查,返回虚拟 pin_key(1=+ 2=- 3=OK 4=Cancel,0=未命中) */
static u8 touch_edit_btn_hit(u16 x, u16 y)
{
    if (y < EDIT_BTN_Y1 || y > EDIT_BTN_Y2)
        return 0;
    if (x >= EDIT_BTN_MINUS_X1 && x <= EDIT_BTN_MINUS_X2)
        return 2; /* "-" */
    if (x >= EDIT_BTN_PLUS_X1 && x <= EDIT_BTN_PLUS_X2)
        return 1; /* "+" */
    if (x >= EDIT_BTN_OK_X1 && x <= EDIT_BTN_OK_X2)
        return 3; /* "OK" */
    if (x >= EDIT_BTN_CANCEL_X1 && x <= EDIT_BTN_CANCEL_X2)
        return 4; /* "Cancel" */
    return 0;
}

/* 导航态菜单项命中检查,返回索引 0~5,0xFF=未命中(含菜单外) */
static u8 touch_nav_item_hit(u16 x, u16 y)
{
    int i;
    u16 item_y;
    if (x < NAV_MENU_X || x > NAV_MENU_X + NAV_MENU_W)
        return 0xFF;
    if (y < NAV_ITEM_Y0 || y >= NAV_ITEM_Y0 + 6 * NAV_ITEM_H)
        return 0xFF;
    for (i = 0; i < 6; i++)
    {
        item_y = NAV_ITEM_Y0 + i * NAV_ITEM_H;
        if (y >= item_y && y < item_y + NAV_ITEM_H)
            return (u8)i;
    }
    return 0xFF;
}

/* 虚拟按键注入:设置 Last_Key 并 post 信号量 */
static void touch_inject_key(u8 key_val)
{
    printf("[TOUCH] inject key=%d\r\n", key_val);
    Last_Key = key_val;
    OSSemPost(Key_Sem);
    OSTimeDly(2); /* 让 control_task 有机会响应 */
}

/* 直接更新调节柱值(拖动/点击跳值共用),menu_c: 0=温度 1=光照 */
static void touch_update_bar_value(u16 y, u8 menu_c)
{
    int new_val;
    u8 err;
    new_val = touch_bar_y_to_val(y, menu_c);
    OSMutexPend(Config_Mutex, 0, &err);
    if (menu_c == 0)
        GlobalConfig.temp_limit = new_val;
    else
        GlobalConfig.light_limit = new_val;
    OSMutexPost(Config_Mutex);
    OSQPost(UI_Queue, (void *)0xFFFFFFFF);
}

/* ====== 弹窗内字段调整 (由触摸 +/- 按钮或上下滑动调用) ====== */
/* Popup_Field 含义随 Clock_Popup 不同:
   1=设时间: 0=时 1=分 2=秒
   2=设日期: 0=年 1=月 2=日
   3=设闹钟: 0=时 1=分
   4=倒计时: 0=分 1=秒 */
static void popup_adjust_field(s8 delta)
{
    s16 v;
    if (Clock_Popup == 1) /* 设时间 */
    {
        if (Popup_Field == 0)
        {
            v = (s16)Pop_H + delta;
            if (v < 0)
                v = 23;
            if (v > 23)
                v = 0;
            Pop_H = (u8)v;
        }
        else if (Popup_Field == 1)
        {
            v = (s16)Pop_M + delta;
            if (v < 0)
                v = 59;
            if (v > 59)
                v = 0;
            Pop_M = (u8)v;
        }
        else
        {
            v = (s16)Pop_S + delta;
            if (v < 0)
                v = 59;
            if (v > 59)
                v = 0;
            Pop_S = (u8)v;
        }
    }
    else if (Clock_Popup == 2) /* 设日期 */
    {
        if (Popup_Field == 0)
        {
            v = (s16)Pop_Y + delta;
            if (v < 0)
                v = 99;
            if (v > 99)
                v = 0;
            Pop_Y = (u8)v;
        }
        else if (Popup_Field == 1)
        {
            v = (s16)Pop_Mo + delta;
            if (v < 1)
                v = 12;
            if (v > 12)
                v = 1;
            Pop_Mo = (u8)v;
        }
        else
        {
            v = (s16)Pop_D + delta;
            if (v < 1)
                v = 31;
            if (v > 31)
                v = 1;
            Pop_D = (u8)v;
        }
    }
    else if (Clock_Popup == 3) /* 设闹钟 */
    {
        if (Popup_Field == 0)
        {
            v = (s16)Alm_H[Popup_Alarm_Idx] + delta;
            if (v < 0)
                v = 23;
            if (v > 23)
                v = 0;
            Alm_H[Popup_Alarm_Idx] = (u8)v;
        }
        else
        {
            v = (s16)Alm_M[Popup_Alarm_Idx] + delta;
            if (v < 0)
                v = 59;
            if (v > 59)
                v = 0;
            Alm_M[Popup_Alarm_Idx] = (u8)v;
        }
    }
    else if (Clock_Popup == 4) /* 倒计时 */
    {
        if (Popup_Field == 0)
        {
            v = (s16)Pop_TH + delta;
            if (v < 0)
                v = 99;
            if (v > 99)
                v = 0;
            Pop_TH = (u8)v;
        }
        else
        {
            v = (s16)Pop_TM + delta;
            if (v < 0)
                v = 59;
            if (v > 59)
                v = 0;
            Pop_TM = (u8)v;
        }
    }
}

/* 打开弹窗时初始化编辑缓冲区 */
static void popup_open(u8 type)
{
    RTC_TimeTypeDef rtc_t;
    RTC_DateTypeDef rtc_d;
    Clock_Popup = type;
    Popup_Field = 0;
    if (type == 1)
    {
        RTC_GetTime(RTC_Format_BIN, &rtc_t);
        Pop_H = rtc_t.RTC_Hours;
        Pop_M = rtc_t.RTC_Minutes;
        Pop_S = rtc_t.RTC_Seconds;
    }
    else if (type == 2)
    {
        RTC_GetDate(RTC_Format_BIN, &rtc_d);
        Pop_Y = rtc_d.RTC_Year;
        Pop_Mo = rtc_d.RTC_Month;
        Pop_D = rtc_d.RTC_Date;
    }
    else if (type == 3)
    {
        /* 闹钟编辑缓冲区直接用 Alm_H/M[Popup_Alarm_Idx] */
    }
    else if (type == 4)
    {
        Pop_TH = (u8)(Timer_Set_Sec / 60);
        Pop_TM = (u8)(Timer_Set_Sec % 60);
    }
}

/* 确认弹窗:写回 RTC / BKP / 倒计时 */
static void popup_confirm(void)
{
    RTC_DateTypeDef rtc_d;
    if (Clock_Popup == 1)
    {
        RTC_Set_Time(Pop_H, Pop_M, Pop_S, RTC_H12_AM);
        sprintf(str_buf, "SYS: Time set %02d:%02d:%02d", Pop_H, Pop_M, Pop_S);
        Add_Comm_Log(str_buf, LOG_CAT_SYS);
    }
    else if (Clock_Popup == 2)
    {
        rtc_d.RTC_Year = Pop_Y;
        rtc_d.RTC_Month = Pop_Mo;
        rtc_d.RTC_Date = Pop_D;
        rtc_d.RTC_WeekDay = 1;
        RTC_SetDate(RTC_Format_BIN, &rtc_d);
        sprintf(str_buf, "SYS: Date set 20%02d-%02d-%02d", Pop_Y, Pop_Mo, Pop_D);
        Add_Comm_Log(str_buf, LOG_CAT_SYS);
    }
    else if (Clock_Popup == 3)
    {
        if (!Alm_En[Popup_Alarm_Idx])
            Alm_En[Popup_Alarm_Idx] = 1; /* 编辑后默认开启 */
        alarm_save_idx(Popup_Alarm_Idx);
        sprintf(str_buf, "SYS: Alarm %d set %02d:%02d", Popup_Alarm_Idx + 1,
                Alm_H[Popup_Alarm_Idx], Alm_M[Popup_Alarm_Idx]);
        Add_Comm_Log(str_buf, LOG_CAT_SYS);
    }
    else if (Clock_Popup == 4)
    {
        Timer_Set_Sec = (u16)Pop_TH * 60 + Pop_TM;
        Timer_Remain_Sec = Timer_Set_Sec;
        Timer_Running = 0;
        sprintf(str_buf, "SYS: Timer set %d:%02d", Pop_TH, Pop_TM);
        Add_Comm_Log(str_buf, LOG_CAT_SYS);
    }
    Clock_Popup = 0;
}

/* 时钟页触摸处理,返回 1=已处理 0=未命中 */
static u8 touch_clock_handle(u16 x, u16 y)
{
    u8 i;

    /* ====== 弹窗模式:处理弹窗内交互 ====== */
    if (Clock_Popup != 0)
    {

        /* 字段点击区:点击大字体数字区域切换字段 */
        if (y >= POPUP_FIELD_Y && y <= POPUP_FIELD_Y + POPUP_FIELD_H)
        {
            if (Clock_Popup == 1 || Clock_Popup == 2)
            {
                /* 3 字段布局: POP3_START_X, POP3_FLD1_X, POP3_FLD2_X */
                u16 fld_x[3] = {POP3_START_X, POP3_FLD1_X, POP3_FLD2_X};
                for (i = 0; i < 3; i++)
                {
                    if (x >= fld_x[i] && x <= fld_x[i] + POPFIELD_W)
                    {
                        Popup_Field = i;
                        return 1;
                    }
                }
            }
            else
            {
                /* 2 字段布局: POP2_START_X, POP2_FLD1_X */
                u16 fld_x[2] = {POP2_START_X, POP2_FLD1_X};
                for (i = 0; i < 2; i++)
                {
                    if (x >= fld_x[i] && x <= fld_x[i] + POPFIELD_W)
                    {
                        Popup_Field = i;
                        return 1;
                    }
                }
            }
        }

        /* 闹钟弹窗: < / > 切换闹钟索引 */
        if (Clock_Popup == 3 &&
            y >= POPUP_SWITCH_Y && y <= POPUP_SWITCH_Y + POPUP_SWITCH_H)
        {
            if (x >= POPUP_PREV_X && x <= POPUP_PREV_X + POPUP_PREV_W)
            {
                if (Popup_Alarm_Idx > 0)
                    Popup_Alarm_Idx--;
                return 1;
            }
            if (x >= POPUP_NEXT_X && x <= POPUP_NEXT_X + POPUP_NEXT_W)
            {
                if (Popup_Alarm_Idx < MAX_ALARMS - 1)
                    Popup_Alarm_Idx++;
                return 1;
            }
            /* ON/OFF 开关: 中间区域 */
            {
                u16 swx = POPUP_X + 110;
                if (x >= swx && x <= swx + 80)
                {
                    Alm_En[Popup_Alarm_Idx] = !Alm_En[Popup_Alarm_Idx];
                    return 1;
                }
            }
        }

        /* - / + 按钮 (所有弹窗) */
        if (y >= POPUP_ADJ_Y && y <= POPUP_ADJ_Y + POPUP_ADJ_H)
        {
            if (x >= POPUP_MINUS_X && x <= POPUP_MINUS_X + POPUP_MINUS_W)
            {
                popup_adjust_field(-1);
                return 1;
            }
            if (x >= POPUP_PLUS_X && x <= POPUP_PLUS_X + POPUP_PLUS_W)
            {
                popup_adjust_field(+1);
                return 1;
            }
        }

        /* OK 按钮 */
        if (y >= POPUP_OK_Y && y <= POPUP_OK_Y + POPUP_OK_H &&
            x >= POPUP_OK_X && x <= POPUP_OK_X + POPUP_OK_W)
        {
            popup_confirm();
            return 1;
        }
        /* Cancel 按钮 */
        if (y >= POPUP_OK_Y && y <= POPUP_OK_Y + POPUP_OK_H &&
            x >= POPUP_CANCEL_X && x <= POPUP_CANCEL_X + POPUP_CANCEL_W)
        {
            Clock_Popup = 0;
            return 1;
        }
        return 1; /* 弹窗模式下吞掉所有其他点击 */
    }

    /* ====== 主视图:4 大功能按钮 ====== */
    /* 按钮 1: 设时间 (左上) */
    if (x >= CLK_BTN_L_X && x <= CLK_BTN_L_X + CLK_BTN_W &&
        y >= CLK_BTN_ROW1_Y && y <= CLK_BTN_ROW1_Y + CLK_BTN_H)
    {
        popup_open(1);
        return 1;
    }
    /* 按钮 2: 设日期 (右上) */
    if (x >= CLK_BTN_R_X && x <= CLK_BTN_R_X + CLK_BTN_W &&
        y >= CLK_BTN_ROW1_Y && y <= CLK_BTN_ROW1_Y + CLK_BTN_H)
    {
        popup_open(2);
        return 1;
    }
    /* 按钮 3: 设闹钟 (左下) */
    if (x >= CLK_BTN_L_X && x <= CLK_BTN_L_X + CLK_BTN_W &&
        y >= CLK_BTN_ROW2_Y && y <= CLK_BTN_ROW2_Y + CLK_BTN_H)
    {
        popup_open(3);
        return 1;
    }
    /* 按钮 4: 倒计时 (右下) */
    if (x >= CLK_BTN_R_X && x <= CLK_BTN_R_X + CLK_BTN_W &&
        y >= CLK_BTN_ROW2_Y && y <= CLK_BTN_ROW2_Y + CLK_BTN_H)
    {
        popup_open(4);
        return 1;
    }

    /* ====== 闹钟列表:点击切换开关 ====== */
    {
        u16 ay = CLK_ALM_LIST_Y;
        for (i = 0; i < MAX_ALARMS; i++)
        {
            if (y >= ay && y <= ay + CLK_ALM_LIST_H &&
                x >= CLK_ALM_LIST_X && x <= CLK_ALM_LIST_X + CLK_ALM_LIST_W)
            {
                Alm_En[i] = !Alm_En[i];
                alarm_save_idx(i);
                sprintf(str_buf, "SYS: Alarm %d %s", i + 1, Alm_En[i] ? "ON" : "OFF");
                Add_Comm_Log(str_buf, LOG_CAT_SYS);
                return 1;
            }
            ay += CLK_ALM_LIST_H;
        }
    }

    /* ====== 倒计时控制:Start/Pause / Reset ====== */
    if (y >= CLK_TIMER_Y && y <= CLK_TIMER_Y + CLK_TIMER_H)
    {
        /* Start/Pause 按钮 */
        if (x >= 250 && x <= 340)
        {
            if (Timer_Remain_Sec == 0)
            {
                Timer_Remain_Sec = Timer_Set_Sec;
                Timer_Running = 1;
            }
            else
            {
                Timer_Running = !Timer_Running;
            }
            return 1;
        }
        /* Reset 按钮 */
        if (x >= 350 && x <= 440)
        {
            Timer_Running = 0;
            Timer_Remain_Sec = Timer_Set_Sec;
            return 1;
        }
    }

    return 0;
}

/**
 * @brief 触摸手势识别与交互任务
 *        30ms 周期扫描触摸,识别 TAP/LONG_PRESS/SWIPE/DRAG,
 *        翻译为虚拟按键注入 Key_Sem 或直接修改全局状态。
 */
void touch_task(void *pdata)
{
    static TouchGesture_t gesture = G_IDLE;
    static u16 down_x = 0, down_y = 0, last_x = 0, last_y = 0;
    static u32 down_tick = 0;
    static u32 tap_cooldown = 0; /* 点击冷却:防止电容屏残余触摸导致二次触发 */
    u8 err;
    u8 touch_pressed;
    u16 cur_x, cur_y;
    int dx, dy, adx, ady;
    u8 menu_s, menu_c;
    u32 tick_now;
    u8 hit_item;
    u8 hit_btn;
    u8 is_long;
    u8 drag_menu_c = 0;
    u8 is_emg;

    pdata = pdata;

    OSTimeDly(150); /* 等待 ui_task 欢迎画面结束(750ms) */

    while (1)
    {
        /* 检查触摸反馈点是否超时, 超时则恢复像素 */
        tap_feedback_poll();

        /* GT9147/FT5206 电容屏: 只需调用 1 次 scan。
           多次连续调用会导致第 2 次读到"已清除"的 GT9147 状态寄存器,
           从而错误清除 tp_dev.sta 的 TP_PRES_DOWN 位, 触摸失效。
           scan 内部有静态变量 t 控制读取频率, 不需外部多次调用。 */
        tp_dev.scan(0);
        touch_pressed = (tp_dev.sta & TP_PRES_DOWN) ? 1 : 0;
        cur_x = tp_dev.x[0];
        cur_y = tp_dev.y[0];

        /* 坐标合法性检查 */
        if (cur_x >= lcddev.width || cur_y >= lcddev.height)
            touch_pressed = 0;

        /* 点击冷却: 电容屏抬手后可能残余 1~2 帧触摸, 冷却期内忽略新按下 */
        if (tap_cooldown > 0)
        {
            tap_cooldown--;
            touch_pressed = 0;
        }

        if (touch_pressed)
        {
            if (gesture == G_IDLE)
            {
                gesture = G_PRESSED;
                down_x = cur_x;
                down_y = cur_y;
                last_x = cur_x;
                last_y = cur_y;
                down_tick = OSTimeGet();
            }
            else
            {
                dx = (int)cur_x - (int)down_x;
                dy = (int)cur_y - (int)down_y;
                adx = dx < 0 ? -dx : dx;
                ady = dy < 0 ? -dy : dy;

                if (gesture == G_PRESSED)
                {
                    /* 检查是否进入调节柱拖动模式 */
                    OSMutexPend(Config_Mutex, 0, &err);
                    menu_s = Menu_State;
                    menu_c = Menu_Cursor;
                    OSMutexPost(Config_Mutex);

                    if (menu_s == 2 && (menu_c == 0 || menu_c == 1) &&
                        down_x >= BAR_HOT_X1 && down_x <= BAR_HOT_X2 &&
                        down_y >= BAR_TOP_Y && down_y <= BAR_BOTTOM_Y &&
                        (adx > DRAG_MOVE_TH || ady > DRAG_MOVE_TH))
                    {
                        gesture = G_DRAG_BAR;
                        drag_menu_c = menu_c;
                        touch_update_bar_value(cur_y, menu_c);
                    }
                    else if (adx >= SWIPE_MOVE_TH && adx > ady)
                    {
                        gesture = G_SWIPE_H;
                    }
                    else if (ady >= SWIPE_MOVE_TH && ady > adx)
                    {
                        gesture = G_SWIPE_V;
                    }
                }
                else if (gesture == G_DRAG_BAR)
                {
                    /* 拖动中实时更新值 */
                    touch_update_bar_value(cur_y, drag_menu_c);
                }

                last_x = cur_x;
                last_y = cur_y;
            }
        }
        else /* 未按下 */
        {
            if (gesture != G_IDLE)
            {
                tick_now = OSTimeGet();
                dx = (int)last_x - (int)down_x;
                dy = (int)last_y - (int)down_y;
                adx = dx < 0 ? -dx : dx;
                ady = dy < 0 ? -dy : dy;
                is_long = ((tick_now - down_tick) >= TAP_TIME_TH) ? 1 : 0;

                OSMutexPend(Config_Mutex, 0, &err);
                menu_s = Menu_State;
                menu_c = Menu_Cursor;
                OSMutexPost(Config_Mutex);

                if (adx < TAP_MOVE_TH && ady < TAP_MOVE_TH)
                {
                    /* === 点击/长按事件 === */
                    /* 即使中途 gesture 被设为 G_SWIPE_*, 只要最终总位移 < 25px 就视为点击
                       (电容屏轻触时手指易抖动 30+px, 但最终回弹后总位移很小) */
                    /* 设置冷却 (12 ticks = 60ms), 防止电容屏残余触摸导致二次触发 */
                    tap_cooldown = 12;
                    /* 显示触摸反馈点 (青色环, 250ms 后自动恢复像素) */
                    tap_feedback_show(down_x, down_y);

                    /* 闹钟弹窗:最高优先级,模态拦截所有其他触摸 */
                    if (Alarm_Popup_Active)
                    {
                        u8 idx;
                        Stop_Alarm_Beep = 1; /* 点击任意按钮立即停止铃声 */
                        /* Snooze 按钮 (绿色, 左) */
                        if (down_x >= 90 && down_x <= 230 &&
                            down_y >= 340 && down_y <= 390)
                        {
                            RTC_TimeTypeDef snz_t;
                            u8 new_m;
                            u8 new_h;
                            idx = Alarm_Popup_Idx;
                            /* 基于当前时间 +5 分钟 (而非闹钟设定时间),
                               否则贪睡会立即重新触发 */
                            RTC_GetTime(RTC_Format_BIN, &snz_t);
                            new_m = (u8)(snz_t.RTC_Minutes + 5);
                            new_h = snz_t.RTC_Hours;
                            if (new_m >= 60)
                            {
                                new_m -= 60;
                                new_h = (u8)((new_h + 1) % 24);
                            }
                            Alm_Snooze_H[idx] = new_h;
                            Alm_Snooze_M[idx] = new_m;
                            Alm_Snoozing[idx] = 1;
                            Alarm_Popup_Active = 0;
                            sprintf(str_buf, "SYS: Alarm %d snoozed to %02d:%02d",
                                    idx + 1, new_h, new_m);
                            Add_Comm_Log(str_buf, LOG_CAT_SYS);
                            OSQPost(UI_Queue, (void *)0xFFFFFFFF);
                        }
                        /* Dismiss 按钮 (红色, 右) */
                        else if (down_x >= 250 && down_x <= 390 &&
                                 down_y >= 340 && down_y <= 390)
                        {
                            idx = Alarm_Popup_Idx;
                            Alm_Dismissed[idx] = 1;
                            Alm_Snoozing[idx] = 0;
                            Alarm_Popup_Active = 0;
                            sprintf(str_buf, "SYS: Alarm %d dismissed", idx + 1);
                            Add_Comm_Log(str_buf, LOG_CAT_SYS);
                            OSQPost(UI_Queue, (void *)0xFFFFFFFF);
                        }
                        /* 弹窗外点击不响应,必须选 snooze 或 dismiss */
                    }
                    else if (Timer_Popup_Active)
                    {
                        /* OK 按钮 (青色, 居中: 170-310, 370-420) */
                        if (down_x >= 170 && down_x <= 310 &&
                            down_y >= 370 && down_y <= 420)
                        {
                            Timer_Popup_Active = 0;
                            /* 蜂鸣由 alarm_check 内部根据 cnt 自行停止 */
                            sprintf(str_buf, "SYS: Timer popup dismissed");
                            Add_Comm_Log(str_buf, LOG_CAT_SYS);
                            OSQPost(UI_Queue, (void *)0xFFFFFFFF);
                        }
                        /* 弹窗外点击不响应 */
                    }
                    else if (menu_s == 0) /* 待机态 */
                    {
                        OSMutexPend(Config_Mutex, 0, &err);
                        is_emg = GlobalConfig.emergency_stop;
                        OSMutexPost(Config_Mutex);

                        /* 紧急模式:点击中心区域恢复(不响应长按菜单) */
                        if (is_emg && !is_long &&
                            down_x >= EMG_HOT_X1 && down_x <= EMG_HOT_X2 &&
                            down_y >= EMG_HOT_Y1 && down_y <= EMG_HOT_Y2)
                        {
                            touch_inject_key(2); /* KEY2: 紧急恢复 */
                        }
                        else if (is_long &&
                                 down_x >= MENU_HOT_CX1 && down_x <= MENU_HOT_CX2 &&
                                 down_y >= MENU_HOT_CY1 && down_y <= MENU_HOT_CY2)
                        {
                            touch_inject_key(0); /* 长按中心:呼出菜单(KEY0) */
                        }
                        else if (!is_long)
                        {
                            /* 日志页:筛选按钮 (命中区上下扩展4px,更容易点到) */
                            if (UI_Mode == 2 &&
                                down_y >= (u16)(LOGFILT_Y1 - 4) && down_y <= (u16)(LOGFILT_Y2 + 4))
                            {
                                u8 old_filt = Log_Filter;
                                if (down_x >= LOGFILT_ALL_X1 && down_x <= LOGFILT_ALL_X2)
                                    Log_Filter = 0;
                                else if (down_x >= LOGFILT_TX_X1 && down_x <= LOGFILT_TX_X2)
                                    Log_Filter = 1;
                                else if (down_x >= LOGFILT_RX_X1 && down_x <= LOGFILT_RX_X2)
                                    Log_Filter = 2;
                                else if (down_x >= LOGFILT_SYS_X1 && down_x <= LOGFILT_SYS_X2)
                                    Log_Filter = 3;
                                /* 切换筛选时重置滚动, 显示最新20条 */
                                if (Log_Filter != old_filt)
                                    Log_Scroll_Offset = 0;
                                OSQPost(UI_Queue, (void *)0xFFFFFFFF);
                            }
                            /* 时钟页:校时/闹钟按钮 */
                            else if (UI_Mode == 3)
                            {
                                if (touch_clock_handle(down_x, down_y))
                                    OSQPost(UI_Queue, (void *)0xFFFFFFFF);
                            }
                            /* 仪表盘:DAC 触摸调节按钮 */
                            else if (UI_Mode == 1 &&
                                     down_y >= DAC_BTN_Y1 && down_y <= DAC_BTN_Y2)
                            {
                                u8 dac_changed = 1;
                                if (down_x >= DAC_BTN_DEC_X1 && down_x <= DAC_BTN_DEC_X2)
                                {
                                    if (Dac_Fix_Mv >= 100)
                                        Dac_Fix_Mv -= 100;
                                    Dac_Mode = 1;
                                }
                                else if (down_x >= DAC_BTN_INC_X1 && down_x <= DAC_BTN_INC_X2)
                                {
                                    if (Dac_Fix_Mv <= 3200)
                                        Dac_Fix_Mv += 100;
                                    Dac_Mode = 1;
                                }
                                else if (down_x >= DAC_BTN_SIN_X1 && down_x <= DAC_BTN_SIN_X2)
                                {
                                    Dac_Mode = 0;
                                }
                                else if (down_x >= DAC_BTN_FIX_X1 && down_x <= DAC_BTN_FIX_X2)
                                {
                                    Dac_Mode = 1;
                                    /* 锁定 Dac_Fix_Mv 当前值, 停止正弦循环 */
                                }
                                else
                                {
                                    dac_changed = 0;
                                }
                                if (dac_changed)
                                {
                                    sprintf(str_buf, "SYS: DAC %s %d.%02dV",
                                            Dac_Mode == 0 ? "SIN" : "FIX",
                                            Dac_Fix_Mv / 1000, (Dac_Fix_Mv % 1000) / 10);
                                    Add_Comm_Log(str_buf, LOG_CAT_SYS);
                                    OSQPost(UI_Queue, (void *)0xFFFFFFFF);
                                }
                            }
                            /* 点击底部状态栏 "Mute:" 文字区域切换消音
                               直接 toggle, 不走 Key_Sem, 避免 control_task
                               去抖周期(150ms)内电容屏残余触摸导致二次翻转 */
                            else if (down_x >= 100 && down_x <= 220 &&
                                     down_y >= (u16)(lcddev.height - 30) &&
                                     down_y <= (u16)(lcddev.height - 5))
                            {
                                OSMutexPend(Config_Mutex, 0, &err);
                                GlobalConfig.beep_mute = !GlobalConfig.beep_mute;
                                OSMutexPost(Config_Mutex);
                                OSQPost(UI_Queue, (void *)0xFFFFFFFF);
                            }
                            else if (UI_Mode == 0)
                            {
                                /* 折线图模式:点击网格显示/移动/关闭气泡 */
                                if (down_x >= 55 && down_x <= 425 &&
                                    down_y >= 40 && down_y <= 640)
                                {
                                    u16 step_x = 370 / PLOT_POINTS_MAX;
                                    u8 new_idx;
                                    if (step_x == 0)
                                        step_x = 1;
                                    new_idx = (u8)((down_x - 55) / step_x);
                                    if (History_Count > 0 && new_idx >= History_Count)
                                        new_idx = History_Count - 1;
                                    Bubble_Idx = new_idx;
                                    Bubble_Show = 1;
                                    OSQPost(UI_Queue, (void *)0xFFFFFFFF);
                                }
                                else if (Bubble_Show)
                                {
                                    /* 点击网格外:关闭气泡 */
                                    Bubble_Show = 0;
                                    OSQPost(UI_Queue, (void *)0xFFFFFFFF);
                                }
                            }
                        }
                    }
                    else if (menu_s == 1) /* 菜单导航态 */
                    {
                        if (!is_long)
                        {
                            hit_item = touch_nav_item_hit(down_x, down_y);
                            if (hit_item != 0xFF)
                            {
                                OSMutexPend(Config_Mutex, 0, &err);
                                Menu_Cursor = hit_item;
                                OSMutexPost(Config_Mutex);
                                touch_inject_key(0); /* 点击菜单项:确认(KEY0) */
                            }
                            else
                            {
                                touch_inject_key(2); /* 点击菜单外:退出(KEY2) */
                            }
                        }
                    }
                    else if (menu_s == 2) /* 编辑态 */
                    {
                        if (!is_long)
                        {
                            hit_btn = touch_edit_btn_hit(down_x, down_y);
                            if (hit_btn > 0)
                            {
                                u8 vk = 0xFF;
                                if (hit_btn == 1)
                                    vk = 3; /* "+" → WK_UP */
                                else if (hit_btn == 2)
                                    vk = 1; /* "-" → KEY1 */
                                else if (hit_btn == 3)
                                    vk = 0; /* "OK" → KEY0 */
                                else if (hit_btn == 4)
                                    vk = 2; /* "Cancel" → KEY2 */
                                touch_inject_key(vk);
                            }
                            else if (menu_c == 0 || menu_c == 1)
                            {
                                /* 点击调节柱跳值(非拖动情况) */
                                if (down_x >= BAR_HOT_X1 && down_x <= BAR_HOT_X2 &&
                                    down_y >= BAR_TOP_Y && down_y <= BAR_BOTTOM_Y)
                                {
                                    touch_update_bar_value(down_y, menu_c);
                                }
                            }
                            else if (menu_c == 2 || menu_c == 3 || menu_c == 4)
                            {
                                /* Emg/Mute/Crash Sim 编辑:点击确认/翻转 */
                                touch_inject_key(0);
                            }
                        }
                    }
                }
                else if (gesture == G_SWIPE_H)
                {
                    /* === 水平滑动 === */
                    if (menu_s == 0 && !(UI_Mode == 3 && Clock_Popup != 0)) /* 待机态:切页(弹窗打开时不切) */
                    {
                        if (Bubble_Show)
                            Bubble_Show = 0; /* 切页关闭气泡 */
                        if (dx < 0)
                        {
                            touch_inject_key(1); /* 左滑:下一页(KEY1) */
                        }
                        else
                        {
                            OSMutexPend(Config_Mutex, 0, &err);
                            UI_Mode = (UI_Mode + 3) % 4; /* 右滑:上一页 */
                            OSMutexPost(Config_Mutex);
                            OSQPost(UI_Queue, (void *)0xFFFFFFFF);
                        }
                    }
                    /* 菜单态不响应水平滑动 */
                }
                else if (gesture == G_SWIPE_V)
                {
                    /* === 垂直滑动 === */
                    if (menu_s == 0 && UI_Mode == 3 && Clock_Popup != 0)
                    {
                        /* 时钟页弹窗:上下滑动调整选中字段 */
                        if (dy < 0)
                            popup_adjust_field(+1);
                        else
                            popup_adjust_field(-1);
                        OSQPost(UI_Queue, (void *)0xFFFFFFFF);
                    }
                    else if (menu_s == 0)
                    {
                        /* 待机态:下滑打开菜单 (所有页面) */
                        if (dy > 0)
                        {
                            touch_inject_key(0); /* 下滑呼出菜单(KEY0) */
                        }
                        /* 上滑:无操作(预留) */
                    }
                    else if (menu_s == 1)
                    {
                        /* 菜单导航态:上划关闭菜单,下滑移动光标 */
                        if (dy < 0)
                            touch_inject_key(2); /* 上划:关闭菜单(KEY2) */
                        else
                            touch_inject_key(1); /* 下滑:光标下移(KEY1) */
                    }
                }
                /* G_DRAG_BAR 释放无需额外处理(拖动中已实时更新) */

                gesture = G_IDLE;
            }
        }

        OSTimeDly(2); /* 10ms 周期(2 ticks × 5ms), 提高 touch 响应速度 */
    }
}
