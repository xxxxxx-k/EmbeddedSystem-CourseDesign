#include "exti.h"
#include "delay.h"
#include "led.h"
#include "key.h"
#include "usart.h"
#include "includes.h"
#include "lcd.h"
#include "adc.h"
#include "sys.h"

//////////////////////////////////////////////////////////////////////////////////
// 本程序只供学习使用，未经作者许可，不得用于其它任何用途
// ALIENTEK STM32F407开发板
// 外部中断 驱动代码
// 正点原子@ALIENTEK
// 技术论坛:www.openedv.com
// 创建日期:2014/5/4
// 版本：V1.0
// 版权所有，盗版必究。
// Copyright(C) 广州市星翼电子科技有限公司 2014-2024
// All rights reserved
//////////////////////////////////////////////////////////////////////////////////

#define START_TASK_PRIO 10 // 开始任务的优先级设置为最低

#define lcdtask_TASK_PRIO 7

volatile u8 Last_Key = 0xFF;
extern OS_EVENT *Key_Sem;

// 外部中断0服务程序 (WK_UP)
void EXTI0_IRQHandler(void)
{
#if SYSTEM_SUPPORT_OS
	OSIntEnter();
#endif
	if (WK_UP == 1)
	{
		Last_Key = 3; // WK_UP 对应 3
		OSSemPost(Key_Sem);
	}
	EXTI_ClearITPendingBit(EXTI_Line0);
#if SYSTEM_SUPPORT_OS
	OSIntExit();
#endif
}
// 外部中断2服务程序 (KEY2)
void EXTI2_IRQHandler(void)
{
#if SYSTEM_SUPPORT_OS
	OSIntEnter();
#endif
	if (KEY2 == 0)
	{
		Last_Key = 2; // KEY2 对应 2
		OSSemPost(Key_Sem);
	}
	EXTI_ClearITPendingBit(EXTI_Line2);
#if SYSTEM_SUPPORT_OS
	OSIntExit();
#endif
}
// 外部中断3服务程序 (KEY1)
void EXTI3_IRQHandler(void)
{
#if SYSTEM_SUPPORT_OS
	OSIntEnter();
#endif
	if (KEY1 == 0)
	{
		Last_Key = 1; // KEY1 对应 1
		OSSemPost(Key_Sem);
	}
	EXTI_ClearITPendingBit(EXTI_Line3);
#if SYSTEM_SUPPORT_OS
	OSIntExit();
#endif
}
// 外部中断4服务程序 (KEY0)
void EXTI4_IRQHandler(void)
{
#if SYSTEM_SUPPORT_OS
	OSIntEnter();
#endif
	if (KEY0 == 0)
	{
		Last_Key = 0; // KEY0 对应 0
		OSSemPost(Key_Sem);
		// 消抖:短暂延时后清除EXTI挂起位再退出,防止多次触发
	}
	EXTI_ClearITPendingBit(EXTI_Line4);
#if SYSTEM_SUPPORT_OS
	OSIntExit();
#endif
}

// 外部中断初始化程序
// 初始化PE2~4,PA0为中断输入.
void EXTIX_Init(void)
{
	NVIC_InitTypeDef NVIC_InitStructure;
	EXTI_InitTypeDef EXTI_InitStructure;

	KEY_Init(); // 按键对应的IO口初始化

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE); // 使能SYSCFG时钟

	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOE, EXTI_PinSource2); // PE2 连接到中断线2
	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOE, EXTI_PinSource3); // PE3 连接到中断线3
	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOE, EXTI_PinSource4); // PE4 连接到中断线4
	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA, EXTI_PinSource0); // PA0 连接到中断线0

	/* 配置EXTI_Line0 */
	EXTI_InitStructure.EXTI_Line = EXTI_Line0;			   // LINE0
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;	   // 中断事件
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising; // 上升沿触发
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;			   // 使能LINE0
	EXTI_Init(&EXTI_InitStructure);						   // 配置

	/* 配置EXTI_Line2,3,4 */
	EXTI_InitStructure.EXTI_Line = EXTI_Line2 | EXTI_Line3 | EXTI_Line4;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;		// 中断事件
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling; // 下降沿触发
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;				// 中断线使能
	EXTI_Init(&EXTI_InitStructure);							// 配置

	NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;			 // 外部中断0
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x00; // 抢占优先级0
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x02;		 // 子优先级2
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;				 // 使能外部中断通道
	NVIC_Init(&NVIC_InitStructure);								 // 配置

	NVIC_InitStructure.NVIC_IRQChannel = EXTI2_IRQn;			 // 外部中断2
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x03; // 抢占优先级3
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x02;		 // 子优先级2
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;				 // 使能外部中断通道
	NVIC_Init(&NVIC_InitStructure);								 // 配置

	NVIC_InitStructure.NVIC_IRQChannel = EXTI3_IRQn;			 // 外部中断3
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x02; // 抢占优先级2
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x02;		 // 子优先级2
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;				 // 使能外部中断通道
	NVIC_Init(&NVIC_InitStructure);								 // 配置

	NVIC_InitStructure.NVIC_IRQChannel = EXTI4_IRQn;			 // 外部中断4
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x01; // 抢占优先级1
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x02;		 // 子优先级2
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;				 // 使能外部中断通道
	NVIC_Init(&NVIC_InitStructure);								 // 配置
}
